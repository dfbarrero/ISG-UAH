#ª/usr/bin/sh


for I in 20/*.dat
do
	FILE=`echo $I | cut -d "/" -f  2 -`
	echo $FILE

	# Extract first line
	head -1 20/$FILE > $FILE
	# Extract the body without the header
	tail -400 20/$FILE >> $FILE
	tail -400 40/$FILE >> $FILE
	tail -400 60/$FILE >> $FILE
	tail -400 80/$FILE >> $FILE
	tail -400 100/$FILE >> $FILE
done
