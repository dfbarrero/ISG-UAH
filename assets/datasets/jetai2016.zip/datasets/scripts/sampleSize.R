#!/usr/bin/Rscript --vanilla
library(binomSamSize)

#standard <- function(epsilon=0.01, p0=0.5, alpha=0.05) {
#	z2 <- qnorm(alpha/2)^2
#
#	return(z2*p0*(1-p0)/(epsilon^2))
#}
#
#ac <- function(epsilon=0.01, p0=0.5, alpha=0.05) {
#	z2 <- qnorm(alpha)^2
#
#	return(standard(epsilon, p0, alpha) - z2)
#}
#
#wilson <- function(epsilon=0.01, p0=0.5, alpha=0.05) {
#	z2 <- qnorm(alpha)^2
#
#	num <- p0*(1-p0)-2*epsilon^2 + sqrt(p0^2*(1-p0)^2+4*epsilon^2*(p0-0.5)^2)
#	return(z2 * num/(2*(epsilon^2)))
#}

x11()

par(mfrow=c(1, 2), mar=c(3,3,1.5,0.5), oma=c(1,0,0,0), mgp=c(2, 1, 0))

alpha <- 0.05
epsilon <- 0.1
p.grid <- seq(0, 0.5, length=100)

plot(1:length(p.grid),  type="n", ylim=range(0, 100), axes=FALSE, main="", ylab="Number of samples (n)", xlab=expression(paste("Anticipated success probability (", p[0], ")")))

lines(ciss.wald(p0=p.grid, d=epsilon, alpha=alpha), lty=2, col=2, lwd=2)
lines(ciss.agresticoull(p0=p.grid, d=epsilon, alpha=alpha), lty=3, col=3, lwd=2)
lines(ciss.wilson(p0=p.grid, d=epsilon, alpha=alpha), lty=4, col=4, lwd=2)

axis(1, at=c(1, 25, 50, 75, 100), c(0.01,0.125, 0.25, 0.375, 0.5))
axis(2, label=TRUE)
box()
grid()
abline(h=seq(10,100, by=10), col = "lightgray", lty = "dotted", lwd = par("lwd"))

########
p <- 0.5
epsilon.grid <- seq(from=0.01, to=0.5, length=100)

plot(1:length(epsilon.grid),  type="n", ylim=range(1, 10000), axes=FALSE, main="", log="y", ylab="", xlab=expression(paste("Half interval width (", epsilon, ")")))

print(ciss.wald(p0=p, d=epsilon.grid, alpha=alpha))
lines(ciss.wald(p0=p, d=epsilon.grid, alpha=alpha), lty=2, col=2, lwd=2)
lines(ciss.agresticoull(p0=p, d=epsilon.grid, alpha=alpha), lty=3, col=3, lwd=2)
lines(ciss.wilson(p0=p, d=epsilon.grid, alpha=alpha), lty=4, col=4, lwd=2)

axis(1, at=c(1, 25, 50, 75, length(epsilon.grid)), c(0.01,0.125, 0.25, 0.375, 0.5))#epsilon.grid)
axis(2, label=TRUE)
box()
grid(equilogs=FALSE)
abline(h=1:10, col = "lightgray", lty = "dotted", lwd = par("lwd"))
abline(h=seq(10,100, by=5), col = "lightgray", lty = "dotted", lwd = par("lwd"))
abline(h=seq(100,1000, by=50), col = "lightgray", lty = "dotted", lwd = par("lwd"))
abline(h=seq(1000,10000, by=500), col = "lightgray", lty = "dotted", lwd = par("lwd"))

legend("topright", c("Standard", "Agresti-Coull", "Wilson"), col=2:4, lty=2:4, lwd=2)

dev.copy2eps(file="sampleSize.eps", width=16, height=8, paper="special",  fonts="ComputerModern");
while (1) Sys.sleep(10)
