#!/usr/bin/Rscript --vanilla

# Systematic CP and CIW for different values of K and N
# n stands for the number of trials while n stands for the
# number of successes.

#------- Parameters --------c
methods <- c("asymptotic", "exact", "agresti-coull", "wilson", "bayes")
labels <- c("Standard", "\"Exact\"", "Agresti-Coull", "Wilson", "Bayes")
labels <- c("Standard", "\"Exact\"", "Agresti-Coull", "Wilson")
methods <- c("asymptotic", "exact", "agresti-coull", "wilson")
npoints <- 200
ppoints <- 2000
#----------------------------
	
x11()
png(file="cp.png")

library(binom, verbose=FALSE)
library(fields, verbose=FALSE)

#par(mfrow=c(length(methods), 2), mar=c(1,2.5,1,0), oma=c(1,0,0,0), mgp=c(1.5, 0.5, 0))
par(oma=c(0,0,0.5,0.5), mgp=c(1.5, 0.5, 0), cex=2)  # margin of 4 spaces width at right hand side
set.panel(2,2) # 3X2 matrix of plots
par(mar=c(3,2.5,0.5,1))

p <- (1:ppoints-1)/ppoints
n <- 1:npoints

#persp(1:4, 1:5, cp)
j <- 1
for (method in methods) {
	cp <- matrix(rep(NA, length(p)*length(n)), c(length(n), length(p)))
	
	for (i in n) {
		lim <- c(0.85, 1)
		if (method != "asymptotic") {
			lim <- c(0,1)
			cp[cp<0.85] <- NA
		}
		cp[cp==1] <- NA
		print(i)
		if (i < 50) {
			cp[i,] <- binom.coverage(p=p, i, method=method, zlim=lim)$coverage
		} else {
			cp[i,] <- binom.coverage(p=p, i, method=method, zlim=lim, tol=.Machine$double.eps^0.03)$coverage
		}
	}
	
	image.plot(p,n,t(cp), ylab=paste(labels[j], ": Runs (n)",sep=""), xlab="Success rate (p)")
	#image.plot(p,n,t(cp), ylab="Runs (n)", xlab="Success rate (p)", axes=TRUE)
	mtext(labels[i], side=2, line=2)
	j <- j+1
	#image.plot(p, n, cp, xlab="Probability (p)", ylab="Runs (n)", main=paste(labels[[i]], " CP", sep=""))
#	image.plot(p, n, ciw,
#		xlab="Probability (p)", ylab="Runs (n)", main=paste(labels[[i]], " CIW", sep=""))
#		contour(as.numeric(rownames(cp)), as.numeric(chartr("X", " ", colnames(cp))), cp, nlevels=5,
#			xlab="P", ylab="N", add=TRUE, col="peru")
}

#par(oma=c(0,0,0,0), mgp=c(0, 0, 0))
#image.plot(p,n, zlim=c(0.85,1), legend.only=TRUE, horizontal=TRUE, legend.mar=7)

#dev.copy2eps(file="cp-ciw.eps", width=18, paper="special", fonts="ComputerModern");

while (1) Sys.sleep(10)
