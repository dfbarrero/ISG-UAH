#!/usr/bin/Rscript --vanilla

# Given a set of CI measures, this script plots 
# CP diagrams for different N and P.

#------- Parameters --------
methods <- c("wilson", "exact", "asymptotic", "bayes", "agresti-coull")
labels <- c("Wilson", "Exact", "Standard", "Bayes", "Agresti-Coull")
methods <- c("wilson", "exact", "asymptotic", "agresti-coull")
labels <- c("Wilson", "Exact", "Standard", "A-C")
#----------------------------
	
# Initial stuff
library(boot, verbose=FALSE)
library(binom, verbose=FALSE)

x11()

# Let's begin to plot
par(mfrow=c(2, 1), mar=c(3,3,1,1), oma=c(0,0,0,0), mgp=c(2, 1, 0))
points <- 1000
plot(0*(1:100), ylim=c(0.8, 1),type="n", ylab="Average CP", xlab="Number of runs (n)", axis=FALSE)
i <- 1
for (method in methods) {
	average <- NULL
	for (n in 1:100) {
		if (method != "bayes" && (n > 50)) {
			tol=.Machine$double.eps^0.03
		} else {
			tol=.Machine$double.eps^0.01
		}
		average[n] <- sum(binom.coverage(p=(1:points)/points, n=n, method=method, tol=tol)$coverage)/length(1:points)

	}
	lines(1:100,average, col=i, lty=i)
	i <- i+1
}

abline(h=0.95, col="grey")
legend("bottomright", labels, col=1:length(methods), lty=1:length(methods))

# Fixed p, variable n
plot((0:100)/100, 0*(0:100)/100, ylim=c(0.5, 1),type="n", ylab="Average CP", xlab="Success probability (p)", axis=FALSE)
i <- 1
for (method in methods) {
	average <- NULL
	for (p in (1:99)) {
		tol=.Machine$double.eps^0.01
		average[p] <- sum(binom.coverage(p=p/100, n=5:49, method=method, tol=tol)$coverage)/length(5:49)
	}
	print(average)
	lines((1:99)/100, average, col=i, lty=i)
	i <- i+1
}

abline(h=0.95, col="grey")

dev.copy2eps(file="average-cp.eps");

while (1) Sys.sleep(10)
q()
# -------- CIW ---------
dev.new()
x11()
#postscript("Rplots.eps", paper="a4", horizontal=FALSE, height=5, width=4)
par(mfrow=c(2, 1), mar=c(3,3,1,1), oma=c(0,0,0,0), mgp=c(2, 1, 0))
ciw <- as.matrix(read.table(paste("../cis/", "asymptotic", "-ciw.dat", sep="")))
colnames(ciw) <- gdata::trim(chartr("X", " ", colnames(ciw)))

#persp(as.numeric(rownames(ciw)), as.numeric(chartr("X", " ", colnames(ciw))), ciw, 
#	theta = 120, phi = 45,
#	col="lightblue", 
#	xlab="P", ylab="N", zlab="CIW",
#	shade=0.75, border=NA)#, main=method) # ticktype = "detailed")

plot(as.numeric(rownames(ciw)), ciw[, n]+0.01,  type="n", ylab="CIW", xlab=paste("Probability (with n =", n, ")"))

i <- 1
for (method in methods) {
	ciw <- as.matrix(read.table(paste("../cis/", method, "-ciw.dat", sep="")))
	colnames(ciw) <- gdata::trim(chartr("X", " ", colnames(ciw)))
	print(colnames(ciw))
	print(length(colnames(ciw)))
	print(length(ciw[,n]))
	lines(as.numeric(rownames(ciw)), ciw[, n], col=i, lty=i. lwd=2)
	i <- i+1
}

#title(main=paste("CIW, fixed n=", n, sep=""))
abline(h=0.95, col="grey", lty=3)
#axis(1, at=1:nrow(ciw), label=rownames(ciw))
#axis(2, label=TRUE)
colnames(ciw) <- gdata::trim(chartr("X", " ", colnames(ciw)))

plot(as.numeric(colnames(ciw)), ciw[p, ],  type="n", ylab="CIW", xlab=paste("Number of runs (with p =", p, ")"))

i <- 1
for (method in methods) {
	ciw <- as.matrix(read.table(paste("../cis/", method, "-ciw.dat", sep="")))
	colnames(ciw) <- gdata::trim(chartr("X", " ", colnames(ciw)))

	lines(as.numeric(colnames(ciw)), ciw[p, ], col=i, lty=i, lwd=2,ylab="XXX")
	i <- i+1
}

#title(main=paste("CIW, fixed p=", p, sep=""))
abline(h=0.95, col="grey", lty=3)
legend("topright", labels, col=1:length(methods), lty=1:length(methods))
#axis(1, at=1:ncol(ciw), label=colnames(ciw))
#axis(2, label=TRUE)

dev.copy2eps(file="cut-ciw.eps");

while (1) Sys.sleep(10)
q()
