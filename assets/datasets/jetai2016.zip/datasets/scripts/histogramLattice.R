#!/usr/bin/Rscript --vanilla

library(lattice)

# Shapiro-Wilk test of normality
# Muestra histograma con ajuste de normalidad
datasets <- c("../ant/k.dat", "../parity/k.dat", "../6-multiplexer/k.dat", "../regression/k.dat")
#datasets <- c("../parity/k.dat", "../parity/k.dat", "../parity/k.dat", "../parity/k.dat")
titles <- c("Artificial ant", "5-parity", "6-multiplexer", "Regression")
values <- c(30, 50, 100, 250, 500, 1000)
#values <- c(50)

print("OK")
#par(mfrow=c(4,length(values)), oma=c(3,2,0,0), mar=c(2,2.5,1.5,0), mgp=c(1.8, 1, 0))
par(mfrow=c(4,length(values)))
j <- 0

datos <- data.frame(dataset=NULL, n=NULL, labeln=NULL, k=NULL)

for (file in datasets) {
	print(file)

	runs <- read.table(file, header=FALSE)

	# Best estimation of p
	k <- sum(runs[nrow(runs), ])
	bestEstimation <- k / ncol(runs)
	print(paste("Best estimation = ",bestEstimation))

	for (N in values) {
		estimation <- NULL
		print(paste("Samples: ",  N))

		samples <- 2000
		for(i in 1:samples) {
			s <- sample(runs, N)
			s <- rowSums(s[nrow(s),]) # Sum number of ones in the last generation (k)
			datos <- rbind(datos, data.frame(dataset=titles[j+1], n=N,labeln=paste("n=", N, sep=""), k=s))
		}

		# Plot binomial distribution
		#estimation <- sort(estimation)
		#observed <- as.data.frame(table(estimation))
		#observed$k <- as.integer(observed$estimation)
		#observed$Freq <- as.integer(observed$Freq)
		#plot(observed)
		#hist(estimation, main=paste("n = ", samples), xlab="k")
		#rug(estimation)
		#binom <- rbinom(samples-1, N, bestEstimation)
		#expected <- as.data.frame(table(binom))
		#expected$k <- as.integer(expected$binom)
		#expected$Freq <- as.integer(expected$Freq)
		
		#points(dbinom(1:histo$breaks[length(histo$breaks)], N, bestEstimation), col="red", pch=20)
	}

	j <- j+1
}

#x11()
postscript(file="../../tex/figs/histogram.eps", colormodel="rgb-nogray", horizontal=FALSE, paper="special", width=11, height=7.5)

histogram(~ jitter(k) | labeln * dataset, data=datos,
	type="density", col="red", allow.multiple=TRUE,
	scales=list(relation="free"),
	xlab="Number of successes (k)", ylab="Density", breaks=NULL, cex=0.7,
	panel = function(x, subscripts, groups, ...) {
		probabilities <- c(0.13, 0.061, 0.956, 0.295)
		prob <- probabilities[floor((panel.number()-1)/length(values))+1]
		num  <- values[((panel.number()-1)%%length(values))+1]
        panel.histogram(x, ...) 
		print(paste("prob: ", prob, ", n: ", num, " pos: ", panel.number()))
	    #panel.mathdensity(dmath = dbinom, col = "black", args = list(size=10,prob=0.2)) 
		lpoints(0:num, dbinom(0:num, num, prob), col="black", pch=20)
    })
#dev.copy2eps(width=14, height=4, horizontal=TRUE, file="histogram.eps");
#dev.copy2eps(horizontal=FALSE, file="histogram.eps");
#while(1) Sys.sleep(10)
