#!/usr/bin/Rscript --vanilla

# Systematic CP and CIW for different values of K and N
# n stands for the number of trials while n stands for the
# number of successes.

#------- Parameters --------c
methods <- c("asymptotic", "exact", "agresti-coull", "wilson", "bayes")
labels <- c("Standard", "\"Exact\"", "Agresti-Coull", "Wilson", "Bayes")
labels <- c("Standard", "\"Exact\"", "Agresti-Coull", "Wilson", "Bayes")
npoints <- 200
ppoints <- 50
#----------------------------
	
x11()
#png(file="cp-ciw.png")

library(binom, verbose=FALSE)
library(fields, verbose=FALSE)

#par(mfrow=c(length(methods), 2), mar=c(1,2.5,1,0), oma=c(1,0,0,0), mgp=c(1.5, 0.5, 0))
par(oma=c(0,0,0,0), mgp=c(1.5, 0.5, 0), cex=2)  # margin of 4 spaces width at right hand side
set.panel(3,2) # 3X2 matrix of plots
par(mar=c(3,2.5,0.5,1))

p <- (1:ppoints-1)/(1*ppoints)
n <- 1:(npoints)

#persp(1:4, 1:5, cp)
j <- 1
for (method in methods) {
	ciw <- matrix(rep(NA, length(p)*length(n)), c(length(n), length(p)))
	
	pb <- txtProgressBar(min = 0, max = max(n), style = 3)
	for (i in n) {
#		print(i)
		setTxtProgressBar(pb, i)
		if (i < 51) {
			ciw[i,] <- binom.length(p=p, i, method=method, zlim=lim, conf.level = 0.95)$length/2
		} else {
			ciw[i,] <- binom.length(p=p, i, method=method, zlim=lim, conf.level = 0.95, tol=.Machine$double.eps^0.03)$length/2
		}
		close(pb)
	}
	
	#image.plot(p,n,t(cp), ylab=paste(labels[j], ": Runs (n)",sep=""), xlab="Success rate (p)")
	contour(p, n, t(ciw), xlab="Success rate (p)", ylim=c(30, npoints), ylab=paste(labels[j], ": Runs (n)",sep=""), nlevels=30, method="flattest")
	#image.plot(p,n,t(cp), ylab="Runs (n)", xlab="Success rate (p)", axes=TRUE)
	mtext(labels[i], side=2, line=2)
	j <- j+1
	#image.plot(p, n, cp, xlab="Probability (p)", ylab="Runs (n)", main=paste(labels[[i]], " CP", sep=""))
#	image.plot(p, n, ciw,
#		xlab="Probability (p)", ylab="Runs (n)", main=paste(labels[[i]], " CIW", sep=""))
}

#par(oma=c(0,0,0,0), mgp=c(0, 0, 0))
#image.plot(p,n, zlim=c(0.85,1), legend.only=TRUE, horizontal=TRUE, legend.mar=7)

dev.copy2eps(file="ciw-95.eps", width=18, paper="special", fonts="ComputerModern");

while (1) Sys.sleep(10)
