#!/usr/bin/Rscript --vanilla

# Systematic CP and CIW for different values of K and N
# n stands for the number of trials while n stands for the
# number of successes.

library(boot, verbose=FALSE)
library(binom, verbose=FALSE)

args <- commandArgs(TRUE)

x11()
par(mar=c(1,2,0,0))
#par(mfrow=c(1,2), mar=c(1,1,0,1))
#cp <- matrix(1:20, c(4,5))

#persp(1:4, 1:5, cp)

cp <- as.matrix(read.table("../cis/asymptotic-cp.dat", sep=""))
ciw <- as.matrix(read.table("../cis/asymptotic-ciw.dat", sep=""))
	
print(cp)

colnames(cp) <- gdata::trim(chartr("X", " ", colnames(cp)))
colnames(ciw) <- gdata::trim(chartr("X", " ", colnames(ciw)))
	
cp[cp == 0] <- NA
ciw[ciw == 0] <- NA
cp[cp == Inf] <- NA
ciw[ciw == Inf] <- NA
cp[cp == -Inf] <- NA
ciw[ciw == -Inf] <- NA
cp[cp < 0] <- NA
ciw[ciw < 0] <- NA

persp(as.numeric(rownames(ciw)), as.numeric(chartr("X", " ", colnames(ciw))), ciw, 
			theta = 120, phi = 45,
			xlab="Probability (p)", ylab="Number of trials (n)", zlab="CIW",
			ticktype = "detailed")
dev.copy2eps(file="ciw-3d.eps");

dev.new()
x11()
par(mar=c(1,2,0,0))
persp(as.numeric(rownames(cp)), as.numeric(chartr("X", " ", colnames(cp))), cp, 
			theta = 120, phi = 45,
			xlab="Probability (p)", ylab="Number of trials (n)", zlab="CP",
			ticktype = "detailed")
dev.copy2eps(file="cp-3d.eps");

while (1) Sys.sleep(10)
q()
