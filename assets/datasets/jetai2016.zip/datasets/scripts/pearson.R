#!/usr/bin/Rscript --vanilla

# Shapiro-Wilk test of normality
# Muestra histograma con ajuste de normalidad

#runs <- read.table("../ant/k.dat", header=FALSE)
runs <- read.table("../parity/k.dat", header=FALSE)
print("Tabla leida")

# Best estimation of p
k <- sum(runs[nrow(runs), ])
bestEstimation <- k / ncol(runs)
print(paste("Best estimation = ",bestEstimation))

print("X cerca de 1 indica que el modelo es bueno, si X >> 1, el modelo es malo, y si X < 1 el modelo esta overfitting")
	
values <- c(15, 30, 50, 100, 250, 500, 1000)

for (N in values) {
	print(paste("Samples: ",  N))
	print("")

	resamples <- 1000
	resamples <- 100
	samples <- 100
	p <- matrix(c(1, 100))
	pb <- txtProgressBar(min=0, max=samples, style=3)

	for (j in 1:samples) {
		estimation <- NULL
		expectation <- NULL
		setTxtProgressBar(pb, j)
		# Resample to get observed frecuencies
		for(i in 1:resamples) {
			s <- sample(runs, N, replace=TRUE)
			s <- rowSums(s[nrow(s),]) # Sum number of ones in the last generation (k)
			estimation[i] <- s
		}

		#estimation <- sort(estimation)
		observed <- as.data.frame(table(estimation))
		observed$k <- as.integer(observed$estimation)
		observed$Freq <- as.integer(observed$Freq)

		binom <- rbinom(resamples, N, bestEstimation)
		expected <- as.data.frame(table(binom))
		expected$k <- as.integer(expected$binom)
		expected$Freq <- as.integer(expected$Freq)

		# Equal number of observations and expected
		#print("")
		#print("\n--- Chi test ---")
		#print(paste("Rango observado: "))
		#print(observed$k)
		#print(observed$Freq)
		#print(paste("Rango esperado: "))
		#print(expected$k)
		#print(expected$Freq)
	
		# We use vector to avoid some problems with dataframes
		fObserved <- observed$Freq
		iObserved <- observed$k
		fExpected <- expected$Freq
		iExpected <- expected$k
		#print(paste("Observados: ", sum(fObserved), " Esperados: ", sum(fExpected)))
	
		# Check expected categories with less than 5 elements
		# First elements
		while (fExpected[1] < 5) {
			fExpected[2] <- fExpected[1] + fExpected[2]
			fObserved[2] <- fObserved[1] + fObserved[2]
			fExpected <- fExpected[2:length(fExpected)]
			iExpected <- iExpected[2:length(iExpected)]
			fObserved <- fObserved[2:length(fObserved)]
			iObserved <- iObserved[2:length(iObserved)]
		}

		# Adjust aggregated sample sized, otherwise chisq.test() fails
		# samples must be truncated since chisq.test() does not admit
		# either zero valued samples neither NAs
		while (max(iObserved) > max(iExpected)) {
			fObserved[length(fObserved)-1] <- fObserved[length(fObserved)] + fObserved[length(fObserved)-1]
			fObserved <- fObserved[1:length(fObserved)-1]
			iObserved <- iObserved[1:length(iObserved)-1]
		}

		while (max(iExpected) > max(iObserved)) {
			fExpected[length(fExpected)-1] <- fExpected[length(fExpected)] + fExpected[length(fExpected)-1]
			fExpected <- fExpected[1:length(fExpected)-1]
			iExpected <- iExpected[1:length(iExpected)-1]
		}

		# Last elements
		while (fExpected[length(fExpected)] < 5) {
			fExpected[length(fExpected)-1] <- fExpected[length(fExpected)] + fExpected[length(fExpected)-1]
			fObserved[length(fExpected)-1] <- fObserved[length(fExpected)] + fObserved[length(fExpected)-1]
			fExpected <- fExpected[1:length(fExpected)-1]
			iExpected <- iExpected[1:length(iExpected)-1]
			fObserved <- fObserved[1:length(fObserved)-1]
			iObserved <- iObserved[1:length(iObserved)-1]
		}
		#print(paste("Observados: ", sum(fObserved), " Esperados: ", sum(fExpected)))

		#print("Observed")
		#print(iObserved)
		#print(fObserved)
		#print("Expected")
		#print(iExpected)
		#print(fExpected)

		# ... and here we go!
		est <- chisq.test(fObserved, fExpected)
		#print(paste("p-value: ", est$p.value))
		p[j] <- est$p.value
		#print(paste("df: ", est$parameter))
		#print(paste("CHI 0.99: ", qchisq(0.99, df=length(kObserved)-2)))
		#print(paste("CHI 0.999: ", qchisq(0.999, df=length(kObserved)-2)))
		#print(est)
	}
	close(pb)
	print(paste("Mean: ", sum(p)/length(p)))
	print(paste("Std: ", sd(p)))
}
