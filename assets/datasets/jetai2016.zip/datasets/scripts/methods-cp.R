#!/usr/bin/Rscript --vanilla

# Given N, it plots a detailed graph of each method's CP

#------- Parameters --------
methods <- c("wilson", "exact", "asymptotic", "bayes", "agresti-coull")
labels <- c("Wilson", "\"Exact\"", "Standard", "Bayes", "Agresti-Coull")
methods <- c("wilson", "exact", "asymptotic", "agresti-coull")
labels <- c("Wilson", "\"Exact\"", "Standard", "Agresti-Coull")
#----------------------------
	
# Initial stuff
library(boot, verbose=FALSE)
library(binom, verbose=FALSE)

args <- commandArgs(TRUE)

if (length(args) != 2) {
	print("Incorrect number of arguments")
	print("SYNTAX: CI-cut.R probability n")
	q()
}

p <- args[1]
n <- args[2]

x11()
#postscript("Rplots.eps", paper="a4", horizontal=FALSE, height=5, width=4)

# Let's begin to plot
#par(mfrow=c(2, 3), mar=c(3,3,2,1), oma=c(0,0,0,0), mgp=c(2, 1, 0))
par(mfrow=c(2, 2), mar=c(3,3,2,1), oma=c(0,0,0,0), mgp=c(2, 1, 0), cex=1.2)

# Read "asymptotic" because it is the most conservative choice
cp <- as.matrix(read.table(paste("../cis/asymptotic", "-cp.dat", sep="")))

# Chech if arguments are contained in the dataset
if (! p %in% rownames(cp)) {
	print(paste("Given probability not present in the dataset. ", p))
	q()
}

colnames(cp) <- gdata::trim(chartr("X", " ", colnames(cp)))
if (! n %in% colnames(cp)) {
	print("Given number of samples not present in the dataset")
	q()
}

cp <- as.matrix(read.table(paste("../cis/asymptotic", "-cp.dat", sep="")))
colnames(cp) <- gdata::trim(chartr("X", " ", colnames(cp)))

i <- 1
for (method in methods) {
	plot(as.numeric(rownames(cp)), cp[, n], ylim=c(0.85, 1), type="n", ylab="CP", xlab=paste("p"), axis=FALSE, main=labels[i], lwd=0.05)

	cp <- as.matrix(read.table(paste("../cis/", method, "-cp.dat", sep="")))
	colnames(cp) <- gdata::trim(chartr("X", " ", colnames(cp)))

	lines(as.numeric(rownames(cp)), cp[, n])
	abline(h=0.95, col="lightgrey")

	i <- i+1
}

#x11()
#dev.new(file="methods-cp-n.eps")
# Fixed p, variable n
#plot(as.numeric(colnames(cp)), cp[p, ], ylim=range(0.8, 1), type="n", ylab="CI coverage", xlab=paste("Samples, P=", p))

#i <- 1
#for (method in methods) {
#	cp <- as.matrix(read.table(paste("../cis/", method, "-cp.dat", sep="")))
#	ciw <- as.matrix(read.table(paste("../cis/", method, "-ciw.dat", sep="")))
#	colnames(cp) <- gdata::trim(chartr("X", " ", colnames(cp)))

#	lines(as.numeric(colnames(cp)),cp[p, ], col=i, lty=i)
#	i <- i+1
#}
#abline(h=0.95, col="grey", lty=3)
#title(main=paste("CP, fixed p=", p, sep=""))

#dev.copy2eps(file="methods-cp-n.eps")

# -------- CIW ---------
#dev.new(file="methods-ciw.eps")
#x11()
#ciw <- as.matrix(read.table(paste("../cis/asymptotic-ciw.dat", sep="")))
#par(mfrow=c(2, 1), mar=c(2,2,2,1), oma=c(0,0,0,0))
#colnames(ciw) <- gdata::trim(chartr("X", " ", colnames(ciw)))

#plot(as.numeric(rownames(ciw)), ciw[, n]+0.01,  type="n", ylab="CI coverage", xlab=paste("Probability, N=", n))

#i <- 1
#for (method in methods) {
#	ciw <- as.matrix(read.table(paste("../cis/", method, "-ciw.dat", sep="")))
#	colnames(ciw) <- gdata::trim(chartr("X", " ", colnames(ciw)))
#	lines(as.numeric(rownames(ciw)), ciw[, n], col=i, lty=i)
#	i <- i+1
#}

#title(main=paste("CIW, fixed n=", n, sep=""))
#abline(h=0.95, col="grey", lty=3)
#axis(1, at=1:nrow(ciw), label=rownames(ciw))
#axis(2, label=TRUE)
#colnames(ciw) <- gdata::trim(chartr("X", " ", colnames(ciw)))

#plot(as.numeric(colnames(ciw)), ciw[p, ],  type="n", ylab="CI coverage", xlab=paste("Samples, P=", p))

#i <- 1
#for (method in methods) {
#	ciw <- as.matrix(read.table(paste("../cis/", method, "-ciw.dat", sep="")))
#	colnames(ciw) <- gdata::trim(chartr("X", " ", colnames(ciw)))

#	lines(as.numeric(colnames(ciw)), ciw[p, ], col=i, lty=i, ylab="XXX")
#	i <- i+1
#}

#title(main=paste("CIW, fixed p=", p, sep=""))
#abline(h=0.95, col="grey", lty=3)
#legend("topright", labels, col=1:length(methods), lty=1:length(methods))

dev.copy2eps(file="methods-cp-p.eps", width=18, height=6, paper="special",  fonts="ComputerModern");
while (1) Sys.sleep(10)
