#!/usr/bin/Rscript --vanilla

# Systematic CP and CIW for different values of K and N
# n stands for the number of trials while n stands for the
# number of successes.

#------- Parameters --------c
methods <- c("asymptotic", "exact", "agresti-coull", "wilson", "bayes")
labels <- c("Standard", "\"Exact\"", "Agresti-Coull", "Wilson", "Bayes")
labels <- c("Standard", "\"Exact\"", "Agresti-Coull", "Wilson")
methods <- c("asymptotic", "exact", "agresti-coull", "wilson")
#methods <- c("wilson")
npoints <- 200
ppoints <- 2000
#----------------------------
	
#png(file="cp.png")

library(binom, verbose=FALSE)
library(lattice, verbose=FALSE)

#par(mfrow=c(length(methods), 2), mar=c(1,2.5,1,0), oma=c(1,0,0,0), mgp=c(1.5, 0.5, 0))
p <- (1:ppoints-1)/(ppoints)
n <- 1:npoints

data <- data.frame(p=NULL,n=NULL,method=NULL,cp=NULL)

#persp(1:4, 1:5, cp)
for (method in methods) {
	print(method)
	
	if (method == "asymptotic") label <- "Standard"
	else if (method == "exact") label <- "\"Exact\""
	else if (method == "agresti-coull") label <- "Agresti-Coull"
	else if (method == "wilson") label <- "Wilson"

	for (i in n) {
		cp <- NULL
		lim <- c(0.85, 1)
		#if (method != "asymptotic") {
		#	lim <- c(0,1)
		#	cp[cp<0.85] <- NA
		#}
		print(i)
		cp <- binom.coverage(p=p, i, method=method, zlim=lim)$coverage
		cp[cp<0.85] <- NA
		data <- rbind(data, data.frame(p=p, n=i, method=label, cp=cp))
	}
}
print(p)

save(data,file="cp-2d.dat", compress=TRUE)

#par(oma=c(0,0,0,0), mgp=c(0, 0, 0))
#image.plot(p,n, zlim=c(0.85,1), legend.only=TRUE, horizontal=TRUE, legend.mar=7)

#dev.copy2eps(file="cp-ciw.eps", width=18, paper="special", fonts="ComputerModern");
