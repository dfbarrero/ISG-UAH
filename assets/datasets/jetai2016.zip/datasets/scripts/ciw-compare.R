#!/usr/bin/Rscript --vanilla

methods <- c("wilson", "exact", "asymptotic", "agresti-coull", "bayes")
labels <- c("Wilson", "\"Exact\"", "Standard", "Agresti", "Bayes")
titles <- c("Artificial ant", "6-multiplexer", "4-parity", "Regression")
methods <- c("wilson", "exact", "asymptotic", "agresti-coull")
labels <- c("Wilson", "\"Exact\"", "Standard", "Agresti")
values <- 5:100
lim <- 0 

mystat <- function(data, index) {
	data = t(data)
	#print(index)
	d <- data[, index]
	
	# P is a column vector
	P <-rowSums(d) / length(index)
	return(P[length(P)])
}

library(boot, verbose=FALSE)
#library(Hmisc, verbose=FALSE)
library(binom, verbose=FALSE)

x11()
# mgp=(label, letrero eje,ejes)
par(mfrow=c(2, 4), mar=c(3.1,3.1,1.6,0.6), oma=c(1,0,0,0), mgp=c(1.8, 1, 0), cex=1.1)
title <- 0

for (file in c("../ant/k.dat", "../6-multiplexer/k.dat", "../parity/k.dat", "../regression/k.dat")) {
	runs <- read.table(file, header=FALSE)
	k <- sum(runs[nrow(runs), ])
	bestEstimator <- k / ncol(runs)
	print(paste("K=", k, ", N=", ncol(runs), "Best P =", bestEstimator))

	print ("---- Interval coverage -----")
	final <- list()
	
	wMin <- 9999999
	wMax <- 0
	covMin <- 9999999
	covMax <- 0
	j <- 1
	title <- title+1

	for (N in values) {
		estimation <- NULL
		run <- list()
		bad <- 0
	
		# Init results
		for (method in methods) {
			run[[method]] <- list(cov=0, w=0)
		}
	
		print(paste("-------- Samples: ",  N, " ----------"))
		samples <- 100
		for(i in 1:samples) {
			s <- sample(runs, N)
			s <- rowSums(s[nrow(s),])
	
			if (file == "../6-multiplexer/k.dat") {
				est <- binom.confint(s, N, tol=.Machine$double.eps^0.5, maxit=5000)
			} else {
				est <- binom.confint(s, N, tol=.Machine$double.eps^0.1, maxit=5000)
			}
	
			for (method in methods) {
				ci <- est[est==method, ]
		
				if (nrow(ci) != 0) {
				if ((bestEstimator > ci$lower) && (bestEstimator < ci$upper)) {
						run[[method]]$cov <- run[[method]]$cov + 1
					}
					run[[method]]$w <- run[[method]]$w + (ci$upper - ci$lower)
				} else if (method == "bayes") {
					# There was a convergence problem with Bayes, do nothing
					bad <- bad + 1
				} else {
				print("Error")
				q()
				}
			}
		}
	
	for (method in methods) {
		cp <- run[[method]]$cov/samples
		ciw <- run[[method]]$w/samples
		
		if (method == "bayes") {
			cp <- run[[method]]$cov/(samples - bad)
			ciw <- run[[method]]$w/(samples - bad)
			print(bad)
		}

		final[[method]]$coverage[j] <- cp
		final[[method]]$width[j] <- ciw
		

		# Find range to plot
		if (cp < covMin) {
			covMin<- cp
		}
		if (cp > covMax) {
			covMax <- cp
		}
		if (ciw < wMin) {
			wMin<- ciw
		}
		if (ciw> wMax) {
			wMax <- ciw
		}


		print(paste(method, ", coverage: ", cp, " width: ", ciw))
	}
	j <- j+1
	}

	print(final)
	temp <- NULL
	legend <- NULL
	col <- NULL
	k<-2

	#plot(final[["wilson"]]$width,  type="n", col="blue", axes=FALSE, main=paste(titles[title]), ylim=c(wMin, wMax), ylab="CIW", xlab="Number of runs")
	plot(final[["wilson"]]$width,  type="n", col="blue", axes=FALSE, main=paste(titles[title]), ylim=c(0.05, 0.3), ylab="CIW", xlab="Number of runs (n)")
	for (method in methods) {
		#col[i] <- k
		#legend[i] <- method
		lines(final[[method]]$width, col=k, lty=k)
		k <- k+1
	}

	if (title == 1) {
		legend("bottomleft", labels, col=2:k, lty=2:k, cex=1)
	}

	#legend("topright", legend, col=col, lty=col)
	abline(h=0.95, col="grey", lty=3)
	axis(1, at=1:length(values), label=values)
	axis(2, label=TRUE)
	box()
}

#------- Parameters --------
probs <- c(0.13168, 0.95629, 0.061, 0.29462)
#----------------------------

# Initial stuff
library(boot, verbose=FALSE)
library(binom, verbose=FALSE)

for (p in probs) {
	# Read "asymptotic" because it is the most conservative choice
	#ciw <- as.matrix(read.table(paste("../cis/wilson", "-cp.dat", sep="")))
	#colnames(ciw) <- gdata::trim(chartr("X", " ", colnames(ciw)))

	# Fixed p, variable n
	#plot(as.numeric(colnames(ciw)), ciw[p,0:50 ], type="n", ylim=c(wMin, wMax), ylab="CIW", xlab=paste("Number of runs"))
	plot(values, 0*values, type="n", ylim=c(0.05, 0.3), ylab="CIW", xlab=paste("Number of runs (n)"))
print(p)
	k <- 2
	for (method in methods) {
		if (method == "bayes") {
			ciw <- c(binom.length(p, 5:49, method=method)$length, binom.length(p, 50:99, method=method, tol=.Machine$double.eps^0.047775)$length)
		} else {
			ciw <- binom.length(p, values, method=method)$length
		}
		print(length(ciw))
		print(ciw)
		lines(ciw, col=k, lty=k)
		k <- k + 1
		ciw <- NULL
	}
	abline(h=0.95, col="grey", lty=3)
	title(main=paste("p=", p, sep=""))
}

dev.copy2eps(file="ciw-compare.eps", width=16, height=8, paper="special", fonts="ComputerModern");
while (1) Sys.sleep(10)
