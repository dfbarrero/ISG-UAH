#!/usr/bin/Rscript --vanilla

# Shapiro-Wilk test of normality
# Muestra histograma con ajuste de normalidad
datasets <- c("../ant/k.dat", "../parity/k.dat", "../6-multiplexer/k.dat", "../regression/k.dat")
datasets <- c("../parity/k.dat", "../parity/k.dat", "../parity/k.dat", "../parity/k.dat")
titles <- c("Artificial ant", "5-parity", "6-multiplexer", "Regression")
values <- c(5, 15, 30, 50, 100, 250, 500, 1000)

#x11(width=6.3in, height=3.9in)
postscript(file="../../tex/figs/histogram.eps", horizontal=FALSE, paper="special", width=11, height=7)
print("OK")
par(mfrow=c(4,length(values)), oma=c(3,2,0,0), mar=c(2,2.5,1.5,0), mgp=c(1.8, 1, 0))
j <- 0

for (file in datasets) {
	runs <- read.table(file, header=FALSE)

	# Best estimation of p
	k <- sum(runs[nrow(runs), ])
	bestEstimation <- k / ncol(runs)
	print(paste("Best estimation = ",bestEstimation))

	for (N in values) {
		estimation <- NULL
		print(paste("Samples: ",  N))

		samples <- 2000
		samples <- 20
		for(i in 1:samples) {
			s <- sample(runs, N)
			s <- rowSums(s[nrow(s),]) # Sum number of ones in the last generation (k)
			estimation[i] <- s
		}

		# Plot binomial distribution
		#estimation <- sort(estimation)
		#observed <- as.data.frame(table(estimation))
		#observed$k <- as.integer(observed$estimation)
		#observed$Freq <- as.integer(observed$Freq)
		#plot(observed)
		#hist(estimation, main=paste("n = ", samples), xlab="k")
		#rug(estimation)
		#binom <- rbinom(samples-1, N, bestEstimation)
		#expected <- as.data.frame(table(binom))
		#expected$k <- as.integer(expected$binom)
		#expected$Freq <- as.integer(expected$Freq)
		
		if (j == 0) {
			# First line
			if (N == values[1]) {
				# First column
				histo <- hist(estimation, main=paste("n=", N),freq=FALSE, xlab="", breaks=6)
				mtext(titles[j+1], side=2, outer=FALSE, line=3)
	#			lines(dbinom(1:histo$breaks[length(histo$breaks)], N, bestEstimation), col="red")
			} else {
				histo <- hist(estimation, main=paste("n=", N),freq=FALSE, xlab="", ylab="", breaks=9)
	#			lines(dbinom(1:histo$breaks[length(histo$breaks)], N, bestEstimation), col="red")
			}
		} else if (j == length(datasets)){
			# Last line
			if (N == values[1]) {
				# First column
				histo <- hist(estimation, main="",freq=FALSE, xlab="k", breaks=6)
	#			lines(dbinom(1:50, N, bestEstimation), col="red")
				mtext(titles[j+1], side=2, outer=FALSE, line=3)
			} else {
				histo <- hist(estimation, main="",freq=FALSE, xlab="k", ylab="", breaks=9)
	#			lines(dbinom(1:50, N, bestEstimation), col="red")
			}
			# Last line
#			hist(estimation, main="",freq=FALSE, xlab="k")
#			lines(dbinom(1:50, N, bestEstimation), col="red")
		} else {
			if (N == values[1]) {
				# First column
				histo <- hist(estimation, main="",freq=FALSE, xlab="", breaks=6)
	#			lines(dbinom(1:50, N, bestEstimation), col="red")
				mtext(titles[j+1], side=2, outer=FALSE, line=3)
			} else {
				histo <- hist(estimation, main="",freq=FALSE, xlab="", ylab="", breaks=9)
	#			lines(dbinom(1:50, N, bestEstimation), col="red")
			}
		}
		points(dbinom(1:histo$breaks[length(histo$breaks)], N, bestEstimation), col="red", pch=20)
	}


	j <- j+1
}

#dev.copy2eps(width=14, height=4, horizontal=TRUE, file="histogram.eps");
#dev.copy2eps(horizontal=FALSE, file="histogram.eps");
#while(1) Sys.sleep(10)
