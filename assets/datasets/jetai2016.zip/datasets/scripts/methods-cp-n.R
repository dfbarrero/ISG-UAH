#!/usr/bin/Rscript --vanilla

# Given N, it plots a detailed graph of each method's CP

#------- Parameters --------
methods <- c("wilson", "exact", "asymptotic", "bayes", "agresti-coull")
labels <- c("Wilson CP", "\"Exact\" CP", "Standard CP", "Bayes CP", "Agresti-Coull CP")
methods <- c("wilson", "exact", "asymptotic", "agresti-coull")
labels <- c("Wilson CP", "\"Exact\" CP", "Standard CP", "Agresti-Coull CP")
runs <- c(20, 50, 100, 500)
#----------------------------
	
# Initial stuff
library(binom, verbose=FALSE)
library(lattice)

args <- commandArgs(TRUE)

x11()

#par(mfcol=c(length(methods), length(runs)), mar=c(1,0.05,0,0), oma=c(1,3,2,0), mgp=c(2, 1, 0))
par(mfcol=c(length(methods), length(runs)), mar=c(1,0.7,0,0), oma=c(3,3,2,0.2), mgp=c(2, 1, 0), cex=1.2)
cov <- data.frame()

for (run in runs) {
	i <- 1
	for (method in methods) {
		coverage <- if (run < 50) {
			binom.coverage(n=run, method=method)$coverage
		} else {
			binom.coverage(n=run, method=method, tol=.Machine$double.eps^0.01)$coverage
		}
		
		plot((1:length(coverage))/length(coverage), coverage, type="l", ylim=c(0.85, 1), col="black", axes=FALSE)
		#plot((1:length(coverage))/length(coverage), coverage, type="h", ylim=c(0.85, 1), col="black", axes=FALSE, add=TRUE)
		box()
		abline(h=0.95, col="lightgrey")

		if (run == runs[1]) {
			# First column
			mtext(labels[i], side=2, outer=FALSE, line=2, cex=1.5)
			axis(2)
		} 
		
		if (method == methods[1]) {
			# First row
			mtext(paste("n=", run), side=3, outer=FALSE, line=0, cex=1.5)
		}

		if (method == methods[length(methods)]) {
			# First row
			axis(1)
			mtext("p", side=1, outer=FALSE, line=2, cex=1.5)
		}
		i <- i+1
	}
}


dev.copy2eps(file="methods-cp-n.eps", width=18, height=15, paper="special");
#while (1) Sys.sleep(10)
