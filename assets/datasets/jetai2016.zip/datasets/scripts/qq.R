#!/usr/bin/Rscript --vanilla

library(MASS)

N <- 2000
datasets <- c("../ant/k.dat", "../6-multiplexer/k.dat", "../parity/k.dat", "../regression/k.dat")
texts<- c("Santa Fe trail Q-Q Plot", "6-multiplexer Q-Q Plot", "5-parity Q-Q Plot", "Regression Q-Q Plot")
# QQ plot against binomial of all datasets
print(texts[1])
x11()

par(mfrow=c(2,2))#, oma=c(0,0,0,0), omi=c(0,0,0,0), mgp=c(1.8, 1, 0))
j <- 1

for (dataset in datasets) {
	print(paste("Dataset: ", dataset))
	runs <- read.table(dataset, header=FALSE)
	lab <- texts[j]
	k <- sum(runs[nrow(runs), ])
	bestEstimator <- k / ncol(runs)

	estimation <- NULL

	for(i in 1:N) {
		s <- sample(runs, N)
		s <- rowSums(s[nrow(s),])
		#estimation[i] <- s/N
		estimation[i] <- s
	}
	print(paste("Best estimation: ", bestEstimator))
	binom <- rbinom(length(estimation), N, bestEstimator)

	qqplot(estimation, binom, main=lab, xlab="Theoretical Quantiles", ylab="Sample Quantiles")
	qqline(binom)

	# Binomialidad
	est <- chisq.test(x=estimation, y=rbinom(n=length(estimation), N, bestEstimator))
	print(est)

	j <- j+1
}

dev.copy2eps(file="qq.eps");
while (1) Sys.sleep(10)
