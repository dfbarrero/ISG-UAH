#!/usr/bin/Rscript --vanilla

# Systematic CP and CIW for different values of K and N
# n stands for the number of trials while n stands for the
# number of successes.

#------- Parameters --------c
methods <- c("asymptotic", "exact", "agresti-Coull", "wilson", "bayes")
labels <- c("Standard", "\"Exact\"", "Agresti-Coull", "Wilson", "Bayes")
methods <- c("asymptotic", "exact", "agresti-Coull", "wilson")
labels <- c("Standard", "\"Exact\"", "Agresti-Coull", "Wilson")
#----------------------------
	
x11()
#png(file="cp-ciw.png")

library(boot, verbose=FALSE)
library(binom, verbose=FALSE)
library(fields, verbose=FALSE)

args <- commandArgs(TRUE)

par(mfrow=c(2, 2), mar=c(2.5,2.5,2,2), oma=c(0,0,0,0), mgp=c(1.5, 0.5, 0))
#cp <- matrix(1:20, c(4,5))

#persp(1:4, 1:5, cp)
i <- 1
for (method in methods) {
	filecp <- paste("../cis/", method, "-cp.dat", sep="")
	fileciw <- paste("../cis/", method, "-ciw.dat", sep="")
	print(file)
	cp <- as.matrix(read.table(filecp))
	ciw <- as.matrix(read.table(fileciw))
	
	colnames(cp) <- gdata::trim(chartr("X", " ", colnames(cp)))
	colnames(ciw) <- gdata::trim(chartr("X", " ", colnames(ciw)))
	
	cp[cp == 0] <- NA
	#ciw[ciw == 0] <- NA
	cp[cp == Inf] <- NA
	ciw[ciw == Inf] <- NA
	cp[cp == -Inf] <- NA
	ciw[ciw == -Inf] <- NA
	cp[cp > 1] <- NA
	cp[cp < 0] <- NA
	ciw[ciw > 1] <- NA
	ciw[ciw < 0] <- NA
	
	if (method == "bayes") {
		ciw[ciw > 0.9] <- NA
	}

	if (method != "bayes") {
		image.plot(as.numeric(rownames(cp)), as.numeric(chartr("X", " ", colnames(cp))), cp,
			xlab="Probability (p)", ylab="Runs (n)", main=paste(labels[[i]], " CP", sep=""))
	#contour(as.numeric(rownames(ciw)), as.numeric(chartr("X", " ", colnames(ciw))), ciw, nlevels=10,
	#	xlab="P", ylab="N")
		#image.plot(as.numeric(rownames(ciw)), as.numeric(chartr("X", " ", colnames(ciw))), ciw,
		#	xlab="Probability (p)", ylab="Runs (n)", main=paste(labels[[i]], " CIW", sep=""))
	} else {
		image.plot(as.numeric(rownames(cp)), as.numeric(chartr("X", " ", colnames(cp))), cp,
			xlab="Probability (p)", ylab="Runs (n)", main=paste(labels[[i]], " CP", sep=""), legend.mar=0, legend.shrink = 1)
	#contour(as.numeric(rownames(ciw)), as.numeric(chartr("X", " ", colnames(ciw))), ciw, nlevels=10,
	#	xlab="P", ylab="N")
		#image.plot(as.numeric(rownames(ciw)), as.numeric(chartr("X", " ", colnames(ciw))), ciw,
		#	xlab="Probability (p)", ylab="Runs (n)", main=paste(labels[[i]], " CIW", sep=""))
	}

	i <- i+1
#		contour(as.numeric(rownames(cp)), as.numeric(chartr("X", " ", colnames(cp))), cp, nlevels=5,
#			xlab="P", ylab="N", add=TRUE, col="peru")
}
#par(mfrow=c(1,1))
#title(main="Wilson CI width")

dev.copy2eps(file="cp-ciw.eps");
while (1) Sys.sleep(10)
