/*
  Copyright 2006 by Sean Luke
  Licensed under the Academic Free License version 3.0
  See the file "LICENSE" for more information
*/

package uah.regex.gp.stats;

import java.io.File;
import java.io.IOException;

import ec.*;
import ec.gp.*;
import ec.gp.koza.KozaFitness;

import uah.regex.gp.GPRegexIndividual;
import uah.regex.gp.problem.GPRegexProblem;

import ec.util.*;

@SuppressWarnings("serial")
public class GPRegexFinalStatistics extends Statistics {
	private Individual best_of_run_a[];
	public int statisticslog;
	public static final String P_STATISTICS_FILE = "file";
	public static final String P_COMPRESS = "gzip";
	
	public void setup(final EvolutionState state, final Parameter base) {
		super.setup(state, base);
		File statisticsFile = state.parameters.getFile(base
				.push(P_STATISTICS_FILE), null);

		if (statisticsFile != null)
			try {
				statisticslog = state.output.addLog(statisticsFile,
						Output.V_NO_GENERAL - 1, false,
						!state.parameters.getBoolean(base.push(P_COMPRESS),
								null, false), state.parameters.getBoolean(base
								.push(P_COMPRESS), null, false));
			} catch (IOException i) {
				state.output
						.fatal("An IOException occurred while trying to create the log "
								+ statisticsFile + ":\n" + i);
			}
	}
	
	public void postInitializationStatistics(final EvolutionState state) {
		// set up our best_of_run array -- can't do this in setup, because
		// we don't know if the number of subpopulations has been determined yet
		best_of_run_a = new Individual[state.population.subpops.length];
	}

	/**
	 * Prints out the statistics, but does not end with a println -- this lets
	 * overriding methods print additional statistics on the same line
	 */
	protected void _postEvaluationStatistics(final EvolutionState state) {
		Individual[] best_i = new Individual[state.population.subpops.length];

		for (int x = 0; x < state.population.subpops.length; x++) {
			if (!(state.population.subpops[x].species.f_prototype instanceof KozaFitness))
				state.output
						.fatal("Subpopulation "
								+ x
								+ " is not of the fitness KozaFitness.  Cannot do timing statistics with KozaStatistics.");

			best_i[x] = null;
			for (int y = 0; y < state.population.subpops[x].individuals.length; y++) {
				// best individual
				if (best_i[x] == null
						|| state.population.subpops[x].individuals[y].fitness
								.betterThan(best_i[x].fitness))
					best_i[x] = state.population.subpops[x].individuals[y];
			}

			// now test to see if it's the new best_of_run_a[x]
			if (best_of_run_a[x] == null
					|| best_i[x].fitness.betterThan(best_of_run_a[x].fitness))
				best_of_run_a[x] = best_i[x];

		}
	}
	
    public void postBreedingStatistics(final EvolutionState state) {}

	public void postEvaluationStatistics(final EvolutionState state) {
		_postEvaluationStatistics(state);
		// state.output.println("",Output.V_NO_GENERAL, statisticslog);
	}

	public void finalStatistics(final EvolutionState state, int result) {
		// Delete this line in case it has to be processed by Octave

		GPRegexProblem problem = (GPRegexProblem) state.evaluator.p_problem;
		if (!problem.ideal) {
			// Print FAILURE and the best regex so far
			// We do not consider subpopulations, so we take the first one
			state.output.print("FAILURE ", Output.V_NO_GENERAL, statisticslog);
		} 
		//else
		//	state.output.print("#evaluations raw adjusted hits size regex\n",
		//			Output.V_NO_GENERAL, statisticslog);

		printBestIndividual(state);
		problem.reset();
	}

	private void printBestIndividual(EvolutionState state) {
		// We print the best individual because Koza does not introduce elitism
		GPRegexProblem problem = (GPRegexProblem) state.evaluator.p_problem;

		// Evaluations
		state.output.print(problem.evaluations + " ", Output.V_NO_GENERAL,
				statisticslog);

		for (int x = 0; x < state.population.subpops.length; x++) {
			state.output.print(""
					+ String.format("%.4g",
							((KozaFitness) (best_of_run_a[x].fitness))
									.rawFitness())
					+ " "
					+ String.format("%.4g",
							((KozaFitness) (best_of_run_a[x].fitness))
									.adjustedFitness())
					+ " "
					+ ((KozaFitness) (best_of_run_a[x].fitness)).hits
					+ " "
					+ ((GPIndividual) best_of_run_a[x]).size()
					+ " "
					+ ((GPRegexIndividual) best_of_run_a[x]).regex + "\n", Output.V_NO_GENERAL,
					statisticslog);
		}
	}
}
