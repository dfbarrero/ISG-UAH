/*
  Copyright 2006 by Sean Luke
  Licensed under the Academic Free License version 3.0
  See the file "LICENSE" for more information
*/


package uah.regex.gp.nodes;

import uah.regex.gp.RegexData;
import ec.*;
import ec.gp.*;
import ec.util.*;

@SuppressWarnings("serial")
public abstract class Terminal extends RegexNode {
	public static final String P_SYMBOL = "symbol";
	
	protected String symbol;

	public void setup(EvolutionState state, Parameter base) {
		super.setup(state, base);
	}

	public void checkConstraints(final EvolutionState state, final int tree,
			final GPIndividual typicalIndividual, final Parameter individualBase) {
		super.checkConstraints(state, tree, typicalIndividual, individualBase);
		if (children.length != 0)
			state.output.error("Incorrect number of children for node "
					+ toStringForError() + " at " + individualBase);
	}

	public void eval(final EvolutionState state, final int thread,
			final GPData input, final ADFStack stack,
			final GPIndividual individual, final Problem problem) {
		//    	state.output.error("KAKA");
		//    	System.out.println("Evaluating A");
		RegexData rd = ((RegexData) (input));
		rd.regex = symbol;
	}
	
	public String toString() { return symbol; }
	
	public String getRegex() { return symbol; }
	
//	public String toStringForHumans() { return symbol; }
}
