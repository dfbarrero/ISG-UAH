/*
  Copyright 2006 by Sean Luke
  Licensed under the Academic Free License version 3.0
  See the file "LICENSE" for more information
*/


package uah.regex.gp.nodes;

import ec.*;
import ec.gp.*;
import ec.util.*;

@SuppressWarnings("serial")
public abstract class Function extends RegexNode {
	public static final String P_START = "start";
	public static final String P_END = "end";
	
	public int child;
	public String start;
	public String end;
	
	public void setup(EvolutionState state, Parameter base) {
		super.setup(state, base);
    	Parameter def = defaultBase();
		
		start = state.parameters.getString(base
				.push(P_START), def.push(P_START));
		if (start == null) start = "";
		start.trim();
		
		end = state.parameters.getString(base
				.push(P_END), def.push(P_END));
		if (end == null) end = "";
		end.trim();
	}

	public void checkConstraints(final EvolutionState state, final int tree,
			final GPIndividual typicalIndividual, final Parameter individualBase) {
		super.checkConstraints(state, tree, typicalIndividual, individualBase);
		if (children.length != child)
			state.output.error("Incorrect number of children for node "
					+ toStringForError() + " at " + individualBase);
	}
	
	public String toString() { return start + end; }
}
