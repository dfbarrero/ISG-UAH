/*
  Copyright 2006 by Sean Luke
  Licensed under the Academic Free License version 3.0
  See the file "LICENSE" for more information
*/


package uah.regex.gp;
//import ec.app.tutorial4.DoubleData;
import ec.gp.*;

@SuppressWarnings("serial")
public class RegexData extends GPData {
    public String regex;
    
    public GPData copyTo(final GPData gpd)  { 
    	((RegexData)gpd).regex = regex; return gpd; 
    }
}


