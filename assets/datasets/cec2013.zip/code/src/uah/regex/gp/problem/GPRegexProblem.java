/*
  Copyright 2006 by Sean Luke
  Licensed under the Academic Free License version 3.0
  See the file "LICENSE" for more information
*/


package uah.regex.gp.problem;

import uah.regex.gp.GPRegexIndividual;
import uah.regex.gp.RegexData;
import uah.regex.problem.RegexProblem;

import ec.util.*;
import ec.vector.VectorDefaults;
import ec.*;
import ec.gp.*;
import ec.gp.koza.KozaFitness;
import ec.simple.*;

/**
 * Wrapper class, actually the class that implements the evaluation is given by
 * the parameter <i>evaluator</i>
 * @author david
 *
 */
@SuppressWarnings("serial")
public class GPRegexProblem extends GPProblem implements SimpleProblemForm {
	protected static String negativeFile;

	public static final String P_EVALUATOR = "evaluator";
	public static final String P_GPPROBLEM = "gpproblem";

	public static final String P_VERBOSE = "verbose";
	protected static String positiveFile;

	public RegexData input;

	public RegexProblem problem;
	public EvolutionState state;

	public static int evaluations = 0;
	public static boolean ideal = false;
	
	protected boolean verbose = false;

	public Object clone() {
		GPRegexProblem newobj = (GPRegexProblem) (super.clone());
		newobj.input = (RegexData) (input.clone());
		return newobj;
	}

	public Parameter defaultBase() {
		return VectorDefaults.base().push(P_GPPROBLEM);
	}

	public void evaluate(final EvolutionState state, final Individual _ind,
			final int subpopulation, final int threadnum) {
		if (_ind.evaluated) return;// don't bother reevaluating
		GPRegexIndividual ind = (GPRegexIndividual) _ind;
		
		// Obtain evaluated regex
		ind.trees[0].child.eval(state, threadnum, input, stack, ind, this);
		ind.regex = new String(input.regex); // Copy String
		
		if (verbose)
			System.out.printf("Evaluation %d (s %d, d %d): %s", evaluations, 
					ind.size(), ind.trees[0].child.depth(), input.regex);
		
		float fitness = 1 - Math.abs(problem.fitness(input.regex));
		
		if (verbose)
			System.out.print("\t ... ");
		
		if ((fitness == 0.0f) && !ideal) {
			ideal = true;
			evaluations++;
		} else if (!ideal) {
			evaluations++;
		}

		if (verbose)
			System.out.print("\tOK " + fitness + "\n");
		
		// the fitness better be KozaFitness!
		((KozaFitness) ind.fitness).setStandardizedFitness(state, fitness);
		if (fitness == 0) ((KozaFitness)ind.fitness).hits++;
		ind.evaluated = true;
	}

	public void reset() { ideal=false; evaluations=0; }

	public void setup(final EvolutionState state, final Parameter base) {
		// very important, remember this
		super.setup(state, base);
		Parameter def = defaultBase();

		// set up our input -- don't want to use the default base, it's unsafe here
		input = (RegexData) state.parameters.getInstanceForParameterEq(base
				.push(P_DATA), def.push(P_DATA), RegexData.class);
		input.setup(state, base.push(P_DATA));

		//Set up our problem
		problem = (RegexProblem) state.parameters.getInstanceForParameterEq(
				base.push(P_EVALUATOR), def.push(P_DATA), RegexProblem.class);
		problem.setup(state, base.push(P_EVALUATOR));

		state.output.exitIfErrors();
		this.state = state;
	}
}
