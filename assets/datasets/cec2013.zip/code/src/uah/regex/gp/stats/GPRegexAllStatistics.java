package uah.regex.gp.stats;

import ec.*;

import java.io.*;

import uah.regex.gp.problem.GPRegexProblem;
import uah.regex.problem.RegexProblem;
import ec.gp.GPIndividual;
import ec.gp.koza.KozaFitness;
import ec.util.*;

public class GPRegexAllStatistics extends Statistics
{
	private static final long serialVersionUID = 1L;

	/** log file parameter */
    public static final String P_STATISTICS_FILE = "file";

    /** The Statistics' log */
    public int statisticslog;
    
    public final static int V_STATS = 1100;
    
    /* The best individual we've found so far */
    //public Individual best_of_run;

    /** compress? */
    public static final String P_COMPRESS = "gzip";

    public static final String P_ALLLOGS = "all-logs";
    
    public void GRegexAllStatistics() { /*best_of_run = null;*/ statisticslog = 0; /* stdout */ }

    public void setup(final EvolutionState state, final Parameter base) {
		super.setup(state, base);
		
		File statisticsFile = state.parameters.getFile(base
				.push(P_STATISTICS_FILE), null);

		if (statisticsFile != null)
			try {
				statisticslog = state.output.addLog(statisticsFile,
						V_STATS - 1, false, !state.parameters.getBoolean(base
								.push(P_COMPRESS), null, false),
						state.parameters.getBoolean(base.push(P_COMPRESS),
								null, false));
			} catch (IOException i) {
				state.output
						.fatal("An IOException occurred while trying to create the log "
								+ statisticsFile + ":\n" + i);
			}
	}

    @Override
    public void postInitializationStatistics(final EvolutionState state) {
		super.postInitializationStatistics(state);
		// Evaluations
		state.output.print(
				state.generation + " ",
				V_STATS, statisticslog);
		for (int x = 0; x < state.population.subpops.length; x++) {
			for (int y = 0; y < state.population.subpops[x].individuals.length; y++) {
					printIndividual(state, (GPIndividual)state.population.subpops[x].individuals[y]);
			}
		}
	}
    
    public void _postEvaluationStatistics(final EvolutionState state) {
	}
	
    @SuppressWarnings("static-access")
	public void finalStatistics(EvolutionState state, int result) {
    	state.output.print("#generation raw adjusted hits size regex\n",
    			Output.V_NO_GENERAL, statisticslog);
		// Evaluations
		state.output.print(state.generation + " ", V_STATS, statisticslog);
		
		for (int x = 0; x < state.population.subpops.length; x++) {
			for (int y = 0; y < state.population.subpops[x].individuals.length; y++) {
					printIndividual(state, (GPIndividual)state.population.subpops[x].individuals[y]);
			}
		}
	}

	public void postEvaluationStatistics(final EvolutionState state)
	{
		super.postEvaluationStatistics(state);
		_postEvaluationStatistics(state);
		state.output.println("",Output.V_NO_GENERAL, statisticslog);
	}

    private void printIndividual(EvolutionState state, GPIndividual node) {
    	// We print the best individual because Koza does not introduce elitism
    	RegexProblem problem = ((GPRegexProblem)state.evaluator.p_problem).problem;
		// Generation
		state.output.print(state.generation + " ", 
				Output.V_NO_GENERAL, statisticslog);

		// Evaluations
		state.output.print(problem.evaluations + " ", 
				Output.V_NO_GENERAL, statisticslog);
			
		for (int x = 0; x < state.population.subpops.length; x++) {
			state.output.print(""
					+ String.format("%.4g", ((KozaFitness) node.fitness).rawFitness())
					+ " "
					+ String.format("%.4g", ((KozaFitness) node.fitness).adjustedFitness())
					+ " "
					+ ((KozaFitness) (node.fitness)).hits
					+ " " + ((GPIndividual) node).size()
					+ " " + node.trees[0].child.toStringForHumans() + "\n",
					Output.V_NO_GENERAL, statisticslog);
		}
    }
}