package uah.regex.gp.stats;

import ec.*;

//import ec.gp.GPIndividual;
import ec.gp.koza.KozaShortStatistics;
import ec.util.*;

@SuppressWarnings("serial")
public class GPRegexStatisticsOld extends KozaShortStatistics {
	public void setup(final EvolutionState state, final Parameter base) {
		super.setup(state, base);
//		state.output.print("MeanRaw MeanAdjusted MeanHits "
//				+ "BestRaw BestAdjusted BestHits "
//				+ "BestRawRun BestAdjustedRun BestHitsRun\n", Output.V_NO_GENERAL, statisticslog);
	}

//    public void postBreedingStatistics(final EvolutionState state) { }
   
    /**
	 * Prints out the statistics, but does not end with a println -- this lets
	 * overriding methods print additional statistics on the same line
	 */
//	@Override
//	protected void _postEvaluationStatistics(final EvolutionState state) {
//		super._postEvaluationStatistics(state);
//        Individual[] best_i = new Individual[state.population.subpops.length];
//        
//        for (int x = 0; x < state.population.subpops.length; x++) {
//			for (int y = 0; y < state.population.subpops[x].individuals.length; y++) {
//				// best individual
//				if (best_i[x] == null
//						|| state.population.subpops[x].individuals[y].fitness
//								.betterThan(best_i[x].fitness))
//					best_i[x] = state.population.subpops[x].individuals[y];
//			}
//        }
//        
//		for (int x = 0; x < state.population.subpops.length; x++) {
//			state.output.print(((GPIndividual) best_i[x]).trees[0].child
//					.toStringForHumans(), Output.V_NO_GENERAL, statisticslog);
//		}
//	}
}
