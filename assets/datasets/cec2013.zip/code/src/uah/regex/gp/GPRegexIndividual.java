/*
  Copyright 2006 by Sean Luke
  Licensed under the Academic Free License version 3.0
  See the file "LICENSE" for more information
*/


package uah.regex.gp;
import uah.regex.Regex;
import ec.*;
import ec.gp.GPIndividual;
import ec.util.*;

/* 
 * GPIndividual.java
 * 
 * Created: Fri Aug 27 17:07:45 1999
 * By: Sean Luke
 */

@SuppressWarnings("serial")
public class GPRegexIndividual extends GPIndividual implements Regex {
	public String regex = null;
	
	public void setup(final EvolutionState state, final Parameter base) {
		super.setup(state, base); // actually unnecessary (Individual.setup() is empty)
	}

	/** Overridden for the GPIndividual genotype, writing each tree in turn. */
	public void printIndividualForHumans(final EvolutionState state,
			final int log, final int verbosity) {
		super.printIndividualForHumans(state, log, verbosity);
		
		if (regex != null) {
			state.output.println("REGEX: " + regex, verbosity, log);
		}
//		state.output.println(EVALUATED_PREAMBLE
//				+ (evaluated ? "true" : "false"), verbosity, log);
//		fitness.printFitnessForHumans(state, log, verbosity);
//		for (int x = 0; x < trees.length; x++) {
//			state.output.print("Tree " + x + ": ", verbosity, log);
//			state.output.println(trees[x].child.toStringForHumans(), verbosity, log);
//		}
	}

	public String getRegex() {
		if (regex != null) {
			return regex;
		} else {
			return "Regex not initialized in GPRegexIndividual";
		}
	}
}
