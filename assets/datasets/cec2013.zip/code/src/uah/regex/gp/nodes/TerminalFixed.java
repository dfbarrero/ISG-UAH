/*
  Copyright 2006 by Sean Luke
  Licensed under the Academic Free License version 3.0
  See the file "LICENSE" for more information
*/


package uah.regex.gp.nodes;

import ec.*;
import ec.util.*;

@SuppressWarnings("serial")
public class TerminalFixed extends Terminal {
	public static final String P_SYMBOL = "symbol";

	public void setup(EvolutionState state, Parameter base) {
		super.setup(state, base);
    	Parameter def = defaultBase();
		
		symbol = state.parameters.getString(base
				.push(P_SYMBOL), def.push(P_SYMBOL));
	}
	
	public String toString() { return symbol; }
}
