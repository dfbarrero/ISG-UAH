/*
  Copyright 2006 by Sean Luke
  Licensed under the Academic Free License version 3.0
  See the file "LICENSE" for more information
*/


package uah.regex.gp.nodes;

import uah.regex.Regex;
import uah.regex.gp.RegexData;
import ec.*;
import ec.gp.*;
import ec.util.*;

@SuppressWarnings("serial")
public class BinaryFunction extends Function {
	public static final String P_OPERATOR = "operator";

	public String operator;
	
	public void setup(EvolutionState state, Parameter base) {
		super.setup(state, base);
		child=2;
	}

	public void eval(final EvolutionState state, final int thread,
			final GPData input, final ADFStack stack,
			final GPIndividual individual, final Problem problem) {
		RegexData rd = ((RegexData) (input));
		
		StringBuffer buffer = new StringBuffer(start);
		children[0].eval(state, thread, input, stack, individual, problem);
		buffer.append(rd.regex);
		children[1].eval(state, thread, input, stack, individual, problem);
		buffer.append(rd.regex);
		buffer.append(end);
		
		rd.regex = buffer.toString();
	}

	public String getRegex() {
		return start + ((Regex) children[0]).getRegex() +
			((Regex) children[1]).getRegex() + end;
	}
	
//	public String toStringForHumans() { 
//		return start + children[0].toStringForHumans() 
//					+ children[1].toStringForHumans() + end; }
}
