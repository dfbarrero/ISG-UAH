package uah.regex.gp.ns;

import ec.*;
import ec.gp.*;
import ec.util.*;
import ec.simple.*;


@SuppressWarnings("serial")
public abstract class CustomNodeSelector implements GPNodeSelector 
    {
	public static int selections = 0;
	
    public static final String P_NODESELECTOR = "ns";
    public static final String P_TERMINAL_PROBABILITY = "terminals";
    public static final String P_NONTERMINAL_PROBABILITY = "nonterminals";
    public static final String P_ROOT_PROBABILITY = "root";
    public static final String P_TRIES = "tries";
    public static final String P_TYPE = "type";
    public static final String P_DEBUG = "debug";

    public boolean debug = false;
    
    /** The probability the root must be chosen */
    public float rootProbability;
    
    /** The probability a terminal must be chosen */
    public float terminalProbability;

    /** The probability a nonterminal must be chosen. */
    public float nonterminalProbability;

    /** The number of nonterminals in the tree, -1 if unknown. */
    public int nonterminals;
    /** The number of terminals in the tree, -1 if unknown. */
    public int terminals;
    /** The number of nodes in the tree, -1 if unknown. */
    public int nodes;

    public int tries;
    
    public int type;
    
    /** Used internally to look for a node.  This is threadsafe as long as
        an instance of KozaNodeSelector is used by only one thread. */
    protected GPNodeGatherer gatherer;
    
    protected SimpleProblemForm problem;

    public Parameter defaultBase()
        {
        return RegexNSDefaults.base().push(P_NODESELECTOR);
        }

    public CustomNodeSelector() 
        {
        gatherer = new GPNodeGatherer(); 
        reset();
        }

    public Object clone()
        {
        try
            {
            CustomNodeSelector s = (CustomNodeSelector)(super.clone());
            // allocate a new gatherer, so we're always threadsafe
            s.gatherer = new GPNodeGatherer();
            s.reset();
            return s;
            }
        catch (CloneNotSupportedException e)
            { throw new InternalError(); } // never happens
        }

    public void setup(final EvolutionState state, final Parameter base)
        {
        problem = (SimpleProblemForm) state.evaluator.p_problem.clone();
        
        Parameter def = defaultBase();
    
        debug = state.parameters.getBoolean(base.push(P_DEBUG), 
        		def.push(P_DEBUG), false);
        
        tries = state.parameters.getInt(
                base.push(P_TRIES),
                def.push(P_TRIES), 0);

        if (tries < 0) {
            state.output.warning("Setting default tries to 5 ",
                               base.push(P_TRIES),
                               def.push(P_TRIES));
            tries = 5;
        }
        
        terminalProbability = state.parameters.getFloat(
            base.push(P_TERMINAL_PROBABILITY),
            def.push(P_TERMINAL_PROBABILITY), 0.0, 1.0);
        if (terminalProbability==-1.0)
            state.output.fatal("Invalid terminal probability for CustomNodeSelector ",
                               base.push(P_TERMINAL_PROBABILITY),
                               def.push(P_TERMINAL_PROBABILITY));

        if (terminalProbability!=0.0)
            state.output.warnOnce("Terminal probability should be 0 ",
                               base.push(P_TERMINAL_PROBABILITY),
                               def.push(P_TERMINAL_PROBABILITY));
        
        nonterminalProbability = state.parameters.getFloat(
            base.push(P_NONTERMINAL_PROBABILITY), 
            def.push(P_NONTERMINAL_PROBABILITY),0.0, 1.0);
        if (nonterminalProbability==-1.0)
            state.output.fatal("Invalid nonterminal probability for CustomNodeSelector ",
                               base.push(P_NONTERMINAL_PROBABILITY), 
                               def.push(P_NONTERMINAL_PROBABILITY));

        rootProbability = state.parameters.getFloat(
            base.push(P_ROOT_PROBABILITY),
            def.push(P_ROOT_PROBABILITY),0.0, 1.0);
        
        if (rootProbability==-1.0)
            state.output.fatal("Invalid root probability for CustomNodeSelector ",
                               base.push(P_ROOT_PROBABILITY),
                               def.push(P_ROOT_PROBABILITY));

        if (rootProbability+terminalProbability+nonterminalProbability > 1.0f)
            state.output.fatal("The terminal, nonterminal, and root for KozaNodeSelector" + base + " may not sum to more than 1.0. (" + terminalProbability + " " + nonterminalProbability + " " + rootProbability + ")",base);

        reset();
    }


    public void reset()	{
        nonterminals = terminals = nodes = -1;
    }

    public GPNode pickNode(final EvolutionState s,
                           final int subpopulation,
                           final int thread,
                           final GPIndividual ind,
                           final GPTree tree) 
    {
        GPNode node = null;

        if (debug) s.output.message("\n------- SELECTING -------");
        //if (debug) s.output.message("ORIGINAL: \n" ); ind.printIndividualForHumans(s, 1, 100000000);
        
        node = select(s, subpopulation, thread, ind, tree);      
 //       System.out.println("Reading node"); System.out.flush();
        if (node == null) { 
        	//System.out.println("NULLLLLLLLL");
        	return ind.trees[0].child; // Return root node
        }
        //node.printRootedTree(s, 1, 10000000, 0);

//        System.out.println("Returning node"); System.out.flush();
//        node.printRootedTree(s, 1, 10000000, 0);
        return node;
     }
     
    abstract protected GPNode select(final EvolutionState s,
            final int subpopulation,
            final int thread,
            final GPIndividual ind,
            final GPTree tree);
    
    protected GPNode searchNode(final EvolutionState s,
                final int subpopulation,
                final int thread,
                final GPIndividual ind,
                final GPTree tree)
        {  
        float rnd = s.random[thread].nextFloat();
        if (rnd > nonterminalProbability + terminalProbability
				+ rootProbability) // pick anyone
		{
			if (nodes == -1)
				nodes = tree.child.numNodes(GPNode.NODESEARCH_ALL);
			{
				tree.child.nodeInPosition(s.random[thread].nextInt(nodes),
						gatherer, GPNode.NODESEARCH_ALL);
				return gatherer.node;
			}
		} else if (rnd > nonterminalProbability + terminalProbability) // pick the root
		{
			return tree.child;
		} else if (rnd > nonterminalProbability) // pick terminals
		{
			if (terminals == -1)
				terminals = tree.child.numNodes(GPNode.NODESEARCH_TERMINALS);

			tree.child.nodeInPosition(s.random[thread].nextInt(terminals),
					gatherer, GPNode.NODESEARCH_TERMINALS);
			return gatherer.node;
		} else // pick nonterminals if you can
		{
			if (nonterminals == -1)
				nonterminals = tree.child
						.numNodes(GPNode.NODESEARCH_NONTERMINALS);
			if (nonterminals > 0) // there are some nonterminals
			{
				tree.child.nodeInPosition(s.random[thread]
						.nextInt(nonterminals), gatherer,
						GPNode.NODESEARCH_NONTERMINALS);
				return gatherer.node;
			} else // there ARE no nonterminals!  It must be the root node
			{
				return null;
			}
		}
        }
    }
