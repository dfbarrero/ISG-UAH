package uah.regex.gp.ns;

import ec.*;
import ec.gp.*;
import ec.gp.koza.KozaFitness;

@SuppressWarnings("serial")
public class StandardPointNodeSelector extends CustomNodeSelector
{
	protected GPNode select(final EvolutionState s,
			final int subpopulation,
			final int thread,
			final GPIndividual ind,
			final GPTree tree) {
		GPNode node = null;
		int tries = this.tries > tree.child.numNodes(GPNode.NODESEARCH_NONTERMINALS)?
				tree.child.numNodes(GPNode.NODESEARCH_NONTERMINALS) : this.tries;

		for (int i=0; i < tries; i++) {
			boolean allEqual = true;
			KozaFitness parentFitness;               	 

			node =  searchNode(s, subpopulation, thread, ind, tree);

			if ((node == null) || (node.parent instanceof GPTree)) {
				continue; // root node, continue search
			}

			// Evaluate nodes
			//s.output.message("NODE: " ); node.printRootedTreeForHumans(s, 1, 1000000000, 3, 0);
			GPIndividual nodeInd = (GPIndividual) s.population.subpops[subpopulation].species.newIndividual(s, thread);
			GPIndividual parentInd = (GPIndividual) s.population.subpops[subpopulation].species.newIndividual(s, thread);

			// Selected node
			nodeInd.trees[0].child = node.cloneReplacing();
			nodeInd.trees[0].child.parent = nodeInd.trees[0];
			nodeInd.evaluated = false;
			problem.evaluate(s, nodeInd, subpopulation, thread);
			KozaFitness nodeFitness = (KozaFitness) nodeInd.fitness;

			// Parent node
			parentInd.trees[0].child = ((GPNode) node.parent).cloneReplacing();
			parentInd.trees[0].child.parent = parentInd.trees[0];
			problem.evaluate(s, parentInd, subpopulation, thread);
			parentFitness = (KozaFitness) parentInd.fitness;
			
			if (debug)  s.output.message("Node: " + nodeFitness.fitness() + "(" + node.atDepth() + ")" + " Parent: " + parentFitness.fitness());

			// If parent is better, do nothing, if not, check the children
			if (nodeFitness.adjustedFitness() < parentFitness.adjustedFitness()) {
				if (debug)  s.output.message("\tParent is better or equal, do nothing.");
				continue;
			} else if (nodeFitness.adjustedFitness() == parentFitness.adjustedFitness()) {
				allEqual = false;
			}

			// Check children nodes
			// We check is there is at least one child worse than the selected node
			for (GPNode child : node.children) {
				GPIndividual childInd = (GPIndividual) s.population.subpops[subpopulation].species.newIndividual(s, thread);
				childInd.trees[0].child = child.cloneReplacing();
				childInd.trees[0].child.parent = childInd.trees[0];
				childInd.evaluated = false;
				problem.evaluate(s, childInd, subpopulation, thread);
				KozaFitness childFitness = (KozaFitness) childInd.fitness;

				if (debug)  s.output.message("\t" + childFitness.fitness());

				if (childFitness.adjustedFitness() < nodeFitness.adjustedFitness()) {
					// Ups, there's one child worse than the selected node, select child 
					if (debug)  s.output.message("\tSELECTED!");
					return child;
				} else if (childFitness.adjustedFitness() != nodeFitness.adjustedFitness()) {
					allEqual = false;
				}
			}
			
			if (!allEqual) {
				if (debug) s.output.message("\tAll the nodes are equal, mutate'em!!");
				return node;
			}
		}

		s.output.message("No one has been found \n"); s.output.flush();
		return node;
	}
}
