package uah.regex.gp.nodes;

import uah.regex.Regex;
import ec.gp.GPNode;

public abstract class RegexNode extends GPNode implements Regex {

}
