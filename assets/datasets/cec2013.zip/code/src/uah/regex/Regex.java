package uah.regex;

public interface Regex {
	public String getRegex();
}
