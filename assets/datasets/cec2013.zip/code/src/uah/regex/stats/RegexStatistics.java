
package uah.regex.stats;
import ec.*;
import java.io.*;
import ec.util.*;

import uah.regex.IndividualRegex;
import uah.regex.coding.vlg.messy.BitMessyIndividual;

/**
 * <p> Each line represents a single generation.  
 * The first items on a line are always:
 <ul>
 <li> The generation number

 <p>Then the following items appear, per subpopulation:
 <ul>
 <li> Generation
 <li> Evaluations
 <li> The mean fitness of the subpopulation this generation
 <li> The best fitness of the subpopulation this generation
 <li> The best fitness of the subpopulation so far in the run
 <li> Diversity (actually always 0)
 <li> The average size of an individual this generation
 <li> The size of the best individual this generation
 <li> The size of the best individual so far in the run
 </ul>

 Compressed files will be overridden on restart from checkpoint; uncompressed files will be 
 appended on restart.

 <p><b>Parameters</b><br>
 <table>
 <tr><td valign=top><i>base.</i><tt>gzip</tt><br>
 <font size=-1>boolean</font></td>
 <td valign=top>(whether or not to compress the file (.gz suffix added)</td></tr>
 <tr><td valign=top><i>base.</i><tt>file</tt><br>
 <font size=-1>String (a filename), or nonexistant (signifies stdout)</font></td>
 <td valign=top>(the log for statistics)</td></tr>
 </table>
 */

@SuppressWarnings("serial")
public class RegexStatistics extends Statistics
    {
    /** log file parameter */
    public static final String P_STATISTICS_FILE = "file";
    
    public static final String P_REGEX = "regex";

    /** The Statistics' log */
    public int statisticslog;

    public final static int V_STATS = 1100;
    
    /* The best individual we've found so far */
    //public Individual best_of_run;

    /** compress? */
    public static final String P_COMPRESS = "gzip";

    public static final String P_ALLLOGS = "all-logs";
    
    public boolean regex;

    public Individual[] best_of_run_a;
    public long lengths[];
    
    public RegexStatistics() { /*best_of_run = null;*/ statisticslog = 0; /* stdout */ }

    public void setup(final EvolutionState state, final Parameter base) {
		super.setup(state, base);

		File statisticsFile = state.parameters.getFile(base
				.push(P_STATISTICS_FILE), null);

		if (statisticsFile != null)
			try {
				statisticslog = state.output.addLog(statisticsFile,
						V_STATS - 1, false, !state.parameters.getBoolean(base
								.push(P_COMPRESS), null, false),
						state.parameters.getBoolean(base.push(P_COMPRESS),
								null, false));
			} catch (IOException i) {
				state.output
						.fatal("An IOException occurred while trying to create the log "
								+ statisticsFile + ":\n" + i);
			}
			
			regex = state.parameters.getBoolean(base
					.push(P_REGEX), null, true);
	}


    public void preInitializationStatistics(final EvolutionState state)
        {
        super.preInitializationStatistics(state);
        }
    
    public void postInitializationStatistics(final EvolutionState state)
        {
        super.postInitializationStatistics(state);
        
        // set up our best_of_run array -- can't do this in setup, because
        // we don't know if the number of subpopulations has been determined yet
        best_of_run_a = new Individual[state.population.subpops.length];
        
        // print out our generation number
        state.output.print("0 ", V_STATS, statisticslog);

        lengths = new long[state.population.subpops.length];
        for(int x=0;x<lengths.length;x++) lengths[x] = 0;
        }

    public void preBreedingStatistics(final EvolutionState state)
        {
        super.preBreedingStatistics(state);
        }

    public void postBreedingStatistics(final EvolutionState state) 
        {
        super.postBreedingStatistics(state);
        state.output.print("" + (state.generation + 1) + " ", V_STATS, statisticslog); // 1 because we're putting the breeding info on the same line as the generation it *produces*, and the generation number is increased *after* breeding occurs, and statistics for it
        }

    public void preEvaluationStatistics(final EvolutionState state)
        {
        super.preEvaluationStatistics(state);
        }

    /** Prints out the statistics, but does not end with a println --
        this lets overriding methods print additional statistics on the same line */
    protected void _postEvaluationStatistics(final EvolutionState state)
        {
        long lengthPerGen = 0;
        Individual[] best_i = new Individual[state.population.subpops.length];
        for (int x = 0; x < state.population.subpops.length; x++) {
        	// Evaluations
        	if (state.generation == 0)
        		state.output.print("" + state.population.subpops[x].individuals.length + " ", V_STATS, statisticslog);
        	else
        		state.output.print("" + state.population.subpops[x].individuals.length * (state.generation+1) + " ", V_STATS, statisticslog);
			
        	// fitness information
			double meanFitness = 0.0;

			for (int y = 0; y < state.population.subpops[x].individuals.length; y++) {
				// best individual
				if (best_i[x] == null
						|| state.population.subpops[x].individuals[y].fitness
								.betterThan(best_i[x].fitness))
					best_i[x] = state.population.subpops[x].individuals[y];

				// mean fitness for population
				meanFitness += state.population.subpops[x].individuals[y].fitness
						.fitness();
			}

			// compute fitness stats
			meanFitness /= state.population.subpops[x].individuals.length;
			state.output.print("" + String.format("%.4g", meanFitness) + " "
					+ String.format("%.4g", best_i[x].fitness.fitness()) + " ", Output.V_NO_GENERAL,
					statisticslog);

			// now test to see if it's the new best_of_run_a[x]
			if (best_of_run_a[x] == null
					|| best_i[x].fitness.betterThan(best_of_run_a[x].fitness))
				best_of_run_a[x] = (Individual) (best_i[x].clone());

			state.output.print("" + String.format("%.4g", best_of_run_a[x].fitness.fitness()) + " ",
					V_STATS, statisticslog);

			// Diversity
			state.output.print("0 ", V_STATS, statisticslog);
			
			// Sizes
			lengthPerGen = 0;
			for (int y = 0; y < state.population.subpops[x].individuals.length; y++) {
				long size = state.population.subpops[x].individuals[y].size();
				lengthPerGen += size;
				lengths[x] += size;
			}

            state.output.print("" + ((double) lengthPerGen)
					/ state.population.subpops[x].individuals.length + " ",
					V_STATS, statisticslog);
            
            // <li> The average size of an individual so far in the run
//			state.output.print("" + ((double) lengths[x])
//					/ (state.population.subpops[x].individuals.length * (state.generation + 1))
//					+ " ", V_STATS, statisticslog);
			
			state.output.print("" + (int) (best_i[x].size()) + " "
					+ (int) (best_of_run_a[x].size()) + " \t\t", V_STATS,
					statisticslog);

			//           state.output.print("" + RegExp.binaryToRegexp((BitVectorIndividual)best_i[x]),
			//                   V_STATS, statisticslog);
			if (regex){ 
				((IndividualRegex) best_i[x]).printIndividualForHumans(state,
					statisticslog, V_STATS);
				if (best_i[x] instanceof BitMessyIndividual)
					state.output.print("\t"
					+ ((BitMessyIndividual) best_i[x]).binaryToCodons(),
					V_STATS, statisticslog);
			}
		}
		// we're done!
	}

	public void postEvaluationStatistics(final EvolutionState state) {
		super.postEvaluationStatistics(state);
		_postEvaluationStatistics(state);
		state.output.println("", V_STATS, statisticslog);
	}

    }
