
package uah.regex.stats;

import ec.*;

import java.io.*;
import ec.util.*;

import uah.regex.IndividualRegex;
import uah.regex.problem.RegexProblem;

/**
 <li> The generation number

 <p>Then the following items appear, per subpopulation:
 <ul>
 <li> Evaluations
 <li> AES
 <li> Size best of the generation
 <li> Best regex of the generation
 </ul>

 Compressed files will be overridden on restart from checkpoint; uncompressed files will be 
 appended on restart.

 <p><b>Parameters</b><br>
 <table>
 <tr><td valign=top><i>base.</i><tt>gzip</tt><br>
 <font size=-1>boolean</font></td>
 <td valign=top>(whether or not to compress the file (.gz suffix added)</td></tr>
 <tr><td valign=top><i>base.</i><tt>file</tt><br>
 <font size=-1>String (a filename), or nonexistant (signifies stdout)</font></td>
 <td valign=top>(the log for statistics)</td></tr>
 </table>
 */

@SuppressWarnings("serial")
public class RegexFinalStatistics extends Statistics
    {
    /** log file parameter */
    public static final String P_STATISTICS_FILE = "file";

    /** The Statistics' log */
    public int statisticslog;

    public Individual[] best_of_run_a;
    
    public final static int V_STATS = 1100;
    
    /* The best individual we've found so far */
    //public Individual best_of_run;

    /** compress? */
    public static final String P_COMPRESS = "gzip";

    public static final String P_ALLLOGS = "all-logs";
    
    public RegexFinalStatistics() { /*best_of_run = null;*/ statisticslog = 0; /* stdout */ }

    public void setup(final EvolutionState state, final Parameter base) {
		super.setup(state, base);
		
		best_of_run_a = null;
		File statisticsFile = state.parameters.getFile(base
				.push(P_STATISTICS_FILE), null);

		if (statisticsFile != null)
			try {
				statisticslog = state.output.addLog(statisticsFile,
						V_STATS - 1, false, !state.parameters.getBoolean(base
								.push(P_COMPRESS), null, false),
						state.parameters.getBoolean(base.push(P_COMPRESS),
								null, false));
			} catch (IOException i) {
				state.output
						.fatal("An IOException occurred while trying to create the log "
								+ statisticsFile + ":\n" + i);
			}
	}

    @Override
    public void postInitializationStatistics(final EvolutionState state) {
		super.postInitializationStatistics(state);
		// set up our best_of_run array -- can't do this in setup, because
		// we don't know if the number of subpopulations has been determined yet
		best_of_run_a = new Individual[state.population.subpops.length];
	}
    
    /**
	 * Prints out the statistics, but does not end with a println -- this lets
	 * overriding methods print additional statistics on the same line
	 */
    public void postEvaluationStatistics(final EvolutionState state) {
		Individual[] best_i = new Individual[state.population.subpops.length];
		
		for (int x = 0; x < state.population.subpops.length; x++) {
			for (int y = 0; y < state.population.subpops[x].individuals.length; y++) {
				// best individual
				if (best_i[x] == null
						|| state.population.subpops[x].individuals[y].fitness
								.betterThan(best_i[x].fitness))
					best_i[x] = state.population.subpops[x].individuals[y];
			}

			// now test to see if it's the new best_of_run_a[x]
			if (best_of_run_a[x] == null
					|| best_i[x].fitness.betterThan(best_of_run_a[x].fitness))
				best_of_run_a[x] = (Individual) (best_i[x].clone());
		}
	}
	
    @SuppressWarnings("static-access")
	public void finalStatistics(EvolutionState state, int result) {
		if (!((RegexProblem)state.evaluator.p_problem).ideal) {
			// Print FAILURE and the best regex so far
			// We do not consider subpopulations, so we take the first one
			state.output.print("FAILURE " + ((IndividualRegex) best_of_run_a[0]).binaryToRegexp() , V_STATS, statisticslog);
			return;
		}
		
	//	state.output.print(state.generation + " ", V_STATS, statisticslog);
		Individual[] best_i = new Individual[state.population.subpops.length];
		for (int x = 0; x < state.population.subpops.length; x++) {
			// Evaluations
			state.output.print(
					((RegexProblem)state.evaluator.p_problem).evaluations + " ",
					V_STATS, statisticslog);

			for (int y = 0; y < state.population.subpops[x].individuals.length; y++) {
				// best individual
				if (best_i[x] == null
						|| state.population.subpops[x].individuals[y].fitness
								.betterThan(best_i[x].fitness))
					best_i[x] = state.population.subpops[x].individuals[y];
			}
			
			// compute fitness stats
//			state.output.print(" " + String.format("%.4g ", best_i[x].fitness.fitness()),
//					Output.V_NO_GENERAL, statisticslog);
			
			// Sizes
			state.output.print("" + (int) (best_of_run_a[x].size()) + "  ", V_STATS,
					statisticslog);

			((IndividualRegex) best_of_run_a[x]).printIndividualForHumans(state,
					statisticslog, V_STATS);
//			if (best_i[x] instanceof BitMessyIndividual)
//				state.output.print("\t"
//						+ ((BitMessyIndividual) best_i[x]).binaryToCodons(),
//						V_STATS, statisticslog);
		}
		
		// When ECJ is invoked from Weka the Problem object is not destroyed after
		// each experiment, so a manual reset of the object is needed
		((RegexProblem)state.evaluator.p_problem).reset();
	}
}
