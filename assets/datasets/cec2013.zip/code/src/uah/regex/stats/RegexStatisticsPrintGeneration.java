
package uah.regex.stats;

import ec.*;

import java.io.*;
import ec.util.*;

import uah.regex.IndividualRegex;
import uah.regex.coding.vlg.messy.BitMessyIndividual;

/**
 <ul>
 <li> Regex
 <li> Fitness
 <li> Size
 </ul>

 Compressed files will be overridden on restart from checkpoint; uncompressed files will be 
 appended on restart.

 <p><b>Parameters</b><br>
 <table>
 <tr><td valign=top><i>base.</i><tt>gzip</tt><br>
 <font size=-1>boolean</font></td>
 <td valign=top>(whether or not to compress the file (.gz suffix added)</td></tr>
 <tr><td valign=top><i>base.</i><tt>file</tt><br>
 <font size=-1>String (a filename), or nonexistant (signifies stdout)</font></td>
 <td valign=top>(the log for statistics)</td></tr>
 </table>
 */

@SuppressWarnings("serial")
public class RegexStatisticsPrintGeneration extends RegexStatistics
    {
    public static final String P_GENERATION = "generation";

    /** The Statistics' log */
    public int statisticslog;

    public final static int V_STATS = 1100;
    
    public static int generation = -1;    
    
    public void setup(final EvolutionState state, final Parameter base) {
		super.setup(state, base);
		File statisticsFile = state.parameters.getFile(base
				.push(P_STATISTICS_FILE), null);

		if (statisticsFile != null)
			try {
				statisticslog = state.output.addLog(statisticsFile,
						V_STATS - 1, false, !state.parameters.getBoolean(base
								.push(P_COMPRESS), null, false),
						state.parameters.getBoolean(base.push(P_COMPRESS),
								null, false));
			} catch (IOException i) {
				state.output
						.fatal("An IOException occurred while trying to create the log "
								+ statisticsFile + ":\n" + i);
			}
			
		try {
		generation = state.parameters.getInt(base.push(P_GENERATION), null);
		} catch (NumberFormatException e) {
			state.output.error("Generation not found", base.push(P_GENERATION));
		}
		state.output.exitIfErrors();
	}

    @Override
    public void _postEvaluationStatistics(final EvolutionState state)
    {
    	if (generation == state.generation)
    		printGeneration(state);
    }
    
    protected void printGeneration(final EvolutionState state) {
        for (int x = 0; x < state.population.subpops.length; x++) {			
			for (int y = 0; y < state.population.subpops[x].individuals.length; y++) {
				IndividualRegex ind = (IndividualRegex) state.population.subpops[x].individuals[y];
				state.output.print("" + ind.fitness.fitness(), Output.V_NO_GENERAL, statisticslog);
				state.output.print("\t" + ind.genomeLength(), Output.V_NO_GENERAL, statisticslog);
				state.output.print("\t" + ind.binaryToRegexp(), Output.V_NO_GENERAL, statisticslog);
				if (ind instanceof BitMessyIndividual)
					state.output.print("\t"
					+ ((BitMessyIndividual) ind).binaryToCodons(),
					V_STATS, statisticslog);
				state.output.println("", V_STATS, statisticslog);
			}
        }
	}
}
