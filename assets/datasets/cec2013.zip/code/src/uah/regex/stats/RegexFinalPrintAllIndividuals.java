/*
  Copyright 2006 by Sean Luke
  Licensed under the Academic Free License version 3.0
  See the file "LICENSE" for more information
 */

package uah.regex.stats;

import ec.*;

import java.io.*;

import uah.regex.IndividualRegex;

import ec.simple.SimpleStatistics;
import ec.util.*;

@SuppressWarnings("serial")
public class RegexFinalPrintAllIndividuals extends SimpleStatistics {
	/** log file parameter */
	public static final String P_STATISTICS_FILE = "file";

	/** The Statistics' log */
	public int statisticslog;

	/* The best individual we've found so far */
	// public Individual best_of_run;
	/** compress? */
	public static final String P_COMPRESS = "gzip";

	public static final String P_FULL = "gather-full";

	public boolean doFull;

	public Individual[] best_of_run_a;
	public long lengths[];

	// timings
	public long lastTime;

	// usage
	public long lastUsage;

	public RegexFinalPrintAllIndividuals() { /* best_of_run = null; */
		statisticslog = 0; /* stdout */
	}

	public void setup(final EvolutionState state, final Parameter base) {
		super.setup(state, base);
		File statisticsFile = state.parameters.getFile(base
				.push(P_STATISTICS_FILE), null);

		if (statisticsFile != null)
			try {
				statisticslog = state.output.addLog(statisticsFile,
						Output.V_NO_GENERAL - 1, false,
						!state.parameters.getBoolean(base.push(P_COMPRESS),
								null, false), state.parameters.getBoolean(base
								.push(P_COMPRESS), null, false));
			} catch (IOException i) {
				state.output
						.fatal("An IOException occurred while trying to create the log "
								+ statisticsFile + ":\n" + i);
			}
		doFull = state.parameters.getBoolean(base.push(P_FULL), null, false);
	}

	public void preInitializationStatistics(final EvolutionState state) {
	}

	public void postInitializationStatistics(final EvolutionState state) {
	}

	public void preBreedingStatistics(final EvolutionState state) {
	}

	public void postBreedingStatistics(final EvolutionState state) {
	}

	public void preEvaluationStatistics(final EvolutionState state) {
	}

	protected void _postEvaluationStatistics(final EvolutionState state) {
	}

	public void postEvaluationStatistics(final EvolutionState state) {
	}

	public void finalStatistics(final EvolutionState state, final int result) {
		// for now we just print the best fitness
		state.output.println("\nIndividuals in last generation:", Output.V_NO_GENERAL,
				statisticslog);
		for (int x = 0; x < state.population.subpops[0].individuals.length; x++) {
			//BitMessyIndividual ind = (BitMessyIndividual) state.population.subpops[0].individuals[x];
			state.output.println(((IndividualRegex) state.population.subpops[0].individuals[x]).fitness.fitness()
					+ "\t" + ((IndividualRegex) state.population.subpops[0].individuals[x]).binaryToRegexp(),
					Output.V_NO_GENERAL, statisticslog);			
		}
	}

}
