
package uah.regex.coding.vlg.messy;
import ec.util.Parameter;
import ec.*;


public final class MessyDefaults implements DefaultsForm {
	public static final String P_MESSY = "messy";

	/** Returns the default base. */
	public static final Parameter base() {
		return new Parameter(P_MESSY);
	}
}
