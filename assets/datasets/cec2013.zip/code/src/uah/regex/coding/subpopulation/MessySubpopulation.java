package uah.regex.coding.subpopulation;

import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.Hashtable;

import uah.regex.coding.vlg.messy.BitMessyIndividual;
import uah.regex.coding.vlg.messy.BitMessySpecies;
import uah.regex.util.Util;

import ec.EvolutionState;
import ec.Group;
import ec.Individual;
import ec.Subpopulation;
import ec.util.Parameter;

@SuppressWarnings("serial")
public class MessySubpopulation extends ec.Subpopulation {
    public static final String P_K = "k";
    
	public int k;
	
    public Group emptyClone() {
		try {
			MessySubpopulation p = (MessySubpopulation) clone();
			p.species = species; 
			p.individuals = new Individual[individuals.length];
			p.k = k;
			return p;
		} catch (CloneNotSupportedException e) {
			throw new InternalError();
		} // never happens
	}
    
    public void setup(final EvolutionState state, final Parameter base)
    {
        Parameter def = defaultBase();
        
    	super.setup(state, base);
    	
    	if (!(species instanceof BitMessySpecies))
    		state.output.fatal("Ohoh, I need a BitMessSpecie");
    	
        k = state.parameters.getInt(
                base.push(P_K),def.push(P_K),1);
        if (k<=0)
                state.output.fatal(
                    "k must be an integer >= 1.\n",
                    base.push(P_K),def.push(P_K));
    }

	public void populate(EvolutionState state, int thread) {
		BitMessySpecies s = (BitMessySpecies) species;
		String[] coding = (((BitMessyIndividual) s.newIndividual(state, thread))
				.getCoding());
		
		System.out.println("Subpop: Coding length " + coding.length);
		System.out.print("Coding: ");
		for (String str: coding) System.out.print (str + ", ");
		System.out.println("");
		
		if (k > coding.length)
			state.output.fatal("k must be < coding length");

		int population = (int) (Math.pow(2, k) * Util.C(coding.length, k));
		state.output.fatal("Hola " + k + ", soy subpopulation " + population);

		try {
			readSubpopulation(state, new LineNumberReader(new FileReader(
					loadInds)));
		} catch (IOException e) {
			state.output
					.fatal("An IOException occurred when trying to read from the file "
							+ loadInds + ".  The IOException was: \n" + e);
		}
	}
}
