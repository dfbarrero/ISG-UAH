package uah.regex.coding.vlg.messy;

import ec.EvolutionState;
import ec.util.Parameter;
import ec.vector.BitVectorIndividual;
import ec.vector.VectorDefaults;
import ec.vector.VectorIndividual;

@SuppressWarnings("serial")
public class BitMessyCSIndividual extends BitMessyIndividual {
	public static final String P_MESSYCS = "messycs-ind";
	
    public Parameter defaultBase() 
    {
    	return VectorDefaults.base().push(P_MESSYCS);
    }
    
    public void defaultCrossover(EvolutionState state, int thread, VectorIndividual ind)
    {
    	BitVectorIndividual i = (BitVectorIndividual) ind;
    	   	
    	if (!(i instanceof BitMessyCSIndividual))
    		state.output.fatal("Messy crossover requires two BitMessyCSIndividual individuals");

    	super.defaultCrossover(state, thread, ind);
    }
}
