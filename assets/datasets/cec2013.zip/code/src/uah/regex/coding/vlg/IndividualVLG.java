/* BitVariableVectorIndividual.java
   Copyright (C) 2008 David F. Barrero <david.barrero@aut.uah.es>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, version 2.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA. 
*/
package uah.regex.coding.vlg;

import uah.regex.IndividualRegex;
import ec.EvolutionState;
import ec.util.Output;
import ec.util.Parameter;

import ec.vector.BitVectorIndividual;
import ec.vector.VectorIndividual;
import ec.vector.VectorSpecies;

@SuppressWarnings("serial")
public class IndividualVLG extends IndividualRegex {
	public static final String P_VLG = "vlg";
//	protected SpeciesVLG species;
	
	public Parameter defaultBase() {
		return VlgDefaults.base().push(P_VLG);
	}

	public void setup(final EvolutionState state, final Parameter base) {
		// Species has not been initialized yet
		super.setup(state, base);
		
        if (!(species instanceof SpeciesVLG)) 
            state.output.fatal("IndividualVLG requires an SpeciesVLG");
    }
    
    public void defaultCrossover(EvolutionState state, int thread, VectorIndividual ind)
    {
    	VectorSpecies s = (VectorSpecies)species;  // where my default info is stored
    	BitVectorIndividual i = (BitVectorIndividual) ind;
//    	long minLength = (genome.length < i.genomeLength())? genome.length : i.genomeLength();
    	
//    	System.out.println("Crossing over");
    	
    	switch(s.crossoverType)
    	{
    	case VectorSpecies.C_ONE_POINT:
    		int pointA = state.random[thread].nextInt(((int) genomeLength() / s.chunksize)+1) * s.chunksize;
    		int pointB = state.random[thread].nextInt(((int) i.genomeLength() / s.chunksize)+1) * s.chunksize;
    		boolean [][] partsA = new boolean[2][];
    		boolean [][] partsB = new boolean[2][];
    		int []  points = {pointA};
    		   		
    		split(points, partsA);
    		points[0] = pointB;
    		i.split(points, partsB);
    		
    		Object []a = {partsA[0], partsB[1]};
    		Object []b = {partsB[0], partsA[1]};
    		
       		join(a);
    		i.join(b);
    		
    		break;
    	case VectorSpecies.C_TWO_POINT: 
    		state.output.fatal("Two points crossover not supported");
    		break;
    	case VectorSpecies.C_ANY_POINT:
    		state.output.fatal("Any point crossover not supported");
    		break;
    	}
    }

	/* (non-Javadoc)
	 * @see ec.vector.BitVectorIndividual#reset(ec.EvolutionState, int)
	 */
	public void reset(EvolutionState state, int thread) {
		SpeciesVLG s = (SpeciesVLG) species;
//		int temp = state.random[thread].nextInt(s.chunksize)+1;
		int size = 	state.random[thread].nextInt(((s.maxGenSize - s.minGenSize) / s.chunksize)+1);
		size = (size*s.chunksize + s.minGenSize);
		
        setGenomeLength(size);
        genome = new boolean[size];
        
		for(int x=0;x<size;x++)
            genome[x] = state.random[thread].nextBoolean();
	}
	
	public void printIndividualForHumans(EvolutionState state, int log, int verbosity) {
		state.output.print(binaryToRegexp(), Output.V_NO_GENERAL, log);
	}
	
	public void setGenome(java.lang.Object gen) {
		this.genome = (boolean[]) gen;
	}
}
