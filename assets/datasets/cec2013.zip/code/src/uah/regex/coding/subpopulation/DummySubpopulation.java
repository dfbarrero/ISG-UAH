package uah.regex.coding.subpopulation;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.Hashtable;

import uah.regex.util.Util;

import ec.EvolutionState;
import ec.util.Parameter;
import ec.vector.BitVectorIndividual;
import ec.vector.VectorSpecies;


@SuppressWarnings("serial")
public class DummySubpopulation extends ec.Subpopulation {
    public static final String P_FILL = "fill";
    
	public boolean fill = false;
	
    
    public void setup(final EvolutionState state, final Parameter base)
    {
        Parameter def = defaultBase();
        
    	super.setup(state, base);
    	
    	if (!(species instanceof VectorSpecies))
    		state.output.fatal("Oh oh, I need a VectorSpecies");
    	
        fill = state.parameters.getBoolean(
                base.push(P_FILL), def.push(P_FILL), true);
    }

    public void populate(EvolutionState state, int thread) {
    	VectorSpecies s = (VectorSpecies) species;
    	
    	state.output.warnOnce("Populating");

    	for(int x=0; x<individuals.length; x++) {
    		individuals[x] = (BitVectorIndividual) species.newIndividual(state, thread);
    		boolean genome[] = new boolean[s.genomeSize];
    		
    		for (int i=0; i<s.genomeSize; i++) genome[i] = fill;
    		System.out.println("Setting " + Util.booleanArrayToString(genome));
    		((BitVectorIndividual) individuals[x]).setGenome(genome);
    		((BitVectorIndividual) individuals[x]).setGenomeLength(genome.length);
    		((BitVectorIndividual) individuals[x]).evaluated = false;
    		//System.out.println("+ " + ((IndividualRegex)individuals[x]).getGenomeBinary());
    	}
    	
        //try { 
        //	writeSubpopulation(state, new DataOutputStream(new FileOutputStream("/tmp/regexTemp"))); }
        //catch (IOException e) { 
        //	state.output.fatal("An IOException occurred when trying to read from the file " 
        //			+ loadInds + ".  The IOException was: \n" + e); }
        
        //try { readSubpopulation(state, new DataInputStream(new FileInputStream("/tmp/regexTemp"))); }
        //catch (IOException e) { state.output.fatal("An IOException occurred when trying to read from the file " + loadInds + ".  The IOException was: \n" + e); }

        //System.out.println("--->");
		//for (int i=0; i<individuals.length; i++)
		//	System.out.println("- " + ((IndividualRegex)individuals[i]).getGenomeBinary());
    }
}
