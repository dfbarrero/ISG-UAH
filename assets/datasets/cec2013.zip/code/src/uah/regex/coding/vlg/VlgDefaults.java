
package uah.regex.coding.vlg;
import ec.util.Parameter;
import ec.*;


public final class VlgDefaults implements DefaultsForm {
	public static final String P_VLG = "vlg";

	/** Returns the default base. */
	public static final Parameter base() {
		return new Parameter(P_VLG);
	}
}
