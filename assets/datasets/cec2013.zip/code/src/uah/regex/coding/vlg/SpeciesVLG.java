package uah.regex.coding.vlg;

import ec.EvolutionState;
import ec.Individual;
import ec.util.Parameter;
import ec.vector.VectorIndividual;
import ec.vector.VectorSpecies;

@SuppressWarnings("serial")
public class SpeciesVLG extends VectorSpecies {
    public static final String P_VARIABLEVECTORSPECIES = "var-species";
    
    public final static String P_GENMIN = "gen-min-size";
    public final static String P_GENMAX = "gen-max-size";
    
    public int minGenSize;
    public int maxGenSize;

 //   public String[] coding;
    
	public Parameter defaultBase() {
    	return VlgDefaults.base().push(P_VARIABLEVECTORSPECIES);
    }

    public void setup(final EvolutionState state, final Parameter base) {	
    	// setup constraints  FIRST so the individuals can see them when they're
    	// set up.

    	Parameter def = defaultBase();

    	minGenSize = state.parameters.getInt(
    			base.push(P_GENMIN),def.push(P_GENMIN), 0);
    	
    	maxGenSize = state.parameters.getInt(
    			base.push(P_GENMAX),def.push(P_GENMAX), 0);
    	if (minGenSize > maxGenSize)
    		state.output.error("BitVariableVectorSpecies must have a minimun genome size smaller than the maximun genome size",
    				base.push(P_GENMAX),def.push(P_GENMAX));
    	if (minGenSize == 0)
    		state.output.error("BitVariableVectorSpecies must have at least 1 bit",
    				base.push(P_GENMAX),def.push(P_GENMAX));
    	
    	state.output.exitIfErrors();

    	// NOW call super.setup(...), which will in turn set up the prototypical individual
    	super.setup(state, base);
    }

    public Individual newIndividual(final EvolutionState state, int thread) {
    	VectorIndividual newind = (VectorIndividual)(super.newIndividual(state, thread));

    	newind.reset(state, thread);
    	return newind;
    }
}
