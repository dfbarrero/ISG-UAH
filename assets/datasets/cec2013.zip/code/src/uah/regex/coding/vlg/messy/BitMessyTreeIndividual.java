package uah.regex.coding.vlg.messy;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Map;
import java.util.TreeMap;

import uah.regex.util.Util;

import ec.EvolutionState;
import ec.util.Parameter;
import ec.vector.VectorIndividual;
import ec.vector.VectorSpecies;

@SuppressWarnings("serial")
public class BitMessyTreeIndividual extends BitMessyIndividual {
	static public final String P_MESSYTREE = "messytree";
	static private boolean verbose = false;
	@SuppressWarnings("unused")
	private TreeMap<Integer, LinkedList<Integer>> rna = null;
	private int min = Integer.MAX_VALUE, max = 0;
	static private int chunksize;
	static private int locusSize;
	static private int valueSize;
	static private float probability;

	// We call getRNA() to force min and max initialization
	public int getMin() { getRNA(); return min; }
	public int getMax() { getRNA(); return max; }

	public void setup(final EvolutionState state, final Parameter base) {
		super.setup(state, base);
	}

	public Parameter defaultBase() {
		return MessyDefaults.base().push(P_MESSYTREE);
	}
    
    public void defaultCrossover(EvolutionState state, int thread, VectorIndividual ind) {
    	BitMessyTreeIndividual ind1 = this;
    	BitMessyTreeIndividual ind2 = (BitMessyTreeIndividual) ind;
    	BitMessySpecies s = ((BitMessySpecies) state.population.subpops[0].species);

    	chunksize = s.chunksize;
    	locusSize = s.locusSize;
    	valueSize = s.valueSize;
    	probability = s.crossoverProbability;
    	
    	if (!(ind2 instanceof BitMessyTreeIndividual))
    		state.output.fatal("Messy crossover requires two BitMessyIndividual individuals");
    	
       	if (verbose) System.out.print("\nCrossing ... " + this.binaryToCodons() + " with " + ind2.binaryToCodons());
       	if (verbose) System.out.println("\nCrossing ... " + this.binaryToCodonsNumbers() + " with " + ind2.binaryToCodonsNumbers());
       	
       	// Init RNA
        ind1.getRNA();
    	ind2.getRNA();
    	
    	//System.out.printf("%s -> %s\n",  binaryToCodons(), binaryToRegexp());
    	
    	if (verbose) {
    		ind1.printRNA();
    		System.out.println("------------");
    		ind2.printRNA();
    		System.out.flush();
    	}
    
    	// And here we go!
    	switch(s.crossoverType)
    	{
    	case VectorSpecies.C_ONE_POINT:
    		onePointCrossover(state, thread, ind);
    		break;
    		
    	case VectorSpecies.C_TWO_POINT: 
    		twoPointCrossover(state, thread, ind);
    		break;
    		
    	case VectorSpecies.C_ANY_POINT:
    		anyPointCrossover(state, thread, ind);
    		break;
    	}
    	
    	if (verbose) {
    		System.out.println("Final regex: " + this.binaryToRegexp());
    		System.out.println("Final codons: " + this.binaryToCodons());
    		System.out.println("Final numbers: " + this.binaryToCodonsNumbers());
    	}
    	
    	//System.out.printf("----> %s + %s = %s\n", codons1, ind2.binaryToCodons(), binaryToCodons());
    	//System.out.printf("----> %s + %s = %s\n", regex1, ind2.binaryToRegexp(), this.binaryToRegexp());
    }
    
    private void anyPointCrossover(EvolutionState state, int thread,
			VectorIndividual ind) {
       	BitMessyTreeIndividual ind1 = this;
    	BitMessyTreeIndividual ind2 = (BitMessyTreeIndividual) ind;
    	
		// We do not crossover if both chromosomes are empty
		if ((ind1.getMax() == 0) && ind2.getMax() == 0) return;

		int min = (ind1.getMin() < ind2.getMin())? ind1.getMin() : ind2.getMin();
		int max = (ind1.getMax() > ind2.getMax())? ind1.getMax() : ind2.getMax();
		
		int genes1=0;//, genes2=0;
		
		TreeMap<Integer, LinkedList<Integer>> partA = new TreeMap<Integer, LinkedList<Integer>>();
//		TreeMap<Integer, LinkedList<Integer>> partB = new TreeMap<Integer, LinkedList<Integer>>();

		TreeMap<Integer, LinkedList<Integer>> rnaA = ind1.getRNA();
		TreeMap<Integer, LinkedList<Integer>> rnaB = ind2.getRNA();
		// Split individual one
		
		for (int i = min; i<=max; i++) {
			Integer key = new Integer(i);
			
			if (!rnaA.containsKey(key) && !rnaB.containsKey(key))
				// There is no gen for this locus
				continue;

			if (state.random[thread].nextBoolean(probability)) {
				// Do crossover
				if (rnaB.containsKey(key)) {
					partA.put(key, rnaB.get(key));
					genes1 += rnaB.get(key).size();
				}
			} else { 
				// Do not crossover
				if (rnaA.containsKey(key)) {
					partA.put(key, rnaA.get(key));
					genes1 += rnaA.get(key).size();
				}
			}
		}
    	
    	if (verbose) {
    		System.out.println("partA:"); printRNA(partA);
 //   		System.out.println("partB:"); printRNA(partB);
    		System.out.println("Genes: " + genes1);
    	}
    	
    	setRNA(partA, genes1);
	}
    
	private void twoPointCrossover(EvolutionState state, int thread,
			VectorIndividual ind) {
       	BitMessyTreeIndividual ind1 = this;
    	BitMessyTreeIndividual ind2 = (BitMessyTreeIndividual) ind;
    	
		// We do not crossover if both chromosomes are empty
		if ((ind1.getMax() == 0) && ind2.getMax() == 0) return;

		int min = (ind1.getMin() < ind2.getMin())? ind1.getMin() : ind2.getMin();
		int max = (ind1.getMax() > ind2.getMax())? ind1.getMax() : ind2.getMax();
		
		if (verbose) System.out.printf("Min: %d, max: %d\n", min, max);
		
		int point1 = ((max-min)>0? state.random[thread].nextInt(max-min) + min : min);
		int point2 = ((max-min)>0? state.random[thread].nextInt(max-min) + min : min);
		
		if (point1 > point2) {
			int temp = point2;
			point2 = point1;
			point1 = temp;
		}
		
		int genes1=0, genes2=0;

		if (verbose) System.out.printf("--\nPoint 1: %d\n", point1);
		if (verbose) System.out.printf("Point 2: %d\n--\n", point2);
		
		if (point1 == point2) return;
		
		TreeMap<Integer, LinkedList<Integer>> partA = new TreeMap<Integer, LinkedList<Integer>>();
		TreeMap<Integer, LinkedList<Integer>> partB = new TreeMap<Integer, LinkedList<Integer>>();

		// Split individual one
		for (Map.Entry<Integer, LinkedList<Integer>> entry : ind1.getRNA().entrySet()) {
			int point = entry.getKey();

			if (((point < point1) || (point > point2))) {
				partA.put(entry.getKey(), entry.getValue());
				genes1 += entry.getValue().size();
			} else {
				partB.put(entry.getKey(), entry.getValue());
				genes2 += entry.getValue().size();
			}
		}
    	
		// Split individual two
    	for (Map.Entry<Integer, LinkedList<Integer>> entry: ind2.getRNA().entrySet()) {
			int point = entry.getKey();
			
			if ((point < point1) || (point > point2)) {
				partB.put(entry.getKey(), entry.getValue());
				genes2 += entry.getValue().size();
			} else {
				partA.put(entry.getKey(), entry.getValue());
				genes1 += entry.getValue().size();
			}
    	}
    	
    	if (verbose) {
    		System.out.println("partA:"); printRNA(partA);
    		System.out.println("partB:"); printRNA(partB);
    		System.out.println("Genes: " + genes1);
    	}
    	
    	setRNA(partA, genes1);
	}
    
	protected TreeMap<Integer, LinkedList<Integer>> getRNA() { 	
		TreeMap<Integer, LinkedList<Integer>> rna = new TreeMap<Integer, LinkedList<Integer>>();
		min=999999; max=0;
		
		for (int gen=0; gen<genome.length/chunksize; gen++) {
			int locus, value;
			
			//Retrieve locus
			String buffer = "";
			for (int i=0; i<locusSize; i++)
				buffer +=  (genome[gen*chunksize+i]==true)? "1" : "0";
			locus = Integer.parseInt(buffer.toString(), 2);

			if (locus < min) min = locus;
			if (locus > max) max = locus;
			
			//Retrieve value
			buffer = "";
			for (int i=0; i<valueSize; i++) 
				buffer += (genome[gen*chunksize+locusSize+i]==true)? "1" : "0";
			value = Integer.parseInt(buffer.toString(), 2);//%coding.length;
			
			// Build RNA
			if (!rna.containsKey(new Integer(locus))) {
				LinkedList<Integer> temp = new LinkedList<Integer>();
				temp.add(new Integer(value));
				rna.put(new Integer(locus), temp);
			} else rna.get(new Integer(locus)).add(new Integer(value));
		}
		
		this.rna = rna;
		return rna;
    }
    
    private void onePointCrossover(EvolutionState state, int thread, VectorIndividual ind) {
    	BitMessyTreeIndividual ind1 = this;
    	BitMessyTreeIndividual ind2 = (BitMessyTreeIndividual) ind;
    	
		// We do not crossover if both chromosomes are empty
		if ((ind1.getMax() == 0) || ind2.getMax() == 0) return;

		int min = (ind1.getMin() < ind2.getMin())? ind1.getMin() : ind2.getMin();
		int max = (ind1.getMax() > ind2.getMax())? ind1.getMax() : ind2.getMax();
		
		int point = ((max-min)>0? state.random[thread].nextInt(max-min) + min : min);
		int genes1=0, genes2=0;

		if (verbose) System.out.printf("--\nPoint: %d\n--\n", point);
		
		TreeMap<Integer, LinkedList<Integer>> partA = new TreeMap<Integer, LinkedList<Integer>>();
		TreeMap<Integer, LinkedList<Integer>> partB = new TreeMap<Integer, LinkedList<Integer>>();

		// Split individual one
    	for (Map.Entry<Integer, LinkedList<Integer>> entry: ind1.getRNA().entrySet()) {
    		if (entry.getKey()<point) {
    			partA.put(entry.getKey(), entry.getValue());
    			genes1 += entry.getValue().size();
    		} else { 
    			partB.put(entry.getKey(), entry.getValue()); 
    			genes2 += entry.getValue().size();
    		}
    	}

		// Split individual two
    	for (Map.Entry<Integer, LinkedList<Integer>> entry: ind2.getRNA().entrySet()) {
    		if (entry.getKey()<point) {
    			partB.put(entry.getKey(), entry.getValue());
    			genes2 += entry.getValue().size();
    		} else {
    			partA.put(entry.getKey(), entry.getValue());
    			genes1 += entry.getValue().size();
    		}
    	}
    	
    	if (verbose) {
    		System.out.println("partA:"); printRNA(partA);
    		System.out.println("partB:"); printRNA(partB);
    	}
    	
    	setRNA(partA, genes1);
    	// RNA to binary        	
//       	boolean[] newGenome2 = new boolean[genes2 * (s.locusSize+s.valueSize)];
    }
    
    private void setRNA(TreeMap<Integer, LinkedList<Integer>> rna, int genesSize)
    {
    	boolean[] newGenome1 = new boolean[genesSize * (locusSize+valueSize)];

    	int genes = 0;
    	for (Map.Entry<Integer, LinkedList<Integer>> entry: rna.entrySet()) {
    		String locus, value;

    		LinkedList<Integer> temp = entry.getValue();
    		// Shuffle the genes to avoid crossover biases
    		Collections.shuffle(temp);
    		for (Integer values: temp) {
    			locus = Integer.toBinaryString(entry.getKey());
    			value = Integer.toBinaryString(values);

    			while (locus.length() != locusSize) locus = "0"+locus;
    			while (value.length() != valueSize) value = "0"+value;

    			boolean[] locusBool = Util.stringToBooleanArray(locus);
    			boolean[] valueBool = Util.stringToBooleanArray(value);

    			// Copy string to chromosome
    			for (int i=0; i<locusSize; i++)
    				newGenome1[genes* (locusSize+valueSize) + i] =
    					locusBool[i];
    			for (int i=0; i<valueSize; i++)
    				newGenome1[genes* (locusSize+valueSize) + locusSize + i] =
    					valueBool[i];

    			//if (verbose) {
    			//	System.out.printf("(%d, %d) = (", entry.getKey(), values);
    			//	System.out.print(locus + ", " + value +")\n");
    			//System.out.printf("%d, %d)\n", Integer.locus + ", " + value +")");
    			//}
    			genes++;
    		}
    	}
    	//Util.printBoolean(newGenome1); System.out.println("<---- genome");
    	setGenome(newGenome1);
    }
    
    protected void printRNA() {printRNA(getRNA());}
    
    protected void printRNA(TreeMap<Integer, LinkedList<Integer>> rna) {
    	for (Map.Entry<Integer, LinkedList<Integer>> i: rna.entrySet()) {
    		System.out.printf("%d --> ", i.getKey());
    		LinkedList<Integer> temp = i.getValue();
    		for (Integer j: temp) System.out.printf("%d ", j);
    		System.out.printf("\n");
    	}
 //   	System.out.println("Min: " + getMin() + " , max:" + getMax());
    }
    
	public void setGenome(boolean[] gen) {
		this.genome = (boolean[]) gen;
		getRNA();
	}
}
