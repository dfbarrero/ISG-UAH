package uah.regex.coding.vlg.messy;

import java.util.HashMap;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import uah.regex.coding.vlg.IndividualVLG;
import uah.regex.util.Util;

import ec.EvolutionState;
import ec.util.Output;
import ec.util.Parameter;

public abstract class BitMessyIndividual extends IndividualVLG {
	public static final String P_MESSY = "messy";

	private final static boolean verbose = false;

	private BitMessySpecies s;
	
    // Copy inverse conding here from MessyCod to improve performance,
    // It is better to store the key as boolean instread string but
    // MessyCod does not have access to the locus size
    public Map<String, boolean[]> inverseCoding = new HashMap<String, boolean[]>();
    
    public Parameter defaultBase() {
		return MessyDefaults.base().push(P_MESSY);
	}

//	public void defaultCrossover(EvolutionState state, int thread,
//			VectorIndividual ind) {
		// System.out.printf("%s -> %s\n", binaryToCodons(), binaryToRegexp());
//		super.defaultCrossover(state, thread, ind);
//	}
    
    public void setup(final EvolutionState state, final Parameter base)
    {
    	super.setup(state, base);
 
    	Parameter def = defaultBase();

    	if (!(species instanceof BitMessySpecies)) 
    		state.output.fatal("BitMessyIndividual requires an BitMessySpecies", base, def);

    	s = (BitMessySpecies) species;
    	
    	if (verbose) 
    		System.out.println("Construyendo inverso en la especie: \n" + coding);

 //   	Boolean keys[] = new Boolean[s.locusSize];
    	boolean values[];
        for (int i=0; i<coding.length; i++) {
        	String valueBinaryS = Integer.toBinaryString(i);
        		
        	// Normalize key length to the number of bits indicated by valueSize        		
        	while (valueBinaryS.length() != s.valueSize) 
        		valueBinaryS = "0" + valueBinaryS;
        	
        	values = Util.stringToBooleanArray(valueBinaryS);
 //       	System.out.println(i + " ---> "+ Util.booleanToInt(values));
        	inverseCoding.put(coding[i], values);
        }
    }
	
    @Override
    public boolean checkCoding() {
		if (coding == null)
			state.output.fatal("Coding is empty");

		BitMessySpecies s = (BitMessySpecies) species;

		if (Math.pow(2, s.valueSize) < getCoding().length) {
			state.output.error("Cannot code " + getCoding().length
					+ " symbols with " + s.valueSize
					+ " bits. Increase value-size.");
			return false;
		}

    	if (((s.locusSize + s.valueSize) != s.chunksize) || ((s.locusSize + s.valueSize) != s.genomeSize)) {
    		state.output.error("locusSize + valueSize must have chunksize and genomeSize");
    		return false;
    	}
		
		return true;
    }
    
	public void reset(EvolutionState state, int thread) {
		super.reset(state, thread);
		
		BitMessySpecies s = (BitMessySpecies) species;
		int bias = Math.round((float) Math.pow((double) 2, (double) s.locusSize)/2);

		for (int locus=0; locus<genome.length/s.chunksize; locus++) {
			String binary = null;
			
//			if (!s.bias) state.output.warnOnce("Loci bias set to false");
			binary = s.bias ? Integer.toBinaryString(bias + locus) : Integer.toBinaryString(locus);
			
			// Normalize string size
			while (binary.length() < s.locusSize)
				binary = "0" + binary;	
			//System.out.println("-XXX--" + binary);
			if (binary.length() > s.locusSize)
				state.output.error("BitMessyIndividual: Insuficient locus bits to bias, please, increase locusSize or reduce gen-max-size.");

			// Copy locus in the genome
			for (int i=locus*s.chunksize; i<(locus*s.chunksize+s.locusSize); i++) {
				genome[i] = (binary.charAt(i-locus*s.chunksize)=='1')? true : false; 
			}

			//System.out.println("BitVariableVectorIndividual: Locus " + locus + " --> " + binary);
		}
		//System.out.println(this.genotypeToString());
		//binaryToRegexp();
	}
	
	public void printIndividualForHumans(EvolutionState state, int log, int verbosity) {
		state.output.print(binaryToRegexp(), Output.V_NO_GENERAL, log);
	}

	public String binaryToRegexp() {
		BitMessySpecies s = (BitMessySpecies) species;
		
		int[] locus = new int[genome.length/s.chunksize];
		int[] values = new int[genome.length/s.chunksize];
		
		StringBuffer regex = new StringBuffer("");
		
		// Retrieve locus and value for each gen in the genome
		for (int gen=0; gen<genome.length/s.chunksize; gen++) {
			//Retrieve locus
			String buffer = "";
			for (int i=0; i<s.locusSize; i++)
				buffer +=  (genome[gen*s.chunksize+i]==true)? "1" : "0";
			
			locus[gen] = Integer.parseInt(buffer.toString(), 2);
			
			//Retrieve value
			buffer = "";
			for (int i=0; i<s.valueSize; i++) 
				buffer += (genome[gen*s.chunksize+s.locusSize+i]==true)? "1" : "0";
			
			values[gen] = Integer.parseInt(buffer.toString(), 2);//%coding.length;
			//System.out.printf("(%d, %d)", locus[gen], values[gen]);
		}
		//System.out.printf("\n");

		// Build regex
		SortedMap<Integer, Integer> map = new TreeMap<Integer, Integer>();
		
		for (int gen=0; gen<genome.length/s.chunksize; gen++)
			if (!map.containsKey(locus[gen]))
				map.put(locus[gen], values[gen]);
		
		for (int i: map.values()) {
			regex.append(coding[i%coding.length]);
		}
		
		//System.out.println("-->" + regex);

		return regex.toString();
	}
	
	public String binaryToCodons() {
		BitMessySpecies s = (BitMessySpecies) species;

		int[] locus = new int[genome.length/s.chunksize];
		int[] values = new int[genome.length/s.chunksize];
		
		StringBuffer regex = new StringBuffer("(");
		
		// Retrieve locus and value for each gen in the genome
		for (int gen=0; gen<genome.length/s.chunksize; gen++) {
			//Retrieve locus
			String buffer = "";
			for (int i=0; i<s.locusSize; i++)
				buffer +=  (genome[gen*s.chunksize+i]==true)? "1" : "0";
			locus[gen] = Integer.parseInt(buffer, 2);
			
			//Retrieve value
			buffer = "";
			for (int i=0; i<s.valueSize; i++) 
				buffer += (genome[(gen*s.chunksize) + s.locusSize + i]==true)? "1" : "0";
			values[gen] = Integer.parseInt(buffer, 2);
			
			regex.append("(" + locus[gen] + ", " + coding[values[gen]%coding.length] + ")");
		}
		regex.append(")");

		return regex.toString();
	}
	
	public String binaryToCodonsNumbers() {
		BitMessySpecies s = (BitMessySpecies) species;

		int[] locus = new int[genome.length/s.chunksize];
		int[] values = new int[genome.length/s.chunksize];
		
		StringBuffer regex = new StringBuffer("(");
		
		// Retrieve locus and value for each gen in the genome
		for (int gen=0; gen<genome.length/s.chunksize; gen++) {
			//Retrieve locus
			String buffer = "";
			for (int i=0; i<s.locusSize; i++)
				buffer +=  (genome[gen*s.chunksize+i]==true)? "1" : "0";
			locus[gen] = Integer.parseInt(buffer.toString(), 2);
			
			//Retrieve value
			buffer = "";
			for (int i=0; i<s.valueSize; i++) 
				buffer += (genome[gen*s.chunksize+s.locusSize+i]==true)? "1" : "0";
			values[gen] = Integer.parseInt(buffer.toString(), 2);
			
			regex.append("(" + locus[gen] + ", " + values[gen] + ")");
		}
		regex.append(")");

		return regex.toString();
	}
}
