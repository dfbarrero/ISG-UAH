package uah.regex.coding.vlg.messy;

import uah.regex.coding.vlg.SpeciesVLG;
import ec.EvolutionState;
import ec.Individual;
import ec.util.Parameter;
import ec.vector.VectorIndividual;

@SuppressWarnings("serial")
public class BitMessySpecies extends SpeciesVLG {
    public static final String P_MESSYSPECIES = "messy-spe";
    
    public final static String P_LOCSIZE = "locus-size";
    public final static String P_VALUESIZE = "value-size";
    
    public final static String P_BIAS = "bias";
    
    public int locusSize;
    public int valueSize;
    
    public boolean bias;

 //   public String[] coding;
    // Copy inverse conding here from MessyCod to improve performance,
    // It is better to store the key as boolean instread string but
    // MessyCod does not have access to the locus size
 //   public Map<String, Boolean[]> inverseCoding = new HashMap<String, Boolean[]>();
    
    EvolutionState state;
    
	public Parameter defaultBase() {
    	return MessyDefaults.base().push(P_MESSYSPECIES);
    }

    public void setup(final EvolutionState state, final Parameter base) {	
    	// setup constraints  FIRST so the individuals can see them when they're
    	// set up.
    	Parameter def = defaultBase();
    	
    	locusSize = state.parameters.getInt(
    			base.push(P_LOCSIZE),def.push(P_LOCSIZE), 0);
    	
    	valueSize = state.parameters.getInt(
    			base.push(P_VALUESIZE),def.push(P_VALUESIZE), 0);
    	
    	bias = state.parameters.getBoolean(
    			base.push(P_BIAS),def.push(P_BIAS), true);
    	
    	state.output.exitIfErrors();

    	// NOW call super.setup(...), which will in turn set up the prototypical individual
    	super.setup(state,base);
    }

    public Individual newIndividual(final EvolutionState state, int thread) {
    	VectorIndividual newind = (VectorIndividual)(super.newIndividual(state, thread));

    	newind.reset( state, thread);
    	return newind;
    }
}
