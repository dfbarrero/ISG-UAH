package uah.regex;

import ec.EvolutionState;
import ec.Evolve;
import ec.util.Output;
import ec.util.Parameter;
import ec.util.ParameterDatabase;

public class MassiveEvolve extends Evolve {
	
	  public static void main(String[] args) {
		EvolutionState state = null;
		ParameterDatabase parameters;

		parameters = loadParameterDatabase(args);
		
		int min = parameters.getIntWithDefault(new Parameter("experiment.min"), null,
				1);
		if (min < 1)
			Output.initialError("The 'experiment.min' parameter must be >= 1 (or not exist, which defaults to 1)");

		int max = parameters.getIntWithDefault(new Parameter("experiment.max"), null, 100);
		if (min < 1)
			Output.initialError("The 'experiment.max' parameter must be >= 1 (or not exist, which defaults to 100)");		
		
		for (int i = min; i <= max; i++) {
			parameters = loadParameterDatabase(args);
			
			// Initialize the EvolutionState, then set its job variables
			state = initialize(parameters, 1); // pass in job# as the seed increment
			
			System.out.print(i + " ");
			
			state.job = new Object[1]; // make the job argument storage
			state.job[0] = new Integer(1); // stick the current job in our job storage
			state.runtimeArguments = args; // stick the runtime arguments in our storage

			// Here you can set up the EvolutionState's parameters further before it's setup(...).
			// This includes replacing the random number generators, changing values in state.parameters,
			// changing instance variables (except for job and runtimeArguments, please), etc.
			String prefix = parameters.getString(new Parameter("stat.file"), null);
			
			// Set output file name
			parameters.set(new Parameter("stat.file"), prefix+i);
			
			// now we let it go
			state.run(EvolutionState.C_STARTED_FRESH);
			cleanup(state); // flush and close various streams, print out parameters if necessary
			parameters = null; // so we load a fresh database next time around
		}

		System.exit(0);
	}
}
