package uah.regex.weka;

import weka.classifiers.Classifier;
import weka.classifiers.Sourcable;

import weka.core.Attribute;
import weka.core.Capabilities;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.Option;
import weka.core.RevisionUtils;
import weka.core.Utils;
import weka.core.WeightedInstancesHandler;
import weka.core.Capabilities.Capability;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.LinkedList;
import java.util.StringTokenizer;
import java.util.Vector;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import ec.EvolutionState;
import ec.Evolve;
import ec.simple.SimpleEvolutionState;
import ec.util.ParameterDatabase;

/**
 <!-- globalinfo-start -->
 * Class for building and using genetic based regex classifier. Predicts the mean (for a numeric class) or the mode (for a nominal class).
 * <p/>
 <!-- globalinfo-end -->
 *
 <!-- options-start -->
 * Valid options are: <p/>
 * 
 * <pre> -D
 *  If set, classifier is run in debug mode and
 *  may output additional info to the console</pre>
 * 
 <!-- options-end -->
 *
 * @author Eibe Frank (eibe@cs.waikato.ac.nz)
 * @version $Revision: 1.19 $
 */

public class WekaECJ extends Classifier implements WeightedInstancesHandler,
		Sourcable {
	static private String ecjConfig;
	private int generations = -1;
	private boolean stop = false;
	private String regex = null;
	private String parameter;
	private String parameterValue;
	private String extra = null;
	private String extraString = null;
	private String problem = null;
	
	private String tempFile = "/tmp/weka.log";
	private String statsPrefix = "/tmp/ECJ-temp/temp-";
	private String finalPrefix = "/tmp/ECJ-temp/last-";
	
	private String positivesFile = "/tmp/wekaPositives.log";
	private String negativesFile = "/tmp/wekaNegatives.log";
	private Pattern pattern = null;
	private static int runs = 1;

	/** for serialization */
	static final long serialVersionUID = 48055541465867954L;

	/** The class value 0R predicts. */
	private double m_ClassValue;

	/** The number of instances in each class (null if class numeric). */
	private double[] m_Counts;

	/** The class attribute. */
	private Attribute m_Class;

	/**
	 * Returns an enumeration describing the available options.
	 * 
	 * @return an enumeration of all the available options.
	 */
	public Enumeration<Option> listOptions() {
		Vector<Option> newVector = new Vector<Option>(2);

		newVector.addElement(new Option("\tIt must set, specifies the ECJ\n"
				+ "\tconfig file", "C", 1, "-C <config file>"));
		newVector.addElement(new Option(
				"\tNumber of generations that the EA will be run. Default config\n"
						+ "\tfile is used in case it is empty", "generations",
				1, "-generations <generations>"));
		newVector.addElement(new Option(
				"\tParameter that is being evaluated\n", "parameter",
				1, "-parameter"));
		newVector.addElement(new Option(
				"\tParameter value that is being evaluated\n", "value",
				1, "-value"));
		newVector.addElement(new Option(
				"\tStop when a ideal individual is found\n", "extra",
				0, "-stop"));
		newVector.addElement(new Option(
				"\tExtra user defined ECJ arguments. This parameter points a "
				+ "text file whose content will be passed to ECJ without modification\n", "extra",
				1, "-extra"));
		newVector.addElement(new Option(
				"\tUser defined problem. By default uah.regex.problem.RegexProblem\n", "problem",
				1, "-problem"));
		
		return newVector.elements();
	}

	public void setOptions(String[] options) throws Exception {
		// super.setOptions(options);
		ecjConfig = Utils.getOption("C", options);
		if (ecjConfig.trim().equals("")) {
			System.out.println("ECJ config file not found");
			System.exit(-1);
		}
		
		parameter = Utils.getOption("parameter", options);
		if (parameter.trim().equals("")) {
			System.out.println("Evaluated parameter not found");
			System.exit(-1);
		}
		
		parameterValue = Utils.getOption("value", options);
		if (parameterValue.trim().equals("")) {
			System.out.println("Evaluated parameter value not found");
			System.exit(-1);
		}
		
		extra = Utils.getOption("extra", options);
		if (extra.trim().equals("")) {
			extra = null;
		}
		
		// Get extra parameters
		if (extra != null) {
		    try {
		        BufferedReader input =  new BufferedReader(new FileReader(extra));
		        extraString = input.readLine();
		        input.close();
		    } catch (IOException e) {
		        System.out.println("WekaECJ could not read extra file." + e.getMessage());
		        System.out.println("Warning: Not using EXTRA parameters.");
		    }
		}

		problem = Utils.getOption("problem", options);
		if (problem.trim().equals("")) {
			problem = null;
		}
		
		String temp = Utils.getOption("generations", options);
		try {
			if (!temp.equals(""))
				generations = Integer.parseInt(temp);
		} catch (NumberFormatException e) {
			System.out.println("Number of generations is not a valid integer value");
			System.exit(-1);
		}
		stop = Utils.getFlag("stop", options);
	}

	/**
	 * Gets the current settings of the WekaECJ classifier.
	 * 
	 * @return an array of strings suitable for passing to setOptions
	 */
	public String[] getOptions() {
		String[] options = new String[20];
		int current = 0;

		options[current++] = "-C";
		options[current++] = " " + ecjConfig;
		options[current++] = "-param";
		options[current++] = parameter;
		options[current++] = "-value";
		options[current++] = parameterValue;

		if (generations != -1) {
			options[current++] = "-generations";
			options[current++] = " " + generations;
		}
		
		if (extra != null) {
			options[current++] = "-extra";
			options[current++] = extra;
		}
		
		if (problem != null) {
			options[current++] = "-problem";
			options[current++] = problem;
		}
		
		if (stop)
			options[current++] = "-stop";

		while (current < options.length) {
			options[current++] = "";
		}

		return options;
	}

	/**
	 * Returns a string describing classifier
	 * 
	 * @return a description suitable for displaying in the
	 *         explorer/experimenter gui
	 */
	public String globalInfo() {
		return "Wrapper class for ECJ evolutionary algorithms.";
	}

	/**
	 * Returns default capabilities of the classifier.
	 * 
	 * @return the capabilities of this classifier
	 */
	public Capabilities getCapabilities() {
		Capabilities result = super.getCapabilities();

		// attributes
		result.enable(Capability.STRING_ATTRIBUTES);
		// class
		result.enable(Capability.NOMINAL_CLASS);
		// instances
		result.setMinimumNumberInstances(0);

		return result;
	}

	/**
	 * Generates the classifier.
	 * 
	 * @param instances
	 *            set of instances serving as training data
	 * @throws Exception
	 *             if the classifier has not been generated successfully
	 */
	@SuppressWarnings("unchecked")
	public void buildClassifier(Instances instances) throws Exception {
		String statFile = statsPrefix + runs;
		String finalFile = finalPrefix + runs;
		
		ArrayList<String> positives = new ArrayList<String>();
		ArrayList<String> negatives = new ArrayList<String>();

		System.out.print(" " + runs);
		runs++;

		// can classifier handle the data?
		getCapabilities().testWithFail(instances);

		// Generate positive and negative samples
		Enumeration<Instance> enume = instances.enumerateInstances();
		while (enume.hasMoreElements()) {
			Instance instance = (Instance) enume.nextElement();
			Attribute classAttribute = instance.classAttribute();

			if (!instance.classIsMissing()) {
				switch ((int) instance.value(classAttribute)) {
				case 0:
					positives.add(instance.stringValue(instance.attribute(0)));
					break;
				case 1:
					negatives.add(instance.stringValue(instance.attribute(0)));
					break;
				}
				// System.out.printf("%s, %s\n",
				// instance.stringValue(instance.attribute(0)),
				// instance.stringValue(instance.attribute(1)));
			} else {
				System.out
						.println("Warning, Class missing, check out data set");
			}
		}

		FileWriter writer = new FileWriter(new File(positivesFile));
		for (String str : positives)
			writer.write(str + "\n");
		writer.close();
		writer = null;

		writer = new FileWriter(new File(negativesFile));
		for (String str : negatives)
			writer.write(str + "\n");

		writer.close();
		writer = null;

		if (m_Debug) {
			System.out.println("Positives: " + positives);
			System.out.println("Negatives: " + negatives);
		}
		
		// Execute GA
		SimpleEvolutionState state;
		LinkedList<String> list = new LinkedList<String>();

		// Must be parameters
		list.add("-file");
		list.add(ecjConfig);
		list.add("-p");
		list.add("eval.problem.positives=" + positivesFile);
		list.add("-p");
		list.add("eval.problem.negatives=" + negativesFile);
		list.add("-p");
		list.add("stat.file=" + statFile);
		list.add("-p");
		list.add("stat.child.0.file=" + finalFile);
		list.add("-p");
		list.add(parameter + "=" + parameterValue);
		
		// Optional parameters
		if (stop) {
			list.add("-p");
			list.add("quit-on-run-complete=true");
		} else {
			list.add("-p");
			list.add("quit-on-run-complete=false");			
		}

		if (generations > 0) {
			list.add("-p");
			list.add("generations=" + generations);
		}

		if (problem != null) {
			list.add("-p");
			list.add("eval.problem=" + problem);
		}
		
		if (extraString != null) {
			System.out.println("To EC: " + extraString);
			list.add(extraString);
		}

		// Run ECJ
		String[] args = (String[]) list.toArray(new String[list.size()]);
		
		if (m_Debug) {
			System.out.println("ARGS: ");
			for (String str: args) System.out.println(str);
		}
		
		ParameterDatabase parameters = Evolve.loadParameterDatabase(args);
		state = (SimpleEvolutionState) Evolve.initialize(parameters, 0);

//		state.output.setVerbosity(Output.ALL_LOGS);
		//System.out.print(" Executing ECJ ");
		state.run(EvolutionState.C_STARTED_FRESH);
		//System.out.print(" ECJ Finish ");
		Evolve.cleanup(state);

		// Check ECJ output
		File file = new File(finalFile);
		if (file.length() == 0) {
			throw new Exception("ECJ output file is empty. " + file);
		}
		
		// Read ECJ output
		// The regex is ghatered from the last line of the ECJ final log
		// Statistics class must be RegexFinalStatistics with regex option true
		LineNumberReader reader = new LineNumberReader(new FileReader(finalFile));
		reader.setLineNumber(reader.getLineNumber());
		String lastLine = reader.readLine(); // finalFile must contain only one line
		
		//System.out.println("\n----" + lastLine); System.out.flush();
		
		StringTokenizer tokenizer = new StringTokenizer(lastLine, " ");
		while (tokenizer.hasMoreElements()) regex = tokenizer.nextToken();

		//regex = tokenizer.nextToken().trim();
		regex = regex.trim();
		//System.out.println("Regex: " + regex);
		
		if (regex == null) {
			System.out.println("Evaluating null regular expression in WekaECJ");
			System.out.println("Check regex extraction");
		}
		
		pattern = Pattern.compile(regex);
		
		// Some clean up work ..
		file = new File(tempFile);
		file.delete();
		file = new File(positivesFile);
		file.delete();
		file = new File(negativesFile);
		file.delete();

		// ////////
		// remove instances with missing class
		instances = new Instances(instances);
		instances.deleteWithMissingClass();
	}

	/**
	 * Classifies a given instance.
	 * 
	 * @param instance
	 *            the instance to be classified
	 * @return index of the predicted class
	 */
	public double classifyInstance(Instance instance) {
		Matcher matcher = pattern.matcher(instance.stringValue(instance
				.attribute(0)));
//		System.out.println("classifyInstance(): "
//				+ instance.stringValue(instance.attribute(0))
//				+ (matcher.matches() ? " YES " : " NO"));

		return (matcher.matches() ? 0.0 : 1.0);
	}

	/**
	 * Calculates the class membership probabilities for the given test
	 * instance.
	 * 
	 * @param instance
	 *            the instance to be classified
	 * @return predicted class probability distribution
	 * @throws Exception
	 *             if class is numeric
	 */
	public double[] distributionForInstance(Instance instance) throws Exception {
		double probabilities[] = { 0.0, 0.0 };

		if (classifyInstance(instance) == 0.0)
			probabilities[0]++;
		else
			probabilities[1]++;

		return probabilities;

		/*
		 * if (m_Counts == null) { double[] result = new double[1]; result[0] =
		 * m_ClassValue; return result; } else { return (double [])
		 * m_Counts.clone(); }
		 */
	}

	/**
	 * Returns a string that describes the classifier as source. The classifier
	 * will be contained in a class with the given name (there may be auxiliary
	 * classes), and will contain a method with the signature:
	 * 
	 * <pre><code>
	 * public static double classify(Object[] i);
	 * </code></pre>
	 * 
	 * where the array <code>i</code> contains elements that are either
	 * Double, String, with missing values represented as null. The generated
	 * code is public domain and comes with no warranty.
	 * 
	 * @param className
	 *            the name that should be given to the source class.
	 * @return the object source described by a string
	 * @throws Exception
	 *             if the souce can't be computed
	 */
	public String toSource(String className) throws Exception {
		StringBuffer result;

		result = new StringBuffer();

		result.append("class " + className + " {\n");
		result.append("  public static double classify(Object[] i) {\n");
		if (m_Counts != null)
			result.append("    // always predicts label '"
					+ m_Class.value((int) m_ClassValue) + "'\n");
		result.append("    return " + m_ClassValue + ";\n");
		result.append("  }\n");
		result.append("}\n");

		return result.toString();
	}

	/**
	 * Returns a description of the classifier.
	 * 
	 * @return a description of the classifier as a string.
	 */
	public String toString() {
		if (regex == null) {
			return "GA regex: No model built yet.";
		} else
			return "GA regex: " + regex;
	}

	/**
	 * Returns the revision string.
	 * 
	 * @return the revision
	 */
	public String getRevision() {
		return RevisionUtils.extract("$Revision: 0.1 $");
	}

	/**
	 * Main method for testing this class. runClassifier calls Evaluate.evaluateModel()
	 * 
	 * @param argv
	 *            the options
	 */
	public static void main(String[] argv) {
	//	System.out.println("ARGUMENTOS: " );
	//	for (String str: argv) System.out.println(str);
		
		runClassifier(new WekaECJ(), argv);
	}
}
