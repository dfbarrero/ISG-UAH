package uah.regex.alphabet.lz;

import java.util.ArrayList;
import java.util.Collections;
import java.util.StringTokenizer;

import uah.regex.alphabet.Alphabet;
import uah.regex.alphabet.AlphabetDefaults;
import uah.regex.problem.RegexProblem;

import ec.EvolutionState;
import ec.util.Parameter;


public class AlphabetLZ extends Alphabet
{
    public static final String P_LZ = "lz";
//    public static final String P_FILE = "file";
    public static final String P_LENGTH = "length";
    public static final String P_SYMBOLS = "symbols";
    public static final String P_MINSYMBOLS = "minSymbols"; // Default 1
    public static final String P_TOKENS = "tokens";
    public static final String P_MINTOKENS = "minTokens"; // Default 3
    
    public Parameter base() {
    	return AlphabetDefaults.base().push(P_LZ);
    }
	
	public void setup(final EvolutionState state, final Parameter base) {
		super.setup(state, base);
		
		String[] symbols, tokens;
		int length=0, minSymbols=0, minTokens=0;

		Parameter bas = ((Parameter) base).push(P_LENGTH);
		Parameter def = base().push(P_LENGTH);
		try {
			length = state.parameters.getInt(bas, def);
			
			bas = ((Parameter) base).push(P_MINSYMBOLS);
			def = base().push(P_MINSYMBOLS);
			minSymbols = state.parameters.getInt(bas, def, 1);
			
			bas = ((Parameter) base).push(P_MINTOKENS);
			def = base().push(P_MINTOKENS);
			minTokens = state.parameters.getInt(bas, def, 3);
		} catch (NumberFormatException e) {
			state.output.fatal(e.getMessage(), bas, def);
		}
		
//    	file = state.parameters.getString(((Parameter) base).push(P_FILE),
//    			base().push(P_FILE));
//    	if (file == null) state.output.fatal("Examples file not found",
//    			((Parameter) base).push(P_FILE), base().push(P_FILE));
    	
    	// Parse symbols
		String string;		
    	string = state.parameters.getString(base.push(P_SYMBOLS),
    			base().push(P_SYMBOLS));
    	if (string == null)
    		state.output.fatal("Coding not found ", base.push(P_SYMBOLS), base().push(P_SYMBOLS));
    	
    	// Parse coding parameter
    	StringTokenizer st = new StringTokenizer(string);
    	symbols = new String[st.countTokens()];
    	for (int i=0; st.hasMoreTokens(); i++)
    		symbols[i] = st.nextToken();
    	
    	// Parse tokens	
    	string = state.parameters.getString(base.push(P_TOKENS),
    			base().push(P_TOKENS));
    	if (string == null)
    		state.output.fatal("Tokens not found ", base.push(P_TOKENS), base().push(P_TOKENS));
    	
    	// Parse coding parameter
    	st = new StringTokenizer(string);
    	tokens = new String[st.countTokens()];
    	for (int i=0; st.hasMoreTokens(); i++)
    		tokens[i] = st.nextToken();
    	
    	// Create alphabet
    	LZInitializer alphabetBuilder = 
    		new LZInitializer(((RegexProblem) state.evaluator.p_problem).positiveSamples, 
    		symbols, false);
		ArrayList<LZInitializer.Entry> arraySymbols, atomicRegex;
		
    	if (verbose) {

    	} 
    	
   		arraySymbols = alphabetBuilder.getSymbolsMinCount(minSymbols);
 		atomicRegex = alphabetBuilder.getAtomicRegexMinCount(minTokens);
   	    	    	
    	// Add symbols to the coding
    	ArrayList<String> temp = new ArrayList<String>();
    	for (String str: coding) temp.add(str);
    	for (int i=0; i<arraySymbols.size(); i++) temp.add(arraySymbols.get(i).getToken());
    	for (int i=0; i<atomicRegex.size(); i++) temp.add(atomicRegex.get(i).getToken());
    	for (String str : tokens) temp.add(str);
//    	for (int i=temp.size(); i<alphabetSize; i++) temp.add(""); // Fill with empty strings
    	
    	Collections.shuffle(temp);

    	// Finally we build the coding
    	coding = new String[temp.size()];
    	for (int i=0; i<temp.size(); i++) coding[i] = temp.get(i);
    	
    	if (verbose) {
			System.out.println("Looking for coding up to " + length + " symbols.");
    		StringBuffer buffer = new StringBuffer();
    		for (String str: symbols) buffer.append(" " + str);
    		System.out.printf("Symbols (fixed): " + buffer); 
    		System.out.printf("\nEncontrados %d s�mbolos, min %d, seleccionando %d: %s\n", 
    				alphabetBuilder.countSymbols(), 
    				minSymbols,
    				alphabetBuilder.getSymbolsMinCount(minSymbols).size(), 
    				alphabetBuilder.getSymbolsMinCount(minSymbols));
    		System.out.printf("Encontrados %d tokens, min %d, seleccionando %d: %s\n", 
    				alphabetBuilder.countAtomicRegex(), 
    				minTokens,
    				alphabetBuilder.getAtomicRegexMinCount(minTokens).size(), 
    				alphabetBuilder.getAtomicRegexMinCount(minTokens));
      		System.out.printf("Utilizando %d simbolos, %d tokens, %d simbolos fijos.\n", arraySymbols.size(), atomicRegex.size(), atomicRegex.size());
       		System.out.printf("Alphabet LZ (%d): %s\n", coding.length, getPrettyAlphabet());
    	}
	}
}
