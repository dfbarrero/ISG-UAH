/* Atomico.java
   Copyright (C) 2008 David F. Barrero <david.barrero@aut.uah.es>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, version 2.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA. 
*/
package uah.regex.alphabet.lz;

import java.util.Collections;
import java.util.TreeMap;
import java.util.ArrayList;

public class LZInitializer {	
//	static private String[] symbols;
	
	static private TreeMap<String, LZInitializer.Entry> dictionary = new TreeMap<String, LZInitializer.Entry>();
	static private TreeMap<String, LZInitializer.Entry> symbolCount = new TreeMap<String, LZInitializer.Entry>();

	private ArrayList<LZInitializer.Entry> listAtom;
	private ArrayList<LZInitializer.Entry> listSymbols;
	
	public static class Entry implements Comparable<Entry> {
		private String token;
		private int count;
		
		/**
		 * @param token
		 * @param count
		 */
		public Entry(String token, int count) {
			super();
			this.token = token;
			this.count = count;
		}
		
		public String getToken() {
			return token;
		}
		public void setToken(String token) {
			this.token = token;
		}
		public int getCount() {
			return count;
		}
		public void setCount(int count) {
			this.count = count;
		}
		public String toString() {
			return token + "="+ count;
			//return "" + count;
		}

		/* (non-Javadoc)
		 * @see java.lang.Object#hashCode()
		 */
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + count;
			result = prime * result + ((token == null) ? 0 : token.hashCode());
			return result;
		}

		/* (non-Javadoc)
		 * @see java.lang.Object#equals(java.lang.Object)
		 */
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			final Entry other = (Entry) obj;
			if (count != other.count)
				return false;
			if (token == null) {
				if (other.token != null)
					return false;
			} else if (!token.equals(other.token))
				return false;
			return true;
		}

		public int compareTo(Entry arg) {
			if (count > arg.getCount()) return -1;
			else if (count == arg.getCount()) return 0;
			else return 1;
		}
	}
			
	public LZInitializer(String[] examples, String[] symbols, boolean verbose) {
		for (String line : examples) {
			// Read examples

			for (String symbol : symbols) {
				// Split the example with each symbol
				String[] tokens = line.split(symbol);
				if (verbose)
					System.out.printf("--> %s\t%d-->", symbol, tokens.length);

				// Contamos los s�mbolos
				if (tokens.length == 1) {
					// The string does not contain the symbol
					if (verbose)
						System.out.println(line + " --");
					continue;
				} else {
					if (!symbolCount.containsKey(symbol))
						// New symbol
						symbolCount.put(symbol, new LZInitializer.Entry(symbol,
								tokens.length - 1));
					else {
						int temp = symbolCount.get(symbol).getCount();
						symbolCount.get(symbol).setCount(
								temp + tokens.length - 1);
					}
				}

				// Contamos los tokens
				for (String token : tokens) {
					// Register tokens
					if (verbose)
						System.out.printf("%sX", token);

					if (token.trim().equals(""))
						continue;

					if (!dictionary.containsKey(token)) {
						dictionary.put(token, new LZInitializer.Entry(token,
								(int) 1));
					} else {
						int count = dictionary.get(token).getCount() + 1;
						dictionary.get(token).setCount(count);
					}
				}
				if (verbose)
					System.out.println("; ");
			}
			if (verbose)
				System.out.println("");
		}

		// Order results
		listAtom = new ArrayList<LZInitializer.Entry>(dictionary.values());
		listSymbols = new ArrayList<LZInitializer.Entry>(symbolCount.values());
		Collections.sort(listAtom);
		Collections.sort(listSymbols);
	}

	public int countSymbols() {return listSymbols.size();}
	
	public int countAtomicRegex() {return listAtom.size();}
	
	public ArrayList<LZInitializer.Entry> getSymbols(int number) {
		ArrayList<LZInitializer.Entry> temp = new ArrayList<LZInitializer.Entry>();
		
		for (int i=0; i<number; i++) {
			temp.add(listSymbols.get(i));
		}
		
		return temp;
	}

	public ArrayList<LZInitializer.Entry> getAtomicRegex(int number) {
		ArrayList<LZInitializer.Entry> temp = new ArrayList<LZInitializer.Entry>();
		
		for (int i=0; i<number; i++) {
			try {
				if (listAtom.get(i).getCount() > 1) temp.add(listAtom.get(i));
				else temp.add(new LZInitializer.Entry("", 0));
			} catch (IndexOutOfBoundsException e) {
				temp.add(new LZInitializer.Entry("", 0));
			}
		}
		
		return temp;
	}
	public ArrayList<LZInitializer.Entry> getSymbolsMinCount(int count) {
		ArrayList<LZInitializer.Entry> temp = new ArrayList<LZInitializer.Entry>();
		
		for (LZInitializer.Entry i: listSymbols) {
			if (i.getCount() >= count) temp.add(i);
		}
		
		return temp;
	}

	public ArrayList<LZInitializer.Entry> getAtomicRegexMinCount(int count) {
		ArrayList<LZInitializer.Entry> temp = new ArrayList<LZInitializer.Entry>();
		
		for (LZInitializer.Entry i: listAtom) {
			if (i.getCount() >= count) temp.add(i);
		}
		
		return temp;
	}
	
//	public static void main(String[] args) {
//		if (args.length == 0) {
//			System.out.println(args[0] + "[file]");
//			System.exit(-1);
//		}
//		
//	    String[] symbols = {"\\.", "/", "\\(", "\\)", "-", ":", "@", ","};
//	    
//		String file = args[0];
//		LZInitializer LZ = new LZInitializer(file, symbols, false);
//	   	System.out.printf("Encontrados %d simbolos: %s \n", LZ.countSymbols(), LZ.getSymbolsMinCount(0));
//    	System.out.printf("Encontrados %d LZ symbols: %s\n", LZ.countAtomicRegex(), LZ.getAtomicRegexMinCount(3));
//	}
}
