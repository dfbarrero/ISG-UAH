package uah.regex.alphabet;

import java.util.StringTokenizer;

import ec.EvolutionState;
import ec.util.Parameter;

public class AlphabetFixed extends Alphabet {
    public static final String P_FIXED = "fixed";
    public static final String P_CODING = "coding";
    
	public Parameter base() { return AlphabetDefaults.base().push(P_FIXED); }
    
	public void setup(final EvolutionState state, final Parameter base) {
		super.setup(state, base);
		
		String string;		
    	string = state.parameters.getString(base.push(P_CODING),
    			base().push(P_CODING));
    	if (string == null)
    		state.output.fatal("Coding not found ", base.push(P_CODING), base().push(P_CODING));
    	if (string.trim().equals(""))
    		state.output.fatal("No symbols found in coding ", base.push(P_CODING), base().push(P_CODING));
    	
    	// Parse coding parameter
    	StringTokenizer st = new StringTokenizer(string);
    	
    	String[] temp = new String[st.countTokens() + coding.length];
    	for (int i=0; i<coding.length; i++)
    		temp[i] = coding[i];
    	for (int i=coding.length; st.hasMoreTokens(); i++)
    		temp[i] = st.nextToken();
    	
    	coding = temp;
    	
    	if (verbose) {
    		System.out.printf("Alphabet fixed (%d): %s\n", coding.length, getPrettyAlphabet());
    	}
	}
}
