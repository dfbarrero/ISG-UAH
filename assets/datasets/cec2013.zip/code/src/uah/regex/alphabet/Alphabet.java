package uah.regex.alphabet;

import ec.EvolutionState;
import ec.util.Parameter;

public abstract class Alphabet {
    public final static String P_VERBOSE = "verbose";
    public final static String P_EMPTY = "empty";
    public final static String P_SPACE = "space";
    
    public boolean verbose;
    public boolean empty;
    public boolean space;
    
	protected String[] coding;
	
	public Parameter defaultBase() { return AlphabetDefaults.base(); }
	
	// FIXME: defaultBase() does not perform correctly
	public void setup(final EvolutionState state, final Parameter base) {
		verbose = state.parameters.getBoolean(base.push(P_VERBOSE), defaultBase().push(P_VERBOSE), false);
		empty = state.parameters.getBoolean(base.push(P_EMPTY), defaultBase().push(P_EMPTY), false);
		space = state.parameters.getBoolean(base.push(P_SPACE), defaultBase().push(P_SPACE), false);
		
    	int increase = (space? 1 : 0) + (empty? 1 : 0);
    	coding = new String[increase];
    	
    	if (space && empty) {
    		coding[0] = " ";
    		coding[1] = "";
    	} else if (space && !empty) coding[0] = " ";
    	else if (!space && empty) coding[0] = "";
	}

	public String getPrettyAlphabet() {
    	StringBuffer buffer = new StringBuffer();
    	for (String str: coding) {
   			if (str.equals("")) { buffer.append(" [empty]"); continue; }
   			if (str.equals(" ")) { buffer.append(" [space]"); continue; }
   			buffer.append(" " + str);
   		}
   		return buffer.toString();
	}
	
	public String[] getCoding() { return coding; }
}
