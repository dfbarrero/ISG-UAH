package uah.regex.alphabet.lz;


import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Before;
import org.junit.Test;

public class LZInitializerTest {
	private String[] symbols = {"\\.", "/", "\\(", "\\)", "-", ":", "@"};
	private String[] tokens = {"\\d+", "\\w`+"};
	
	private int alphabetSize=5, length=5;
	private boolean verbose = true;
	
	@Before
	public void setUp() throws Exception {
	}
	
	@Test
	public void phone() {
		String[] samples = {"(22)264-1234", "(11)543-5673", "(44)234-1224",
				"(34)125-9753", "(21)122-5464"};
		
    	// Create alphabet
    	LZInitializer alphabetBuilder = new LZInitializer(samples, symbols, true);
		ArrayList<LZInitializer.Entry> arraySymbols, atomicRegex;
		
    	if (verbose) {
			System.out.println("Coding up to " + alphabetSize + " symbols with " + length + " bits.");
    		StringBuffer buffer = new StringBuffer();
    		for (String str: symbols) buffer.append(" " + str);
    		System.out.printf("Symbols (fixed): " + buffer); 
    		System.out.printf("\nEncontrados %d s�mbolos, seleccionando %d: %s\n", 
    				alphabetBuilder.countSymbols(),
    				alphabetBuilder.getSymbolsMinCount(5).size(), 
    				alphabetBuilder.getSymbolsMinCount(5));
    		System.out.printf("Encontrados %d regex at�micos, seleccionando %d: %s\n",
    				alphabetBuilder.countAtomicRegex(),
    				alphabetBuilder.getAtomicRegexMinCount(3).size(), 
    				alphabetBuilder.getAtomicRegexMinCount(3));
    	} 
    	assertEquals(0, alphabetBuilder.getAtomicRegexMinCount(3).size());
    	assertEquals(3, alphabetBuilder.getSymbolsMinCount(5).size());
    	
   		arraySymbols = alphabetBuilder.getSymbolsMinCount(5);
 		atomicRegex = alphabetBuilder.getAtomicRegexMinCount(3);
  		System.out.printf("Utilizando %d simbolos, %d regex atomicas, %d simbolos fijos.\n", arraySymbols.size(), atomicRegex.size(), tokens.length);
	}
	
	@Test
	public void email() {
		String[] samples = { "mdolores@uah.com", "dfbarrero@algo.com",
				"david@universidad.com", "dfdavid@uni.com",
				"algo@gmail.com", "blabla@congo.com", "bleble@taralila.com"};
		
    	// Create alphabet
    	LZInitializer alphabetBuilder = new LZInitializer(samples, symbols, true);
		ArrayList<LZInitializer.Entry> arraySymbols, atomicRegex;
		
    	if (verbose) {
			System.out.println("Coding up to " + alphabetSize + " symbols with " + length + " bits.");
    		StringBuffer buffer = new StringBuffer();
    		for (String str: symbols) buffer.append(" " + str);
    		System.out.printf("Symbols (fixed): " + buffer); 
    		System.out.printf("\nEncontrados %d s�mbolos, seleccionando %d: %s\n", 
    				alphabetBuilder.countSymbols(),
    				alphabetBuilder.getSymbolsMinCount(6).size(), 
    				alphabetBuilder.getSymbolsMinCount(6));
    		System.out.printf("Encontrados %d regex at�micos, seleccionando %d: %s\n", 
    				alphabetBuilder.countAtomicRegex(),
    				alphabetBuilder.getAtomicRegexMinCount(3).size(), 
    				alphabetBuilder.getAtomicRegexMinCount(3));
    	} 
    	assertEquals(1, alphabetBuilder.getAtomicRegexMinCount(3).size());
    	assertEquals(2, alphabetBuilder.getSymbolsMinCount(6).size());
    	
   		arraySymbols = alphabetBuilder.getSymbolsMinCount(6);
 		atomicRegex = alphabetBuilder.getAtomicRegexMinCount(3);
  		System.out.printf("Utilizando %d simbolos, %d regex atomicas, %d simbolos fijos.\n", arraySymbols.size(), atomicRegex.size(), tokens.length);
	}

}
