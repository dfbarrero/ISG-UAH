package uah.regex;

public interface PrintRegex {

}
