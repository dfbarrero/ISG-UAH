/* BitVariableVectorIndividual.java
   Copyright (C) 2008 David F. Barrero <david.barrero@aut.uah.es>

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, version 2.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307,
   USA. 
*/
package uah.regex;

import uah.regex.alphabet.Alphabet;
import uah.regex.util.Util;
import ec.EvolutionState;
import ec.util.Output;
import ec.util.ParamClassLoadException;
import ec.util.Parameter;
import ec.vector.BitVectorIndividual;
import ec.vector.VectorSpecies;

@SuppressWarnings("serial")
public abstract class IndividualRegex extends BitVectorIndividual {
	public static final String P_REGEX = "regex";
	
	public static final String P_ALPHABET = "alphabet";
	
	@SuppressWarnings("unused")
	protected EvolutionState state;
	protected Alphabet alphabet;
	//	protected VectorSpecies specie;
	protected String coding[]=null;
	
	public Parameter defaultBase() {
    	return new Parameter(P_REGEX);
    }
	
    public void setup(final EvolutionState state, final Parameter base) {
    	super.setup(state, base);
    	
    	this.state = state;
    	
    	try {    		
    		alphabet = (Alphabet) state.parameters.getInstanceForParameter(base.push(P_ALPHABET),
    				defaultBase().push(P_ALPHABET), Alphabet.class);
    		alphabet.setup(state, base.push(P_ALPHABET));
    		coding = alphabet.getCoding();
    	} catch (ParamClassLoadException e) {
    		System.out.println(e.getMessage());
    		state.output.error("Could not load alphabet " 
    			+ state.parameters.getString(base.push(P_ALPHABET), defaultBase().push(P_ALPHABET)));
    	} catch (NullPointerException e) { state.output.warnOnce("Alphabet class not defined");}
    	
    	if (!checkCoding())
    		state.output.fatal("Incorrect coding, check coding in config file");
    }
	
    public boolean checkCoding() {
		if (coding == null)
			state.output.fatal("Coding is empty");

		VectorSpecies s = (VectorSpecies) species;

		if (Math.pow(2, s.chunksize) < getCoding().length) {
			state.output.error("Cannot code " + getCoding().length
					+ " symbols with " + (int) Math.pow(2, s.chunksize)
					+ " bits. Increase chunsize.");
			return false;
		}

		return true;
    }
    
	public void printIndividualForHumans(EvolutionState state, int log, int verbosity) {
		state.output.print(binaryToRegexp(), Output.V_NO_GENERAL, log);
	}

	public String binaryToRegexp() {
//		RegexProblem problem = (RegexProblem) state.evaluator.p_problem;
//		String[] coding = problem.getCoding();
	
		StringBuffer string = new StringBuffer("");
		String regexp = "";
		int sum;
		int chunksize = ((VectorSpecies) species).chunksize;

    	if (coding == null) state.output.fatal("Coding is empty");  
		
		if (genome.length % chunksize != 0) {
			System.out.println("BitVectorIndividualRegex:: Genoma no es multimo del tama�o de gen");
			return null;
		}

		sum = 0;
		for (int j=0; j<(genome.length / chunksize); j++) {
			for(int i=0; i<chunksize; i++) {
				string.append((genome[j*chunksize+i] ? "1" : "0"));
			}

			sum = Integer.parseInt(string.toString(), 2);
//			System.out.printf("Bin: %s, Dec: %d\n", string, sum);
			try {
				regexp = regexp.concat(coding[sum%coding.length]);
			} catch (ArrayIndexOutOfBoundsException e) {
				System.out.println("ArrayIndexOutOfBoundsException, using an empty symbol");
				regexp = regexp.concat("");
			}
			sum=0;
			string = new StringBuffer("");
		}
		return regexp;
	}
	
	public String[] getCoding() { return coding; }
	
	public String getGenomeBinary() { return (Util.booleanArrayToString(this.genome)) ; }
}

