package uah.regex.problem;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

import uah.regex.IndividualRegex;

import ec.*;
import ec.simple.*;
import ec.util.Parameter;
import ec.vector.VectorDefaults;


@SuppressWarnings("serial")
public class RegexProblem extends Problem implements SimpleProblemForm
{
	public static final String P_BASIC = "basic";
	
	public static final String P_POSITIVES="positives";
	public static final String P_NEGATIVES="negatives";
	
	static protected int GEN_SIZE;
	
	protected EvolutionState state;
	
	static public String positiveFile;
	public String[] positiveSamples;
	
	static public String negativeFile;
	static public String[] negativeSamples;
	
	protected boolean verbose = false;
	
	public static int evaluations = 0;
	public static boolean ideal = false;

    public Parameter defaultBase() {
    	return VectorDefaults.base().push(P_BASIC);
    }
	
	public void setup(final EvolutionState state, final Parameter base) {	
    	Parameter def = defaultBase();
    	
    	positiveFile = state.parameters.getString(
    			base.push(P_POSITIVES),def.push(P_POSITIVES));
    	
    	// I know, I know, it is horrible, but ....
    	if ((positiveFile == null) && !(this instanceof RegexProblemArff))
    		state.output.warnOnce("Positive example set file not found",
    				base.push(P_POSITIVES),def.push(P_POSITIVES));

    	negativeFile = state.parameters.getString(
    			base.push(P_NEGATIVES),def.push(P_NEGATIVES)); 
    	if ((negativeFile == null) && !(this instanceof RegexProblemArff))
    		state.output.warnOnce("Negative example set file not found",
    				base.push(P_NEGATIVES),def.push(P_NEGATIVES));
    	    	
		super.setup(state,base);
		this.state = state;
		
		try {
			readSamples();
		}catch (FileNotFoundException e) {
			state.output.fatal("No se pudo abrir alguno de los ejemplos. "
					+ e.getMessage(), null);
		} catch (IOException e) {
			state.output.fatal("Error en lectura de archivo. " 
					+ e.getMessage(), null);
		}
    	state.output.exitIfErrors();
	}
	
    public void evaluate(final EvolutionState state,
                         final Individual ind,
                         final int subpopulation,
                         final int threadnum)
    {	
        if (ind.evaluated) return;
        
        if (!(ind instanceof IndividualRegex))
            state.output.fatal("It's not a IndividualRegex!!!", null);
       
        this.state = state;
        IndividualRegex ind2 = (IndividualRegex)ind;

        if (!(ind2.fitness instanceof SimpleFitness))
            state.output.fatal("Whoa!  It's not a SimpleFitness!!!",null);

        String regexp = ind2.binaryToRegexp();

        float fitness = fitness(regexp);
        
        if (verbose) state.output.message("Fitness: " + fitness);
        
        if ((fitness == (float) 1.0) && !ideal) {
        	ideal = true;
        	evaluations++;
        } else if (!ideal) {
        	evaluations++;
        }
        
        ((SimpleFitness)ind2.fitness).setFitness(state, fitness, (fitness == (float)1.0)? true : false);
        ind2.evaluated = true;
        }

    public void describe(final Individual ind, 
    		final EvolutionState state, 
    		final int subpopulation, 
    		final int threadnum,
    		final int log,
    		final int verbosity)
    {
     	System.out.println("REGEXP: " 
    			+ ((IndividualRegex) ind).binaryToRegexp());
    }
    
    protected void readSamples() throws IOException {
		int lines = 0;
		String line = "";

		if (verbose) {
			state.output.message("Reading ... " + positiveFile);
			state.output.message("Reading ... " + negativeFile);
			state.output.flush();
		}

		// Positive examples
		LineNumberReader reader = new LineNumberReader(new FileReader(positiveFile));

		line = reader.readLine(); // First line
		if (line == null) 
			throw new IOException("Empty positive samples file " + positiveFile);
		
		// Count lines
		while (line != null) {
			lines++;
			line = reader.readLine();
		}
		positiveSamples = new String[lines];
		//System.out.println(" Positive lines -- " + lines);

		// Read positive file
		reader = new LineNumberReader(new FileReader(positiveFile));
		for (int i=0; i<lines; i++) {
			line = reader.readLine();
			positiveSamples[i] = line;
		}
		
		// Negative examples
		reader = new LineNumberReader(new FileReader(negativeFile));
		lines = 0;
		
		line = reader.readLine(); // First line
		if (line == null) 
			throw new IOException("Empty positive samples file " + negativeFile);
		
		// Count lines
		while (line != null) {
			lines++;
			line = reader.readLine();
		}
		negativeSamples = new String[lines];
		//System.out.println("Negative lines -- " + lines);

		// Read positive file
		reader = new LineNumberReader(new FileReader(negativeFile));
		for (int i=0; i<lines; i++) {
			line = reader.readLine();
			negativeSamples[i] = line;
		}

		if (verbose) System.out.println(getPrettyExamples());
	}
    
    protected String getPrettyExamples() {
		String str = "Positive:";
		for (String s: positiveSamples) str = str + " " + s;
		str += "\nNegatives";
		for (String s: negativeSamples) str = str + " " + s;
		return str;
    }
    
    // TODO: Este m�todo deber�a ser desacoplado
	public float fitness(String regexp) {
		Pattern pattern = null;
		float positive = 0, negative = 0;
		//System.out.println(getPrettyExamples());
		if (verbose) System.out.println("");
		
		try {
			pattern = Pattern.compile(regexp);
					
			if (verbose)
				System.out.print("\nEvaluating regexp: " + regexp + "\n");

			//Positive examples
			for (String example: positiveSamples) {
				if (verbose) System.out.print(example+ " ... ");
				Matcher matcher = pattern.matcher(example);
				
				if (verbose) System.out.print(" --> ");
				int count = 0;
				
				while (matcher.find()) {
					count += matcher.end() - matcher.start();
				}
				
				if (verbose) System.out.print( "--> ");
				
				positive += ((float)count / (float)example.length());
				if (verbose)
					System.out.print(count + " of " + example.length() + " : " 
							+ String.format("%.3g", ((float)count / example.length()))
							+ "\n");
				matcher = null;
			}
			positive /= positiveSamples.length;
//			if (verbose) System.out.println("");
			
			//Negative examples
			for (String example: negativeSamples) {
				if (verbose) System.out.print("\n" + example + " ");
				Matcher matcher = pattern.matcher(example);
				
				if (matcher.matches()) negative++;
				if (verbose) 
					System.out.print(" --> "
							+ (matcher.matches() ? "true" : "false"));
				matcher = null;
			}
			negative /= negativeSamples.length;
		} catch (PatternSyntaxException e) {
			state.output.fatal("Could not compile regexp " + regexp, null);
		}

		float delta = positive - negative;

		if (verbose)
			System.out.println("\nPos: " + positive
				+ ", neg: " + negative + ", DELTA: " + delta + "\n");
		
		return delta;
	}
	
	public void reset() {
		evaluations = 0;
		ideal = false;
	}


	// It is used by the testing function in RegexProblemArff
	public void setVerbose(boolean verbose) {
		this.verbose = verbose;
	}
}
