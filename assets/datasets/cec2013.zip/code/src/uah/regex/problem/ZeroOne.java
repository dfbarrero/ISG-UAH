package uah.regex.problem;

import ec.*;
import ec.simple.*;
import ec.util.Parameter;
import ec.vector.*;

/**
 * This class is mean to be used for testing. It returns 0 and 1 by turns.
 * More or less it should evaluate 0 and 1, with +- 50% of ideals.
 * 
 * @author david
 */
public class ZeroOne extends RegexProblemArff implements SimpleProblemForm
{
	private static final long serialVersionUID = 1L;
	
	protected boolean verbose = false;
	
	protected float prob = 0;
	
	public static final String P_ZERO = "zero";
	public static final String P_PROB = "prob";
	
    public Parameter defaultBase() {
    	return VectorDefaults.base().push(P_ZERO);
    }
	
	public void setup(final EvolutionState state, final Parameter base) {	
    	Parameter def = defaultBase();
    	
    	prob = state.parameters.getFloat(base.push(P_PROB),def.push(P_PROB), 0, 1);
 //   	   System.out.println("Prob: " + prob);
       	state.output.exitIfErrors();
       	
		super.setup(state,base);
	}
	
	@Override
    public void evaluate(final EvolutionState state,
                         final Individual ind,
                         final int subpopulation,
                         final int threadnum)
    {	
        if (ind.evaluated) return;
        if (!(ind instanceof BitVectorIndividual))
            state.output.fatal("Whoa!  It's not a BitVectorIndividual!!!",null);
        
        BitVectorIndividual ind2 = (BitVectorIndividual) ind;
        float fitness = (state.random[threadnum].nextBoolean(prob))? (float) 1.0 : (float) 0.0;
        
        if ((fitness == (float) 1.0) && !ideal) {
        	ideal = true;
        	evaluations++;
        } else if (!ideal) {
        	evaluations++;
        }
        
        ((SimpleFitness)ind2.fitness).setFitness(state, fitness, (fitness==(float) 1.0));
        ind2.evaluated = true;
        }
}
