package uah.regex.problem;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.regex.Pattern;

import weka.core.Attribute;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;

import ec.*;
import ec.simple.*;
import ec.util.Parameter;

@SuppressWarnings("serial")
public class RegexProblemArff extends RegexProblem implements SimpleProblemForm
{
	public static final String P_ARFF="arff";
	public static String arffFile;
	

	public void setup(final EvolutionState state, final Parameter base) {	
    	Parameter def = defaultBase();
    	
    	arffFile = state.parameters.getString(base.push(P_ARFF), def.push(P_ARFF));
    	if (arffFile == null) {
    		state.output.fatal("Arff file not found",
    				base.push(P_ARFF),def.push(P_ARFF));
    	}
    	
		super.setup(state,base); // It must be here, setup() calls readSamples()
	}
    
	@SuppressWarnings("unchecked")
	@Override
    protected void readSamples() throws IOException {
		Reader reader = new FileReader(arffFile);
		Instances instances = new Instances(reader);
		instances.setClassIndex(instances.numAttributes() - 1);

		ArrayList<String> positives = new ArrayList<String>();
		ArrayList<String> negatives = new ArrayList<String>();

		// Generate positive and negative samples
		Enumeration<Instance> enume = instances.enumerateInstances();
		while (enume.hasMoreElements()) {
			Instance instance = (Instance) enume.nextElement();
			Attribute classAttribute = instance.classAttribute();

			if (!instance.classIsMissing()) {
				switch ((int) instance.value(classAttribute)) {
				case 0:
					positives.add(instance.stringValue(instance.attribute(0)));
					break;
				case 1:
					negatives.add(instance.stringValue(instance.attribute(0)));
					break;
				}
			} else {
				System.out
						.println("Warning, Class missing, check out data set");
			}
		}
		
		positiveSamples = new String[positives.size()];
		negativeSamples = new String[negatives.size()];
		
		for (int i=0; i<positiveSamples.length; i++)
			positiveSamples[i] = positives.get(i);
		
		for (int i=0; i<negativeSamples.length; i++)
			negativeSamples[i] = negatives.get(i);
		
		//if (verbose) 
//			System.out.println(getPrettyExamples()); System.out.flush();
	}
	
	  public static void main(String[] args) throws Exception {
		    InputStreamReader input = new InputStreamReader(System.in);
		    BufferedReader reader = new BufferedReader(input);
			
			if (args.length != 1) {
				System.out.println("RegexProblemArff [ARFF file]");
				System.exit(-1);
			}
			
			RegexProblemArff problem = new RegexProblemArff();
			problem.setVerbose(true);
			problem.arffFile = args[0];
			problem.readSamples();
			
		    System.out.println("Type regex to evaluate: ");
		    String regex = reader.readLine(); 
		    
		    System.out.print("\nFitness: " + problem.fitness(regex) + "\n");
	  }
}
