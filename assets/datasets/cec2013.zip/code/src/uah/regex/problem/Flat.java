package uah.regex.problem;

import ec.*;
import ec.simple.*;
import ec.vector.*;

public class Flat extends Problem implements SimpleProblemForm
{
	private static final long serialVersionUID = 1L;
	static protected int GEN_SIZE;
	
	protected EvolutionState state;
	
	static protected String positiveFile;
	static protected String negativeFile;
	
	protected static String [] coding;
	
	protected boolean verbose = false;
	
    public void evaluate(final EvolutionState state,
                         final Individual ind,
                         final int subpopulation,
                         final int threadnum)
    {	
        if (ind.evaluated) return;
        
        if (!(ind instanceof BitVectorIndividual))
            state.output.fatal("Whoa!  It's not a BitVectorIndividual!!!",null);
        
        this.state = state;
        BitVectorIndividual ind2 = (BitVectorIndividual)ind;
        
        ((SimpleFitness)ind2.fitness).setFitness(state, (float) 0.5, false);
        ind2.evaluated = true;
        }

    public void describe(final Individual ind, 
    		final EvolutionState state, 
    		final int subpopulation, 
    		final int threadnum,
    		final int log,
    		final int verbosity)
    {
    }   
}
