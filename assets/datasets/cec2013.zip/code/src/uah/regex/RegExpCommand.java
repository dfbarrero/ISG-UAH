package uah.regex;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class RegExpCommand {
	public static void main(String[] args) {
		boolean verbose = false;
		
		if (args.length != 2){
			System.out.printf("%s [regexp] [file]", args[0]);
			System.exit(-1);
		}
		
		String regexp = args[0];
		String file = args[1];
		
		try {
			Pattern pattern = Pattern.compile(regexp);

			LineNumberReader positiveReader 
				= new LineNumberReader(new FileReader(file));
			
			if (verbose)
				System.out.printf("regexp: %s, file: %s\n", regexp, file);

			String text = positiveReader.readLine();
			while(text != null) {	
				Matcher matcher = pattern.matcher(text);
				
				while (matcher.find()) {
					System.out.println("-> " + matcher.group());
				}

				text = positiveReader.readLine();
			}
		} catch (PatternSyntaxException e) {
			System.out.println("Could not compile regexp " + regexp);
			System.exit(-1);
		}catch (FileNotFoundException e) {
			System.out.println("No se pudo abrir el archivo "
					+ e.getMessage());
		} catch (IOException e) {
			System.out.println("Error en lectura de archivo. " 
					+ e.getMessage());
		}

	}
}
