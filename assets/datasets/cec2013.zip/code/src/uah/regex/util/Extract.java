package uah.regex.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class Extract {
  public static void main(String[] args) throws Exception {
	Pattern pattern = null;
 //   String regex = args[0];

    for (int i=0; i<args.length; i++) {
    	String file=args[i];
    	StringBuffer text = new StringBuffer("");
    	BufferedReader reader = new BufferedReader(new FileReader(file));

        InputStreamReader input = new InputStreamReader(System.in);
        BufferedReader console = new BufferedReader(input);
        
        
        String regex = console.readLine();
        
    	try
    	{
			pattern = Pattern.compile(regex);
			
			String line = reader.readLine();
    		while ((line = reader.readLine()) != null) {
    			text.append(line);
    			text.append(System.getProperty("line.separator"));
    		}
    		
 			//System.out.println("Using " + regex + " with " + text);
			Matcher matcher = pattern.matcher(text);
			while (matcher.find()) {
				System.out.println("" 
					+ text.substring(matcher.start(), matcher.end()));
    		}
    	} catch (PatternSyntaxException e) {
    		System.out.println("Incorrect Regex");
    		System.out.println(e.getMessage());
    		System.exit(-1);
    	} catch (Exception e) {
    		System.out.println(e.getMessage());
    		System.exit(-1);
    	}
    }
  }
}
