package uah.regex.util;

import weka.core.Attribute;
import weka.core.Instance;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import java.util.Enumeration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

public class TestRegex {

  public static void main(String[] args) throws Exception {
	Pattern pattern = null;
    Instances data = DataSource.read(args[0]);
	data.setClassIndex(data.numAttributes() - 1);
	
    String regex = "";
    InputStreamReader input = new InputStreamReader(System.in);
    BufferedReader reader = new BufferedReader(input);

    System.out.println("Type regex to evaluate: ");
    try
    {
        regex = reader.readLine(); 
        //System.out.println("Type text: ");
        //String text = reader.readLine(); 
        //System.out.println("Using " + regex + " with " + text);
        pattern = Pattern.compile(regex);
		//Matcher matcher = pattern.matcher(text);
		//while (matcher.matches())
		//	System.out.print(" " + text.substring(matcher.start(), matcher.end()));
    } catch (PatternSyntaxException e) {
    	System.out.println("Incorrect Regex");
    	System.out.println(e.getMessage());
    	System.exit(-1);
    } catch (Exception e){}
    
	//System.exit(-1);
	// Generate positive and negative samples
	Enumeration<Instance> enume = data.enumerateInstances();
	while (enume.hasMoreElements()) {
		Instance instance = (Instance) enume.nextElement();
		String sample =instance.stringValue(instance.attribute(0));
		Attribute classAttribute = instance.classAttribute();

		switch ((int) instance.value(classAttribute)) {
		case 0:
			System.out.print("Sample pos: " + sample + " :");
			break;
		case 1:
			System.out.print("Sample neg: " + sample + " :");
			break;
		}
		
		Matcher matcher = pattern.matcher(sample);
		while (matcher.find())
			System.out.print(" " + sample.substring(matcher.start(), matcher.end()));
		System.out.println("");
	}
  }
}
