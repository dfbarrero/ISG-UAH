package uah.regex.util;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class UtilTest {
	boolean test1[] = {false, false, false, false};
	boolean test2[] = {false, false, false, true};
	boolean test3[] = {false, true, false, false};
	boolean test4[] = {true, false};
	boolean test5[] = {false};
	
	String string1 = "0000";
	String string2 = "0001";
	String string3 = "0100";
	String string4 = "10";
	String string5 = "0";
	
	@Before
	public void setUp() throws Exception {
	}

	
	@Test
	public void testGetBoolean() {
	}
	
	@Test
	public void testBooleanArrayToString() {
		assertEquals("0000", Util.booleanArrayToString(test1));
		assertEquals("0001", Util.booleanArrayToString(test2));
		assertEquals("0100", Util.booleanArrayToString(test3));
		assertEquals("10", Util.booleanArrayToString(test4));
		assertEquals("0", Util.booleanArrayToString(test5));
	}

	@Test
	public void testBooleanToInt() {
		assertEquals(0, Util.booleanToInt(test1));
		assertEquals(1, Util.booleanToInt(test2));
		assertEquals(4, Util.booleanToInt(test3));
		assertEquals(2, Util.booleanToInt(test4));
		assertEquals(0, Util.booleanToInt(test5));
	}

	@Test
	public void testFactorial() {
		assertEquals(1, Util.factorial(0));
		assertEquals(1, Util.factorial(1));
		assertEquals(24, Util.factorial(4));
		assertEquals(3628800, Util.factorial(10));
		try {
			assertEquals(0, Util.factorial(-1));
			fail("Exception not thrown");
		} catch (IllegalArgumentException e) {
			
		}
	}
	
	@Test
	public void testC() {
		assertEquals(1, Util.C(0, 0));
		assertEquals(1, Util.C(3, 0));
		assertEquals(3, Util.C(3, 2));
		assertEquals(10, Util.C(5, 2));
		try {
			assertEquals(0, Util.C(1, 5));
			fail("Exception not thrown");
		} catch (IllegalArgumentException e) {
			
		}
	}
}
