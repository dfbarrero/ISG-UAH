#!/bin/bash 

# Paths
BASE=/home/dbarrero/repositorios/2013-eurogp/trunk/code
CLASSPATH=$BASE/bin/
LIB=$BASE/lib


# $1 --> ECJ parameters file
CONFIG_FILE=`pwd`/$1

control_c()
{
	# Delete the last run, just to avoid potential inconsistent data
	echo
	echo "Cleaning run " $I
	echo -en "\n*** Exiting ***\n"
	exit
}

for I in $LIB/*
do
	CLASSPATH=$CLASSPATH:$I
done

if [ -z "$1" ]
then
	echo ERROR: $0 file.params
	exit 
fi

echo $CLASSPATH
mkdir data 2> /dev/null
trap clean_data SIGINT

echo Running ECJ params $1

java -Xmx1200m -Xms500m -classpath $CLASSPATH uah.regex.MassiveEvolve -file $CONFIG_FILE 2>/dev/null

echo
