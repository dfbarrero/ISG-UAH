#!/usr/bin/Rscript --vanilla

library(boot, verbose=FALSE)

N <- 100
samples <- 1000

runs <- read.table("measures/k.dat", header=TRUE)

print ("---- P -----")
x11()
	
k <- sample(runs, N)
k <- rowSums(k)
p <- k / N

plot(p, ylim=c(0,N),  type="n", col="blue", axes=FALSE, main="Santa Fe Trail", ylab="P(M, i)", xlab="Generation")
average <- 1:length(p) * 0

for (i in 1:samples) {
	k <- sample(runs, N)
	k <- rowSums(k)
	p <- k / N
	average <- average + k 
	lines(k, col="grey")
	i <- i+1
}

lines(average/samples, col="black")
axis(1, at=1:length(p), label=1:length(p))
axis(2, label=TRUE)
box()

dev.copy2eps();
while (1) Sys.sleep(10)
