#!/bin/bash 

# Paths
BASE=/home/dbarrero/repositorios/2013-eurogp/trunk/code
LIB=$BASE/lib
CLASSPATH=$BASE/bin/

for I in $LIB/*
do
	CLASSPATH=$CLASSPATH:$I
done

# Dot slash is used in the execution of TestParameter to avoid a bug in ECJ, the parameter file must be provided with a directory

#echo Warning: There must be a directory in the provided path
java -classpath $CLASSPATH uah.regex.util.TestParameter $1
