#!/usr/bin/Rscript --vanilla

# Fit the density distribution of P with several models

library(MASS)
library(fitdistrplus)
library(xtable)

#options(digits=1)

print("hola")
#pdf(file="../presentacion/figs/histogram.pdf", width=8, height=4)

file <- c("data.dat")

data <- read.table(file, header=T)
colnames(data)

par(mfrow=c(2,3))
print(nrow(data))

result <- data.frame(problem=NULL, shape=NULL, scale=NULL, meanlog=NULL, sdlog=NULL,
	ksw=NULL, kswp=NULL, ksl=NULL, kslp=NULL)

for (problem in unique(data$problem)) {
	print(problem)
	p <- problem
	
	#if (p == "quintic-gp-erc") next
	#if (p == "twobox-noadf") next

	sdata <- subset(data, problem==p)$evaluations
	if (length(sdata) > 100)
		sdata <- sample(sdata, 100)

	#print(paste("Datos: "), length(sdata))
	print("weibull")
	fw <- fitdist(sdata, "weibull")
	#fwr<-gofstat(fw, print=T)
	print(fw)
	test <- ks.test(sdata, "pweibull", shape=fw$estimate[1], scale=fw$estimate[2])
	print(test)
	fwr <- NULL
	fwr$p <- test$p.value
	fwr$ks <- test$statistic

	print("lnorm")
	fl <- fitdist(sdata, "lnorm")
	print(fl)
	#flr<-gofstat(fl, print=T)
	test <- ks.test(sdata, "plnorm", meanlog=fl$estimate[1], sdlog=fl$estimate[2])
	print(test)
	flr <- NULL
	flr$p <- test$p.value
	flr$ks <- test$statistic

	#res <- cdfcomp(list(fw,fln),legendtext=c("Weibull","lognormal"), xlab="serving sizes (g)",lwd=2)
	#print(str(flr))
	
	#if (p == "quintic-gp-erc")
	#	temp <- data.frame(problem=p,
	 #       ksw=fwr$ks, kswt="NA", est,
	#		ksl=flr$ks, kslt="NA", adl=flr$ad, adlt=flr$adtest)
	#else
		temp <- data.frame(problem=p, shape=fw$estimate[1], scale=fw$estimate[2], 
	       ksw=fwr$ks, kswp=fwr$p, 
			meanlog=fl$estimate[1], sdlog=fl$estimate[2],
		   ksl=flr$ks, kslp=flr$p)
		
	result <- rbind(result, temp)
}

print(result, digits=2)
fm1.table <- xtable(result, digits=3)
print(fm1.table,type="latex")
#while(1) Sys.sleep(1)
