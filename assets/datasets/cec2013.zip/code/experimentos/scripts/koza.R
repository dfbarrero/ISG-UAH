#!/usr/bin/Rscript --vanilla

data <- read.table("measures/koza.dat", header=T)

P <- data$P
I <- data$I
Inoceil <- data$Inoceil
diff <- data$diff

#Plot preparations
x11()

par(mfrow=c(4,1))

plot(P, type="n", ylab="P(M,i)", log="y")
lines(P, lty=1, col=2, pch=1, log="y")

plot(P, type="n", ylab="P(M,i)")
lines(P, lty=1, col=2, pch=1)
lines(0.08*(1-exp(1:50)), lty=3, col=3, pch=3)

plot(I, type="n", xlab=paste("Imin=", ceiling(min(I, na.rm=TRUE)), ", Iminnoceil= ", ceiling(min(Inoceil, na.rm=TRUE)), ", diff=", ceiling(min(I, na.rm=TRUE)-min(ceiling(Inoceil), na.rm=TRUE))), ylab="I(M,i,z)")
leg.y <- c(2, 3)
lines(I, lty=1, col=2, pch=1)
lines(Inoceil, lty=2, col=3, pch=2)
leg.txt <- c("I with ceil", "I without ceil")
legend("topright", leg.txt, col=leg.y, lty=leg.y, pch=leg.y)

maximum <- 1:length(P)
maximum <- maximum * 500
plot(abs(I-Inoceil), type="n", xlab="Generations", ylab="diff")
lines(abs(I-Inoceil), lty=1, col="red", pch=1)
lines(maximum, lty=1, col=3, pch=2)
legend("topleft", c("Error", "Maximun theoretical error"), col=leg.y, lty=leg.y, pch=leg.y)

#plot(P, type="n", xlab="Generations", ylab="P(M,i)")
#lines(P, lty=1, col="red", pch=1)

dev.copy2eps();

while(1) Sys.sleep(10)
