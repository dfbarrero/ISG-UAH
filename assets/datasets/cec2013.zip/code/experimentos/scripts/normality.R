#!/usr/bin/Rscript --vanilla

files <- c("../simples/ant/simple/measures/k-notaccumulated.dat",
           "../simples/regression/simple/measures/k-notaccumulated.dat",
           "../simples/4-parity/simple/measures/k-notaccumulated.dat",
           "../simples/5-parity/simple/measures/k-notaccumulated.dat",
           "../simples/6-multiplexer/simple/measures/k-notaccumulated.dat",
           "../simples/11-multiplexer/simple/measures/k-notaccumulated.dat")
labels <- c("Artificial ant", "Regression", "4-Parity", "5-Parity", "6-Multiplexer", "11-Multiplexer")
distributions <- c("Normal", "Lognormal", "Weibull", "Logistic")

mystat <- function(data, index) {
	data = t(data)
	#print(index)
	d <- data[, index]
	
	# P is a column vector
	P <-rowSums(d) / length(index)
	return(P[length(P)])
}

runs <- read.table("../simples/ant/simple/measures/k.dat", header=FALSE)
k <- sum(runs[nrow(runs), ])
bestEstimator <- k / ncol(runs)
print(paste("K=", k, ", N=", ncol(runs), "Best P =", bestEstimator))
x11()

print("------ Normality test --------")
print("p < alpha implica normalidad")

values <- c(50)
par(mfrow=c(2,length(values)/2))
	
for (N in values) {
	estimation <- NULL
	print(paste("Samples: ",  N))

	samples <- 1000
	for(i in 1:samples) {
		s <- sample(runs, N)
		s <- rowSums(s[nrow(s),])
		#estimation[i] <- s/N
		estimation[i] <- s
	}
	print(shapiro.test(estimation))
	hist(estimation, main=paste("n = ", N), xlab="Number of successes (k)", freq=FALSE)
	estimation <- sort(estimation)
	#qqplot(estimation, dbinom(estimation, N, 0.1336))
	lines(estimation, dbinom(estimation, N, 0.13168), col="red")
	rug(estimation)
}
#dev.copy2eps();
while (1) Sys.sleep(10)
