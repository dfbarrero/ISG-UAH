#!/Applications/Octave.app/Contents/Resources/bin/octave -qf

#save_precision(2)

# Parameters
BASE_DATA = "data/run-";

arg_list = argv ();

if nargin != 2;
	printf("%s", "ERROR: average.m generations n\n");
	exit;
else
	generaciones = str2num(arg_list{1});
	n = str2num(arg_list{2});
endif

# Get matrix dimension
total = [];
temp = load(sprintf("%s%s", BASE_DATA, num2str(1)));

suma = zeros(generaciones, columns(temp));
all = zeros(generaciones, 1);

# Sum values
for i=1:1:n;
	temporal = load(sprintf("%s%s", BASE_DATA, num2str(i)));
	suma = suma .+ temporal;
end

suma = suma/n;
save "average.dat" suma;
