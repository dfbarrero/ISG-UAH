#!/usr/bin/Rscript --vanilla

# Fit the density distribution of P with several models

library(MASS)
library(fitdistrplus)
library(xtable)
library(MASS)
library(binom)

files <- c("../tour/ant-tour/tour-1/measures/k-notaccumulated.dat", 
           "../tour/regression-tour/tour-1/measures/k-notaccumulated.dat")
x11()

par(mfcol=c(6, 2))

#print("X cerca de 1 indica que el modelo es bueno, si X >> 1, el modelo es malo, y si X < 1 el modelo esta overfitting")

for (file in files) {
	print("--------")
	print(file)
	data <-read.table(file, header=F)$V1
	print("weibull")
	print(length(data))
	data <- sample(data, 150)


	#pdf(file="../presentacion/figs/histogram.pdf", width=8, height=4)

	fw <- fitdist(data, "weibull")
	str(fw$estimate["shape"])
	str(fw$estimate["scale"])
	fwr<-gofstat(fw, print=T)
	fwr$ks <- fwr$ks
	fwr$t <- fwr$kstest

	#res <- cdfcomp(list(fw,fln),legendtext=c("Weibull","lognormal"), xlab="serving sizes (g)",lwd=2)
	#temp <- data.frame(problem=p,
	#    ksw=fwr$ks, kswt=fwr$kstest, adw=fwr$ad, adwt=fwr$adtest,
	#	ksl=flr$ks, kslt=flr$kstest, adl=flr$ad, adlt=flr$adtest)
		
	#result <- rbind(result, temp)
}

#print(result)
#fm1.table <- xtable(result, digits=2)
#print(fm1.table,type="latex")
