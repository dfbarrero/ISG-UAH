#!/usr/bin/Rscript --vanilla
test <- function(x, value) {
	if (x < value) return(0)
	else return(1)
}

echo=TRUE
args <- commandArgs(TRUE)

PREFIX <- "data/run-"

if (length(args) != 6) {
	print("SYNTAX: generate_k.R runs column operation value epsilon population")
	q()
}

runs <- as.integer(args[1])
column <- as.integer(args[2])
operation <- args[3]
value <- as.integer(args[4])
epsilon <- as.numeric(args[5])
population <- as.numeric(args[6])

#runs <- 10

# Get number of rows and create empty k matrix
matrix <- data.matrix(read.table(paste(PREFIX, 1, sep="")))
print(paste("   Init data for ", runs, " runs and", nrow(matrix), " generations"));
k <- array(rep(0, runs * nrow(matrix)), dim=c(nrow(matrix), runs))

#print(paste("Runs:", runs, " column: ", column, "operation: ", operation, "value: ", value))

print("   Loading dataset")
for (i in 1:runs) {
	file=paste(PREFIX, i, sep="")
	matrix <- data.matrix(read.table(file, header=F))

	k[, i] <- matrix[, column]
}

#print(k)

if (operation == "==") {
	locate <- function(x, value) {
		if (x == value) return(1)
		else return(0)
	}
} else if (operation == ">") {
	locate <- function(x, value) {
		if (x > value) return(1)
		else return(0)
	} 
} else if (operation == ">=") {
	locate <- function(x, value) {
		if (x >= value) return(1)
		else return(0)
	}
} else if (operation == "<") {
	locate <- function(x, value) {
		if (x < value) return(1)
		else return(0)
	}
} else if (operation == "<=") {
	locate <- function(x, value) {
		if (x <= value) return(1)
		else return(0)
	}
}

if (!exists("locate")) {
	print("Operation not supported. Select ==, <, >, <=, >=")
	q()
}

y <- apply(k, c(1,2), locate, value=value)

#print("--- Not accumulated ---")
#print(y)
#print(paste("col ", ncol(y), " row ", nrow(y)))

k <- NULL # Free memory 

# We have instant successes, now we find accumulated successes
print("   Detecting successes")
generation <- list()
for (i in 1:ncol(y)) {
	for (j in 1:nrow(y)) {
		if (y[j,i] == 1) {
			# Fill ones the rest of the column
			# R does not provide a break instruction, so we must operate until the end
			generation[length(generation)+1] <- j
			y[j:nrow(y),i] <- 1
			break
		}
	}
}

write.table(matrix(generation), "measures/k-notaccumulated.dat", row.names=FALSE, col.names=FALSE)
write.table(y, "measures/k.dat", row.names=FALSE, col.names=FALSE)
#print("----accumulated-----")
#print(y)
#Sys.sleep(1)

print("   Calculating precise P(M, i)")
K <- rowSums(y)
P <- K/runs
print(paste("   Calculating precise P(", population, ", ", nrow(y), ") = ", K[length(K)], " / ", runs, " = ", P[nrow(y)], sep=""))

# Y is big and we do now need it anymore
y <- NULL
I <- NULL
Inoceil <- NULL

print("   Calculating precise I(M,i,z)")
for (i in 1:length(P)) {
	if (P[i] == 0) {
		I[i] <- NaN
		Inoceil[i] <- NaN
	} else {
		R <- ceiling(log(epsilon)/log(1-P[i]))
		Rnoceil <- log(epsilon)/log(1-P[i])
		I[i] <- population * i * R
		Inoceil[i] <- population * i * Rnoceil
	}
}

print(paste("   Imin(M,i,z) = ", min(I[abs(I) != Inf], na.rm=TRUE)))
result <- data.frame(K=K, P=P, I=I, Inoceil=Inoceil)
write.table(as.matrix(result), "measures/koza.dat", row.names=FALSE)
