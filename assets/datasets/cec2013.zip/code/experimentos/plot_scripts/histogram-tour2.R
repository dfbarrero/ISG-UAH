#!/usr/bin/Rscript --vanilla

# Fit the density distribution of P with several models

library(MASS)
library(lattice)

data <- read.csv("dataset.csv", header=T)
#postscript(file="../../../tex/figs/histogram.eps", width=8, height=4, paper="special", horizontal=TRUE)
#pdf(file="../presentacion/figs/histogram.pdf", width=8, height=4)
#trellis.device(postscript, file="foo.eps", color=T, width=7, height=6)
#trellis.device(postscript, file="foo.eps", color=T, horizontal=F, onefile=FALSE, width=15)

#x11(width=7, height=6)
x11()

# Histogram() does not respect relation="free", we need a trick: using densityplot and then put a panel.histogram()
densityplot(~runtime|problem, data, subset=tournament==2, type="density", aspect="y",
	scales=list(relation="free"), col="white", layout=c(3,2), xlab="Expected runtime (generations)",
	#scales=list(relation="free"), col="gray88", layout=c(3,2), xlab="Expected runtime (generations)",
	auto.key = list(text = c("Lognormal","Weibull"), space="bottom", lines=TRUE, columns=2),
	as.table=TRUE, index.cond=list(c(5,2,4,6,3,1)),
	prepanel = function(x, ...) {
		prepanel.default.histogram(x, breaks=15, ...)
	},
	panel = function(x, ...) {
	  	param <- fitdistr(x, densfun="Lognormal")$estimate
		y <- max(dlnorm(1:1000, param[1], param[2]))
		panel.histogram(x, breaks=15, xlim=c(0, max(x)), ylim=c(0,1), ...)

		panel.mathdensity(dmath=dlnorm, args=list(meanlog=param[1], sdlog=param[2]), col="blue")

	  	param <- fitdistr(x, densfun="Weibull")$estimate
		panel.mathdensity(dmath=dweibull, args=list(shape=param[1], scale=param[2]), col="red")
	}
)
dev.copy2eps(file="../../../tex/histogram-tour2.eps",  fonts="ComputerModern"); 
