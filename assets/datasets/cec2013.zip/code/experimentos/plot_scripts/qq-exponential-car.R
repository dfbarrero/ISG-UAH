#!/usr/bin/Rscript --vanilla

# Fit the density distribution of P with several models

library(MASS)
library(car)

x11()

par(mfrow=c(2,3), mar=c(3,3,2,1), oma=c(0.5,0.5,0,0.5), mgp=c(1.8, 1, 0))

#postscript(file="../../../tex/figs/histogram.eps", width=8, height=4, paper="special", horizontal=TRUE)
#pdf(file="../presentacion/figs/histogram.pdf", width=8, height=4)

files <- c( "../simples/4-parity/simple/measures/k-notaccumulated.dat",
           "../simples/5-parity/simple/measures/k-notaccumulated.dat",
           "../simples/11-multiplexer/simple/measures/k-notaccumulated.dat")
labels <- factor(c("4-Parity", "5-Parity", "11-Multiplexer"), ordered=TRUE)

files <- c("../simples/regression/simple/measures/k-notaccumulated.dat",
           "../simples/5-parity/simple/measures/k-notaccumulated.dat",
           "../simples/11-multiplexer/simple/measures/k-notaccumulated.dat",
		   "../simples/ant/simple/measures/k-notaccumulated.dat", 
           "../simples/4-parity/simple/measures/k-notaccumulated.dat",
           "../simples/6-multiplexer/simple/measures/k-notaccumulated.dat") 

labels <- factor(c("Regression", "5-Parity", "11-Multiplexer", "Artificial ant", "4-Parity", "6-Multiplexer"))

#par(mfrow=c(3,2), mar=c(3,3,2,1), oma=c(0.5,0.5,0,0.5), mgp=c(1.8, 1, 0))

data <- data.frame(problem=NULL, g=NULL, label=NULL)

i <- 1
for (file in files) {
    print(file)
    x <-read.table(file, header=F)
    x <- x$V1

	shift <- 0
	gens <-1:50
  	breaks <- 0:50


	if (i == 4) {
		# Hormiga
		shift <- 9
	} else if (i  == 5) {
		# 4-Parity
	    shift <- 17
	} else if (i == 6) {
		# 6-Multiplexer
		x <- sample(x, 1000) # Avoid unnecesary points
		shift <- 7
	} else if (i == 1) {
		# Reression
		x <- sample(x, 1000) # Avoid unnecesary points
		shift <- 5
	} else if (i == 2) {
		# 5-Parity
		shift <- 7
        x <- x[x<800]
        gens <- 1:800
	} else if (i == 3) {
		# 11-Multiplexer
   	    shift <- 60
        x <- x[x<800]
        gens <- 1:800
    } 

    x <- x[x>shift]
    x <- x - shift
    
    param <- fitdistr(x, densfun="exponential")$estimate
	print(param)
	print(shift)
    #x <- shift:max(gens)

	geo <- rgeom(length(x), param)

	# Remove values higher than mac(gens)
	geo[geo>max(x)] <- rgeom(1, param)
	geo[geo>max(x)] <- rgeom(1, param)
	geo[geo>max(x)] <- rgeom(1, param)
	geo[geo>max(x)] <- rgeom(1, param)
	geo[geo>max(x)] <- rgeom(1, param)
	geo[geo>max(x)] <- rgeom(1, param)
	geo[geo>max(x)] <- rgeom(1, param)
	geo[geo>max(x)] <- rgeom(1, param)
	geo[geo>max(x)] <- rgeom(1, param)
	geo[geo>max(x)] <- rgeom(1, param)

	qqPlot(sample(x, 150), "exp", main=labels[i])

	data <- rbind(data, data.frame(problem=labels[i], g=x, label="Generation-to-success"))
	data <- rbind(data, data.frame(problem=labels[i], g=geo, label="Exponential"))
	i <- i+1	
}
#print(data)

#strip.background <- trellis.par.get("strip.background") 
#trellis.par.set(strip.background = list(col = grey(7:1/8))) 
## Set color of plot symbols to grayscale: 
#plot.symbol <- trellis.par.get("plot.symbol") 
#trellis.par.set(plot.symbol = list(col = grey(5/8))) 

#,
#        type="density", col="red", allow.multiple=TRUE,
#        scales=list(relation="free"), as.table=TRUE, layout=c(3,2),aspect="y",
#        xlab="Generation-to-success", ylab="Density", breaks=NULL, cex=0.7,
#	   index.cond=list(c(5,2,4,6,3,1)),
#dev.copy2eps(file="../../../tex/figs/qq-exponential.eps",  fonts="ComputerModern")
while(1) Sys.sleep(2)
