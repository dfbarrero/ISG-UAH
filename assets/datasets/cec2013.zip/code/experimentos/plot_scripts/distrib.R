#!/usr/bin/Rscript --vanilla

# Fit the density distribution of P with several models

library(MASS)

win <- TRUE

data <-read.table("../simples/11-multiplexer/simple//measures/k-notaccumulated.dat", header=F)
data <-read.table("../tour/ant-tour/tour-1//measures/k-notaccumulated.dat", header=F)
data <- data$V1
#data <- data[data<400]
#data <- data[data>60]
#data <- data-60
#print(data)

if (win) x11()

par(mfrow=c(3,2))
breaks <- 25
generaciones <- 1:1000

param <- fitdistr(data, densfun="geometric")$estimate
hist(data, freq=F, breaks=breaks, main="Geometric")
rug(data)
lines(dgeom(generaciones, param), col="red")

#param <- fitdistr(data, densfun="Negative Binomial")$estimate
#hist(data, freq=F, breaks=50, main="Negative binomial")
#rug(data)
#:lines(dnbinom(1:50, size=floor(param[1]), mu=param[2], log=F), col="red")

param <- fitdistr(data, densfun="Weibull")$estimate
hist(data, freq=F, breaks=breaks, main="Weibull")
rug(data)
print(param)
lines(dweibull(generaciones, shape=param[1], scale=param[2], log=F), col="red")

param <- fitdistr(data, densfun="Logistic")$estimate
hist(data, freq=F, breaks=breaks, main="Logistic")
rug(data)
print(param)
lines(dlogis(generaciones, location=param[1], scale=param[2], log=F), col="red")

param <- fitdistr(data, densfun="Lognormal")$estimate
hist(data, freq=F, breaks=breaks, main="Lognormal")
rug(data)
print(param)
lines(dlnorm(generaciones, meanlog=param[1], sdlog=param[2], log=F), col="red")

param <- fitdistr(data, densfun="Normal")$estimate
hist(data, freq=F, breaks=breaks, main="Normal")
rug(data)
print(param)
lines(dnorm(generaciones, mean=param[1], sd=param[2], log=F), col="red")

param <- fitdistr(data, densfun="Gamma")$estimate
hist(data, freq=F, breaks=breaks, main="Gamma")
rug(data)
print(param)
lines(dgamma(generaciones, shape=param[1], rate=param[2], log=F), col="red")

#param <- fitdistr(data, densfun="t")$estimate
#hist(data, freq=F, breaks=50, main="Studtent's t")
#rug(data)
#print(param)
#lines(dt(generaciones, df=param[3], ncp=param[1], log=F), col="red")

#param <- fitdistr(data, densfun="f")$estimate
#hist(data, freq=F, breaks=50, main="f")
#rug(data)
print("f")
print(param)
#lines(df(1:50, df1=param[1], df2=param[2], ncp=param[3], log=F), col="red")

#qqnorm(data)

if (win) dev.copy2pdf(file="distrib.pdf");

if (win) while(1) Sys.sleep(10)
