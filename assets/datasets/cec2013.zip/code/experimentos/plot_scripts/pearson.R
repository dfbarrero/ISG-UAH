#!/usr/bin/Rscript --vanilla

# Fit the density distribution of P with several models

library(MASS)

files <-  c("../simples/6-multiplexer/simple/measures/k-notaccumulated.dat", 
			"../simples/11-multiplexer/simple/measures/k-notaccumulated.dat",
			"../simples/4-parity/simple/measures/k-notaccumulated.dat",
			"../simples/5-parity/simple/measures/k-notaccumulated.dat",
			"../simples/ant/simple/measures/k-notaccumulated.dat",
			"../simples/regression/simple/measures/k-notaccumulated.dat")
x11()

par(mfcol=c(6, 2))

#print("X cerca de 1 indica que el modelo es bueno, si X >> 1, el modelo es malo, y si X < 1 el modelo esta overfitting")

for (file in files) {
	print("--------")
	print(file)
	data <-read.table(file, header=F)$V1

	param <- fitdistr(data, densfun="Lognormal")$estimate
	hist(data, freq=F, main=file)
	lines(dlnorm(1:max(data), meanlog=param[1], sdlog=param[2], log=F), col="red")

	lognormal <- rlnorm(length(data), meanlog=param[1], sdlog=param[2])
	lognormal <- lognormal[lognormal<max(data)]

	# No usar file[i]!!!!
	if (file == "../simples/6-multiplexer/simple/measures/k-notaccumulated.dat") { # 6-multiplexer
		print("1")
		breaks <- c(0, 7, 10, 15, 30, 50)
	} else if (file == "../simples/11-multiplexer/simple/measures/k-notaccumulated.dat") {
		print("2")
		breaks <- c(0, 100, 200, 300, 400, 500)
	} else if (file == "../simples/4-parity/simple/measures/k-notaccumulated.dat") {
		print("3")
		breaks <- c(0, 15, 20, 25, 30, 50)
	} else if (file == "../simples/5-parity/simple/measures/k-notaccumulated.dat") { # 5-parity
		print("4")
		data <- sample(data, length(lognormal))
		lognormal <- sample(lognormal, length(lognormal))
		Sys.sleep(5)
		breaks <- c(0, 100, 200, 400, 600, 800)
	} else if (file == "../simples/ant/simple/measures/k-notaccumulated.dat")  { # Ant
		print("5")
		breaks <- c(0, 10, 15, 25, 33, 50)
	} else if (file == "../simples/regression/simple/measures/k-notaccumulated.dat")  { # Regression
		print("6")
		breaks <- c(0, 5, 9, 14, 20, 50)
	} else { print("ERROR") }

	print(length(data))
	print(length(lognormal))
	data <- sample(data, 100)
	lognormal <- sample(lognormal, 100)
#	qqplot(lognormal, data[1:length(lognormal)], main=file)
#	abline(0, 1, col="red")

	observed <- hist(data, breaks=breaks, plot=FALSE)$count
	expected <- hist(lognormal, breaks=breaks, plot=FALSE)$count
	#print(expected)
	#rint(observed)
	
	plot(1:length(expected), expected, type="l", col="red")
	lines(1:length(observed), observed)

	#print("ANTES: expected")
	#print(expected)
	#print("ANTES: observed")
	#print(observed)	
	#print(table(observed))

	print("DESPUES: expected")
	print(expected)
	print("DESPUES: observed")
	print(observed)	
	#print(length(observed))	
	#print("DESPUES: Prop expected")
	#print(observed/sum(expected))	
	#print(observed/sum(expected))
	
	if (length(expected) != length(observed)) print("Longitudes desiguales");
	#est <- chisq.test(observed, expected/sum(expected))
	#print(est$expected)
	#print(est$observed)
	#print(est)

	chi <- (observed - expected)^2/expected
	#print("chi")
	#print(chi)
	df <- length(expected) - 1

	print(paste("breaks: "))
	print(breaks)
	print(paste("n: ", sum(observed)))
	print(paste("df: ", df))
	print(paste("Chi: ", sum(chi)))
	print(paste("Tabla: ", qchisq(0.95, df=df)))
}

dev.copy2eps(file="pearson.eps",  fonts="ComputerModern");
while(1) Sys.sleep(10)
#q()
#dev.copy2eps();
