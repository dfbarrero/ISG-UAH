#!/usr/bin/Rscript --vanilla

# Fit the density distribution of P with several models

library(lattice)

win <- TRUE

#postscript(file="../../../tex/figs/histogram.eps", width=8, height=4, paper="special", horizontal=TRUE)
#pdf(file="../presentacion/figs/histogram.pdf", width=8, height=4)

files <- c("../simples/regression/simple/measures/k-notaccumulated.dat",
           "../simples/5-parity/simple/measures/k-notaccumulated.dat",
           "../simples/11-multiplexer/simple/measures/k-notaccumulated.dat",
		   "../simples/ant/simple/measures/k-notaccumulated.dat", 
           "../simples/4-parity/simple/measures/k-notaccumulated.dat",
           "../simples/6-multiplexer/simple/measures/k-notaccumulated.dat") 

labels <- factor(c("Regression", "5-Parity", "11-Multiplexer", "Artificial ant", "4-Parity", "6-Multiplexer"))

data <- data.frame(problem=NULL, g=NULL)

if (win) x11(width=8, height=6)

par(mfrow=c(2,3), mar=c(3,3,2,1), oma=c(0.5,0.5,0,0.5), mgp=c(1.8, 1, 0))

#strip.background <- trellis.par.get("strip.background") 
#trellis.par.set(strip.background = list(col = grey(7:1/8))) 
## Set color of plot symbols to grayscale: 
#plot.symbol <- trellis.par.get("plot.symbol") 
#trellis.par.set(plot.symbol = list(col = grey(5/8))) 

i <- 1
for (file in files) {
    print(file)
    g <-read.table(file, header=F)
    g <- g$V1
    g <- g[g<800]
	g <- log(g)

	if (length(g) > 200) {
		g <- sample(g, 200)
	}

	data <- rbind(data, data.frame(problem=labels[i], g=g))
	i <- i+1
}

#print(data)
#histogram(~ g|problem, data=data, col="red", 
#	type = "density", xlab="log(generation-to-success)",
#	layout = c(3,2), aspect="y",
#   panel = function(x, ...) {
#	     panel.histogram(x, ...)
#	     panel.mathdensity(dmath = dnorm, col = "black",
#	     args = list(mean=mean(x),sd=sd(x)))
#	}
#)#, scales=list(relation="free"))

qqmath(~ g|problem, data=data, xlab="Normal quantiles", ylab="log(run-time) quantiles",
       prepanel = prepanel.qqmathline,
	   aspect = "y", as.table=TRUE,
	   index.cond=list(c(5,2,4,6,3,1)),
	   panel = function(x, ...) {
	         panel.qqmathline(x, ...)
	         panel.qqmath(x, ...)
	   })

#qqmath(~ g|problem, data=data)#, scales=list(relation="free"))

dev.copy2eps(file="../../../tex/qq-log.eps",  fonts="ComputerModern"); 
if(win) while(1) Sys.sleep(1)
