#!/usr/bin/Rscript --vanilla
library(lattice)

dataset <-read.csv("dataset.csv", header=T)

x11()
print(colnames(dataset))

densityplot(~log(runtime)|problem, dataset, group=tournament,
	scales=list(relation="free"),
	as.table=TRUE, index.cond=list(c(5,2,4,6,3,1)),
	auto.key=list(text=c("Tour. size 1", "Tour. size 2", "Tour. size=7"),
		space="bottom", columns=3),
	plot.points=F, aspect="y")

dev.copy2eps(file="density-tournament.eps");

while(1) Sys.sleep(1)
