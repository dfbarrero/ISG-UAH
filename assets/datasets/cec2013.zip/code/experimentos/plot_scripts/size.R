#!/usr/bin/Rscript --vanilla

library(lattice)

win <- TRUE

files <- c("../simples/regression/simple/measures/average.dat",
           "../simples/5-parity/simple/measures/average.dat",
           "../simples/11-multiplexer/simple/measures/average.dat",
		   "../simples/ant/simple/measures/average.dat",
           "../simples/4-parity/simple/measures/average.dat",
           "../simples/6-multiplexer/simple/measures/average.dat") 

labels <- factor(c("Regression", "5-Parity", "11-Multiplexer", "Artificial ant", "4-Parity", "6-Multiplexer"))

files <- c("../tour-1/ant/tour-1/measures/average.dat", 
           "../tour-1/regression/tour-1/measures/average.dat")
labels <- factor(c("Artificial ant", "Regression"))

if (win) x11()

dat <- data.frame(label=NULL, generation=NULL, bestRaw=NULL, meanRaw=NULL, AverageDepth=NULL, AverageNodes=NULL)

i <- 1
for (file in files) {
    print(file)
    data <-read.table(file, header=T)

	print(names(data))

	#generation <- data$generation
	#bestRawGen <- data$bestRawGen
	#meanRawGen <- data$meanRawGen
	#bestAdjustedGen <- data$bestAdjustedGen
	#meanAdjustedGen <- data$meanAdjustedGen
	#bestHitsGen <- data$bestHitsGen
	#meanHitsGen <- data$meanHitsGen
	#size <- data$avgDepthIndGen
	dat <- rbind(dat, data.frame(label=labels[i], generation=data$generation, bestRaw=data$bestRawGen, meanRaw=data$meanRawGen, AverageDepth=data$avgDepthIndGen, AverageNodes=data$avgNodesIndGen))
	i <- i+1	
}
#print(data)
	
#Plot preparations
x11()

xyplot(AverageDepth + AverageNodes ~ generation, data=dat, groups = label,
	   xlim = c(0,1000),# main="Average tree sizes",
       type = "a", ascpect=0.2, ylabel="", layout=c(1,2), xlab="Generation",
       auto.key = list(space = "right", points = FALSE, lines = TRUE, columns=1),
	   scales = list(relation="free", log=FALSE, y=list(log=FALSE)),
	   panel = function(...) {
	     panel.grid()
	     panel.xyplot(...)
	   })

dev.copy2eps(file="../../../tex/size-tour.eps",  fonts="ComputerModern")
if(win) while(1) Sys.sleep(1)
