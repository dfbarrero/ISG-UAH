#!/usr/bin/Rscript --vanilla

data <- data.frame(problem=NULL, runtime=NULL, tournement=NULL)

for (label in dir(path="../tour-2/", pattern="*")) {
	path <- paste("../tour-2/", label, sep="")
	if (file.info(path)$isdir == FALSE) next

	print(path)
	file <- paste(path, "/tour-2/measures/k-notaccumulated.dat", sep="")
	print(paste("Reading ", file))
 	temp <-read.table(file, header=F)$V1

	data <- rbind(data, data.frame(problem=label, runtime=temp, tournament=2))
}

for (label in dir(path="../tour-1/", pattern="*")) {
	path <- paste("../tour-1/", label, sep="")
	if (file.info(path)$isdir == FALSE) next

	print(path)
	file <- paste(path, "/tour-1/measures/k-notaccumulated.dat", sep="")
	print(paste("Reading ", file))
 	temp <-read.table(file, header=F)$V1

	data <- rbind(data, data.frame(problem=label, runtime=temp, tournament=1))
}

for (label in dir(path="../simples/", pattern="*")) {
	path <- paste("../simples/", label, sep="")
	if (file.info(path)$isdir == FALSE) next

	print(path)
	file <- paste(path, "/simple/measures/k-notaccumulated.dat", sep="")
	print(paste("Reading ", file))
 	temp <-read.table(file, header=F)$V1

	data <- rbind(data, data.frame(problem=label, runtime=temp, tournament=7))
}

write.csv(data, file="dataset.csv", row.names=FALSE)
