#!/usr/bin/Rscript --vanilla

# Fit the density distribution of P with several models

library(MASS)
library(lattice)

win <- TRUE

#postscript(file="../../../tex/figs/histogram.eps", width=8, height=4, paper="special", horizontal=TRUE)
#pdf(file="../presentacion/figs/histogram.pdf", width=8, height=4)

files <- c( "../datasets/simples/4-parity/simple/measures/k-notaccumulated.dat",
           "../datasets/simples/5-parity/simple/measures/k-notaccumulated.dat",
           "../datasets/simples/11-multiplexer/simple/measures/k-notaccumulated.dat")
labels <- factor(c("4-Parity", "5-Parity", "11-Multiplexer"), ordered=TRUE)

files <- c("../simples/regression/simple/measures/k-notaccumulated.dat",
           "../simples/5-parity/simple/measures/k-notaccumulated.dat",
           "../simples/11-multiplexer/simple/measures/k-notaccumulated.dat",
		   "../simples/ant/simple/measures/k-notaccumulated.dat", 
           "../simples/4-parity/simple/measures/k-notaccumulated.dat",
           "../simples/6-multiplexer/simple/measures/k-notaccumulated.dat") 

labels <- factor(c("Regression", "5-Parity", "11-Multiplexer", "Artificial ant", "4-Parity", "6-Multiplexer"))


if (win) x11(width=8, height=6)

#par(mfrow=c(3,2), mar=c(3,3,2,1), oma=c(0.5,0.5,0,0.5), mgp=c(1.8, 1, 0))

data <- data.frame(label=NULL, g=NULL)

#strip.background <- trellis.par.get("strip.background") 
#trellis.par.set(strip.background = list(col = grey(7:1/8))) 
## Set color of plot symbols to grayscale: 
#plot.symbol <- trellis.par.get("plot.symbol") 
#trellis.par.set(plot.symbol = list(col = grey(5/8))) 

i <- 1
for (file in files) {
    print(file)
    g <-read.table(file, header=F)
    g <- g$V1
	#g <- g[g<800]

	data <- rbind(data, data.frame(label=labels[i], g=g))
	i <- i+1	
}
#print(data)

histogram(~ g | label, data=data, col="red",
        type="density", allow.multiple=TRUE,
        scales=list(relation="free"), as.table=TRUE, layout=c(3,2),aspect="y",
        xlab="Generation-to-success", ylab="Density", breaks=NULL, cex=0.7,
	   index.cond=list(c(5,2,4,6,3,1)),
	    panel = function(x, subscripts, ...) {
			#print(subscripts)
			shift <- 0
			gens <-1:50
  			breaks <- 0:50

    		print(panel.number())
			if (panel.number() == 1) {
				# Hormiga
				shift <- 9
			} else if (panel.number()  == 2) {
				# 4-Parity
			    shift <- 17
			} else if (panel.number() == 3) {
				# 6-Multiplexer
				shift <- 7
			} else if (panel.number() == 4) {
				# Reression
				shift <- 5
			} else if (panel.number() == 5) {
				# 5-Parity
				shift <- 7
      		    gens <- 1:1000
			} else if (panel.number() == 6) {
				# 11-Multiplexer
   			    shift <- 60
      		    x <- x[x<1000]
      		    gens <- 1:1000
    		} 

    		x <- x[x>shift]
    		x <- x - shift
    
    		param <- fitdistr(x, densfun="exponential")$estimate
			print(param)
			print(shift)
    		#x <- shift:max(gens)
	        panel.histogram(x+shift, ...) 
 	  		llines(shift:max(gens), dgeom(0:(max(gens)-shift), param), col="black")
	        #panel.mathdensity(dmath = dbinom, col = "black", args = list(size=10,prob=0.2)) 
		})
dev.copy2eps(file="../../../tex/figs/histogram-exponential.eps",  fonts="ComputerModern")
if(win) while(1) Sys.sleep(1)
