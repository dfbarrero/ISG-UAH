#!/usr/bin/Rscript --vanilla

# Fit the density distribution of P with several models

library(car)

x11()

#postscript(file="../../../tex/figs/histogram.eps", width=8, height=4, paper="special", horizontal=TRUE)
#pdf(file="../presentacion/figs/histogram.pdf", width=8, height=4)

files <- c("../simples/ant/simple/measures/k-notaccumulated.dat", 
           "../simples/regression/simple/measures/k-notaccumulated.dat",
           "../simples/4-parity/simple/measures/k-notaccumulated.dat",
           "../simples/5-parity/simple/measures/k-notaccumulated.dat",
           "../simples/6-multiplexer/simple/measures/k-notaccumulated.dat",
           "../simples/11-multiplexer/simple/measures/k-notaccumulated.dat") 

labels <- c("Artificial ant", "Regression", "4-Parity", "5-Parity", "6-Multiplexer", "11-Multiplexer")
distributions <- c("Normal", "Lognormal", "Weibull", "Logistic")

data <- data.frame(problem=NULL, g=NULL)

par(mfrow=c(2,3), mar=c(3,3,2,1), oma=c(0.5,0.5,0,0.5), mgp=c(1.8, 1, 0))

i <- 1
for (file in files) {
    print(file)
    g <-read.table(file, header=F)
    g <- g$V1
    g <- g[g<800]
	g <- log(g)

	qqPlot(log(sample(g, 150)), "norm", main=labels[i], ylab="Expected run-time samples", xlab="Lognormalamples")
	i <- i+1
}

#dev.copy2eps(file="../../../tex/figs/histogram-log.eps",  fonts="ComputerModern"); 
print("OK")
while (1) Sys.sleep(1)
