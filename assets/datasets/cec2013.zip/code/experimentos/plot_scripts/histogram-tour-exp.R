#!/usr/bin/Rscript --vanilla

# Fit the density distribution of P with several models

library(MASS)
library(car)
#postscript(file="../../../tex/figs/histogram.eps", width=8, height=4, paper="special", horizontal=TRUE)
#pdf(file="../presentacion/figs/histogram.pdf", width=8, height=4)

files <- c("../tour/ant-tour/tour-1/measures/k-notaccumulated.dat", 
           "../tour/regression-tour/tour-1/measures/k-notaccumulated.dat")
labels <- c("Artificial ant", "Regression")
distributions <- c("Normal", "Lognormal", "Weibull", "Logistic")

x11()

par(mfrow=c(2,2), mar=c(3,3,2,1), oma=c(0.5,0.5,0,0.5), mgp=c(1.8, 1, 0))

i <- 1
for (file in files) {
    print(file)
    print(i)
    data <-read.table(file, header=F)
    data <- data$V1

    x <- 100*(1:10)
    y <- rep(c(rep(FALSE, 999), TRUE), 10)

    gens <- 1:1000

	if (labels[i] == "Artificial ant")
		shift <- 180
	else if (labels[i] == "Regression")
		shift <- 280

	print(x)

    hist(data, freq=FALSE, xlab="Generation-to-success", main=labels[i], lwd=0.1, ylim=c(0,0.003), breaks=20)

	# Plot Weibull
    param <- fitdistr(data, densfun="Weibull")$estimate
    point <- dweibull(gens, shape=param[1], scale=param[2], log=F)
    lines(point, col=4, lty=3, pch=3, lwd=1.2)
    points((1:10)*100, point[(1:10)*100], col=4, lty=2, lwd=1.2, pch=3)

	# Plot shifted exponential
	data <- data[data>shift]
	data <- data-shift
    param <- fitdistr(data, densfun="exponential")$estimate
    point <- dexp(gens, param, log=F)
    lines(point, col="black", lty=4, pch=4, lwd=1.2)
    points((1:10)*100, point[(1:10)*100], col="black", lty=2, lwd=1.2, pch=4)

    #param <- fitdistr(data, densfun="t")$estimate 
	#point <- dt(1:50, df=param[3], ncp=param[1], log=F) 
	#lines(point, col=5, lty=5, pch=5) 
	#points(x, point[y==TRUE], col=5, lty=5, pch=5)
				
	if (i == 2) { # Last histogram 
		legend("topright", distributions, bty="n", 
			cex=0.9, col=c(1,2,4,"darkgreen"), lty=c(2,1,3,4), lwd=1.2, pch=c(1,2,3,4)) 
			#cex=0.9, col=c(2,1,3,4), lty=c(2,1,3,4), pch=c(2,1,3,4), lwd=1.2) 
	}

	wei <- rexp(length(data), param)
	wei[wei>max(data)] <- dexp(1, param, log=F)
	wei[wei>max(data)] <- dexp(1, param, log=F)
	wei[wei>max(data)] <- dexp(1, param, log=F)
	wei[wei>max(data)] <- dexp(1, param, log=F)
	wei[wei>max(data)] <- dexp(1, param, log=F)
	wei[wei>max(data)] <- dexp(1, param, log=F)
	wei[wei>max(data)] <- dexp(1, param, log=F)
	wei[wei>max(data)] <- dexp(1, param, log=F)
	wei[wei>max(data)] <- dexp(1, param, log=F)
	wei[wei>max(data)] <- dexp(1, param, log=F)
	wei[wei>max(data)] <- dexp(1, param, log=F)
	wei[wei>max(data)] <- dexp(1, param, log=F)
	wei[wei>max(data)] <- dexp(1, param, log=F)
	print(wei[wei>max(data)])
	
	qqplot(data+shift, wei+shift, col="blue", xlab="Generation-to-success", ylab="Weibull")
	abline(0,1,col="darkgrey")
	grid()
	i <- i+1 
}

#dev.copy2eps(file="../../../tex/figs/histogram-tour.eps",  fonts="ComputerModern"); 
while(1) Sys.sleep(1)
#q() 
