#!/bin/bash

# Mandatory parameters: "gp" or "ga"
TYPE="gp"
R_HEADER="generation initA initB initC initD avgNodesIndGen avgNodesTreeAGen avgNodesIndRun avgDepthIndGen avgDepthTreeA avgDepthIndRun meanRawGen meanAdjustedGen meanHitsGen bestRawGen bestAdjustedGen bestHitsGen bestRawRun bestAdjustedRun bestHitsRun"

# Statistics
SR="true"
SR_FITNESS=0.001
SR_CONDITION="<="
SR_COLUMN=15

KOZA="true"
KOZA_E=0.01

# Experiment parameters
PARAM="foo"
PARAM_VALUES="simple"
NAME="simple"
EXTRA=
