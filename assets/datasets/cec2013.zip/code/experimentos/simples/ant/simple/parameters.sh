#!/bin/bash

R_HEADER="generation initA initB initC initD avgNodesIndGen avgNodesTreeAGen avgNodesIndRun avgDepthIndGen avgDepthTreeA avgDepthIndRun meanRawGen meanAdjustedGen meanHitsGen bestRawGen bestAdjustedGen bestHitsGen bestRawRun bestAdjustedRun bestHitsRun"

# Statistics
SR="true"
SR_FITNESS=0
SR_CONDITION="=="
SR_COLUMN=15

KOZA="true"
KOZA_E=0.01
