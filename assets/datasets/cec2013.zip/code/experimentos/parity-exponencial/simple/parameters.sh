#!/bin/bash

# Mandatory parameters: "gp" or "ga"
K_HEADER="generation initA initB initC initD avgNodesIndGen avgNodesTreeAGen avgNodesIndRun avgDepthIndGen avgDepthTreeAGen avgDepthIndRun meanRawGen meanAdjustedGen meanHitsGen bestRawGen bestAdjustedGen bestHitsGen bestRawRun bestAdjustedRun bestHitsRun"

# Statistics
SR="true"
SR_CONDITION="=="
SR_FITNESS=0
SR_COLUMN=15

KOZA_E=0.01
